# PPLgram

PPLgram stores story records inside the existing Global Chat API by posting a
`PPLGRAM_STORY:` message to `/api/global-chat/messages`.

No new API route or database table is required.

- Text stories are stored directly in the chat message.
- Photo/video stories are uploaded to Catbox from the Flutter client, then the
  resulting URL is stored in the existing chat message.
- Stories expire client-side after 24 hours.
- Normal Global Chat hides `PPLGRAM_STORY:` records so stories do not pollute chat.
