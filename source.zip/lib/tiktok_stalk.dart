import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:flutter/services.dart';
import 'package:share_plus/share_plus.dart';
import 'package:path_provider/path_provider.dart';

// ─── TEMA WARNA PUTIH X BIRU NEW ─────────────────────────────────────────────────────────────
class _C {
  static const bg         = Color(0xFFE8EDF2);
  static const surface    = Color(0xFFFFFFFF);
  static const card       = Color(0xFFFFFFFF);
  static const border     = Color(0xFFD4DCE4);
  static const borderLit  = Color(0xFFCBD5E1);

  static const tiktokBlack = Color(0xFF010101);
  static const tiktokWhite = Color(0xFFFFFFFF);
  static const tiktokPink  = Color(0xFFFE2C55);
  static const tiktokBlue  = Color(0xFF00F2EA);
  static const tiktokPurple = Color(0xFF7C3AED);

  static const blue       = Color(0xFF1A73E8);
  static const blueMid    = Color(0xFF4285F4);
  static const green      = Color(0xFF34A853);
  static const red        = Color(0xFFEA4335);
  static const amber      = Color(0xFFFBBC04);

  static const text       = Color(0xFF202124);
  static const textSub    = Color(0xFF5F6368);
  static const textDim    = Color(0xFF9AA0A6);
  static const white      = Color(0xFFFFFFFF);

  static const LinearGradient tiktokGrad = LinearGradient(
    colors: [Color(0xFFFE2C55), Color(0xFF7C3AED)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );
}

class TiktokStalkPage extends StatefulWidget {
  const TiktokStalkPage({super.key});

  @override
  State<TiktokStalkPage> createState() => _TiktokStalkPageState();
}

class _TiktokStalkPageState extends State<TiktokStalkPage>
    with SingleTickerProviderStateMixin {
  final TextEditingController _usernameController = TextEditingController();
  bool _isLoading = false;
  Map<String, dynamic>? _userData;
  String? _errorMessage;
  List<dynamic>? _videoList;
  bool _isLoadingVideos = false;
  bool _isDownloading = false;

  late TabController _tabController;

  // ─── API ENDPOINTS ─────────────────────────────────────────────────────────
  static const String _apiStalk = 'https://api.siputzx.my.id/api/stalk/tiktok';
  static const String _apiUser = 'https://api.siputzx.my.id/api/tiktok/user';
  static const String _apiBackupStalk = 'https://api.dry.my.id/api/tiktok/stalk';
  static const String _apiBackupUser = 'https://api.dry.my.id/api/tiktok/user';

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  // ─── 3D TEXT ──────────────────────────────────────────────────────────────
  Widget _build3DText(String text, {double size = 16, Color? color}) {
    final textColor = color ?? _C.tiktokPink;
    return Stack(
      children: [
        Text(
          text,
          style: TextStyle(
            fontSize: size,
            fontWeight: FontWeight.w900,
            color: Colors.black.withOpacity(0.12),
            letterSpacing: 1,
          ),
        ),
        Transform.translate(
          offset: const Offset(-1.5, -1.5),
          child: Text(
            text,
            style: TextStyle(
              fontSize: size,
              fontWeight: FontWeight.w900,
              color: Colors.white.withOpacity(0.3),
              letterSpacing: 1,
            ),
          ),
        ),
        Transform.translate(
          offset: const Offset(-3, -3),
          child: Text(
            text,
            style: TextStyle(
              fontSize: size,
              fontWeight: FontWeight.w900,
              color: textColor,
              letterSpacing: 1,
              shadows: [
                Shadow(
                  color: textColor.withOpacity(0.3),
                  blurRadius: 12,
                  offset: const Offset(0, 3),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  // ─── STALK TIKTOK ──────────────────────────────────────────────────────────
  Future<void> _stalkTiktok() async {
    final username = _usernameController.text.trim();
    if (username.isEmpty) {
      setState(() {
        _errorMessage = "Masukkan username TikTok!";
        _userData = null;
        _videoList = null;
      });
      return;
    }

    final cleanUsername = username.replaceAll('@', '');

    setState(() {
      _isLoading = true;
      _errorMessage = null;
      _userData = null;
      _videoList = null;
    });

    // Coba API Primary
    bool success = await _fetchFromPrimary(cleanUsername);
    
    // Jika gagal, coba backup
    if (!success) {
      success = await _fetchFromBackup(cleanUsername);
    }

    if (!success && mounted) {
      setState(() {
        _errorMessage = "Gagal mendapatkan data. Coba lagi nanti.";
        _isLoading = false;
      });
    }
  }

  Future<bool> _fetchFromPrimary(String username) async {
    try {
      final response = await http.get(
        Uri.parse('$_apiStalk?username=$username'),
      ).timeout(const Duration(seconds: 15));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['status'] == true && data['data'] != null) {
          final userData = data['data'];
          
          setState(() {
            _userData = {
              'unique_id': userData['unique_id'] ?? username,
              'nickname': userData['nickname'] ?? userData['name'] ?? '',
              'avatar': userData['avatar'] ?? userData['profile_pic'] ?? '',
              'signature': userData['signature'] ?? userData['bio'] ?? '',
              'follower_count': userData['follower_count'] ?? userData['followers'] ?? 0,
              'following_count': userData['following_count'] ?? userData['following'] ?? 0,
              'heart_count': userData['heart_count'] ?? userData['likes'] ?? 0,
              'video_count': userData['video_count'] ?? userData['videos'] ?? 0,
              'region': userData['region'] ?? '',
              'is_verified': userData['is_verified'] ?? userData['verified'] ?? false,
              'is_private': userData['is_private'] ?? userData['private'] ?? false,
            };
            _errorMessage = null;
          });

          await _fetchUserVideos(username);
          setState(() => _isLoading = false);
          return true;
        }
      }
    } catch (e) {
      print('Primary API error: $e');
    }
    return false;
  }

  Future<bool> _fetchFromBackup(String username) async {
    try {
      final response = await http.get(
        Uri.parse('$_apiBackupStalk?username=$username'),
      ).timeout(const Duration(seconds: 15));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['status'] == true && data['result'] != null) {
          final userData = data['result'];
          
          setState(() {
            _userData = {
              'unique_id': userData['unique_id'] ?? username,
              'nickname': userData['nickname'] ?? userData['name'] ?? '',
              'avatar': userData['avatar'] ?? userData['profile_pic'] ?? '',
              'signature': userData['signature'] ?? userData['bio'] ?? '',
              'follower_count': userData['follower_count'] ?? userData['followers'] ?? 0,
              'following_count': userData['following_count'] ?? userData['following'] ?? 0,
              'heart_count': userData['heart_count'] ?? userData['likes'] ?? 0,
              'video_count': userData['video_count'] ?? userData['videos'] ?? 0,
              'region': userData['region'] ?? '',
              'is_verified': userData['is_verified'] ?? userData['verified'] ?? false,
              'is_private': userData['is_private'] ?? userData['private'] ?? false,
            };
            _errorMessage = null;
          });

          await _fetchUserVideosBackup(username);
          setState(() => _isLoading = false);
          return true;
        }
      }
    } catch (e) {
      print('Backup API error: $e');
    }
    return false;
  }

  Future<void> _fetchUserVideos(String username) async {
    setState(() => _isLoadingVideos = true);
    try {
      final response = await http.get(
        Uri.parse('$_apiUser?username=$username&limit=20'),
      ).timeout(const Duration(seconds: 15));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['status'] == true && data['data'] != null) {
          final videos = data['data'];
          if (videos is List) {
            setState(() {
              _videoList = videos.map((v) => {
                'video_url': v['video_url'] ?? v['url'] ?? '',
                'cover': v['cover'] ?? v['thumbnail'] ?? v['thumb'] ?? '',
                'title': v['title'] ?? v['description'] ?? v['desc'] ?? 'No description',
                'play_count': v['play_count'] ?? v['views'] ?? 0,
                'like_count': v['like_count'] ?? v['likes'] ?? 0,
                'comment_count': v['comment_count'] ?? v['comments'] ?? 0,
                'share_count': v['share_count'] ?? v['shares'] ?? 0,
                'duration': v['duration'] ?? 0,
                'created_at': v['created_at'] ?? v['create_time'] ?? '',
              }).toList();
            });
          } else {
            setState(() => _videoList = []);
          }
        }
      }
    } catch (e) {
      print('Error fetching videos: $e');
    } finally {
      setState(() => _isLoadingVideos = false);
    }
  }

  Future<void> _fetchUserVideosBackup(String username) async {
    setState(() => _isLoadingVideos = true);
    try {
      final response = await http.get(
        Uri.parse('$_apiBackupUser?username=$username&limit=20'),
      ).timeout(const Duration(seconds: 15));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['status'] == true && data['data'] != null) {
          final videos = data['data'];
          if (videos is List) {
            setState(() {
              _videoList = videos.map((v) => ({
                'video_url': v['video_url'] ?? v['url'] ?? '',
                'cover': v['cover'] ?? v['thumbnail'] ?? v['thumb'] ?? '',
                'title': v['title'] ?? v['description'] ?? v['desc'] ?? 'No description',
                'play_count': v['play_count'] ?? v['views'] ?? 0,
                'like_count': v['like_count'] ?? v['likes'] ?? 0,
                'comment_count': v['comment_count'] ?? v['comments'] ?? 0,
                'share_count': v['share_count'] ?? v['shares'] ?? 0,
                'duration': v['duration'] ?? 0,
                'created_at': v['created_at'] ?? v['create_time'] ?? '',
              })).toList();
            });
          } else {
            setState(() => _videoList = []);
          }
        }
      }
    } catch (e) {
      print('Backup videos error: $e');
    } finally {
      setState(() => _isLoadingVideos = false);
    }
  }

  Future<void> _downloadVideo(String url, String desc) async {
    if (url.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('URL video tidak tersedia'),
          backgroundColor: _C.red,
          behavior: SnackBarBehavior.floating,
        ),
      );
      return;
    }

    setState(() => _isDownloading = true);
    try {
      final response = await http.get(Uri.parse(url));
      if (response.statusCode == 200) {
        final dir = await getTemporaryDirectory();
        final file = File(
          '${dir.path}/tiktok_${DateTime.now().millisecondsSinceEpoch}.mp4',
        );
        await file.writeAsBytes(response.bodyBytes);

        await Share.shareXFiles(
          [XFile(file.path)],
          text: desc.isNotEmpty ? 'TikTok: $desc' : 'TikTok Video',
        );

        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Row(children: [
                Icon(Icons.check_circle, color: Colors.white, size: 18),
                SizedBox(width: 8),
                Text('Video siap dibagikan!'),
              ]),
              backgroundColor: _C.green,
              behavior: SnackBarBehavior.floating,
              duration: Duration(seconds: 2),
            ),
          );
        }
      } else {
        throw Exception('Failed to download');
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Gagal download: $e'),
            backgroundColor: _C.red,
            behavior: SnackBarBehavior.floating,
          ),
        );
      }
    } finally {
      if (mounted) setState(() => _isDownloading = false);
    }
  }

  void _copyToClipboard(String text, String label) {
    Clipboard.setData(ClipboardData(text: text));
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(children: [
          const Icon(Icons.check_circle, color: Colors.white, size: 16),
          const SizedBox(width: 8),
          Text('$label disalin!', style: const TextStyle(color: Colors.white)),
        ]),
        backgroundColor: _C.green,
        behavior: SnackBarBehavior.floating,
        duration: const Duration(seconds: 2),
      ),
    );
  }

  String _formatNumber(dynamic num) {
    if (num == null) return '0';
    final n = num is int ? num : int.tryParse(num.toString()) ?? 0;
    if (n >= 1000000) {
      return '${(n / 1000000).toStringAsFixed(1)}M';
    } else if (n >= 1000) {
      return '${(n / 1000).toStringAsFixed(1)}K';
    }
    return n.toString();
  }

  String _formatDuration(dynamic duration) {
    if (duration == null) return '0:00';
    final seconds = duration is int ? duration : int.tryParse(duration.toString()) ?? 0;
    final minutes = seconds ~/ 60;
    final remainingSeconds = seconds % 60;
    return '$minutes:${remainingSeconds.toString().padLeft(2, '0')}';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _C.bg,
      appBar: _buildAppBar(),
      body: SingleChildScrollView(
        physics: const BouncingScrollPhysics(),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            children: [
              _buildSearchCard(),
              const SizedBox(height: 16),
              if (_errorMessage != null) _buildErrorBanner(),
              if (_isLoading) _buildLoadingState(),
              if (_userData != null && !_isLoading) _buildResultCard(),
            ],
          ),
        ),
      ),
    );
  }

  PreferredSizeWidget _buildAppBar() {
    return AppBar(
      title: _build3DText('TikTok Stalk', size: 18, color: _C.tiktokPink),
      backgroundColor: _C.surface,
      elevation: 0,
      centerTitle: true,
      bottom: PreferredSize(
        preferredSize: const Size.fromHeight(1),
        child: Container(height: 1, color: _C.border),
      ),
      leading: IconButton(
        icon: const Icon(Icons.arrow_back_ios_new_rounded, color: _C.textSub),
        onPressed: () => Navigator.pop(context),
      ),
      actions: [
        IconButton(
          icon: const Icon(Icons.info_outline_rounded, color: _C.textSub),
          onPressed: () => _showInfoDialog(),
        ),
        const SizedBox(width: 4),
      ],
    );
  }

  Widget _buildSearchCard() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: _C.surface,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: _C.border),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.04),
            blurRadius: 12,
            offset: const Offset(0, 6),
          ),
          BoxShadow(
            color: Colors.white.withOpacity(0.6),
            blurRadius: 8,
            offset: const Offset(-2, -2),
          ),
        ],
      ),
      child: Column(
        children: [
          Row(
            children: [
              Container(
                width: 40,
                height: 40,
                decoration: BoxDecoration(
                  gradient: _C.tiktokGrad,
                  borderRadius: BorderRadius.circular(12),
                  boxShadow: [
                    BoxShadow(
                      color: _C.tiktokPink.withOpacity(0.3),
                      blurRadius: 12,
                      offset: const Offset(0, 4),
                    ),
                  ],
                ),
                child: const Icon(Icons.music_note_rounded, color: Colors.white, size: 22),
              ),
              const SizedBox(width: 14),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Cari Akun TikTok',
                    style: TextStyle(
                      color: _C.text,
                      fontSize: 16,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  const Text(
                    'Masukkan username tanpa @',
                    style: TextStyle(
                      color: _C.textSub,
                      fontSize: 12,
                    ),
                  ),
                ],
              ),
            ],
          ),
          const SizedBox(height: 16),
          TextField(
            controller: _usernameController,
            style: const TextStyle(
              color: Colors.black,
              fontSize: 14,
              fontWeight: FontWeight.w500,
            ),
            decoration: InputDecoration(
              hintText: 'contoh: tiktok',
              hintStyle: TextStyle(color: _C.textDim),
              prefixIcon: const Icon(Icons.alternate_email_rounded, color: _C.tiktokPink),
              filled: true,
              fillColor: _C.bg,
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: BorderSide(color: _C.border),
              ),
              enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: BorderSide(color: _C.border),
              ),
              focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: BorderSide(color: _C.tiktokPink, width: 1.5),
              ),
              contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
            ),
            onSubmitted: (_) => _stalkTiktok(),
          ),
          const SizedBox(height: 14),
          SizedBox(
            width: double.infinity,
            child: Container(
              height: 48,
              decoration: BoxDecoration(
                gradient: _C.tiktokGrad,
                borderRadius: BorderRadius.circular(14),
                boxShadow: [
                  BoxShadow(
                    color: _C.tiktokPink.withOpacity(0.35),
                    blurRadius: 16,
                    offset: const Offset(0, 4),
                  ),
                  BoxShadow(
                    color: Colors.white.withOpacity(0.6),
                    blurRadius: 8,
                    offset: const Offset(-2, -2),
                  ),
                ],
              ),
              child: ElevatedButton(
                onPressed: _isLoading ? null : _stalkTiktok,
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.transparent,
                  shadowColor: Colors.transparent,
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(
                      _isLoading ? Icons.hourglass_top : Icons.search,
                      color: Colors.white,
                      size: 20,
                    ),
                    const SizedBox(width: 10),
                    Text(
                      _isLoading ? 'MENCARI...' : 'STALKING',
                      style: const TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.w800,
                        fontSize: 14,
                        letterSpacing: 0.5,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildErrorBanner() {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: _C.red.withOpacity(0.06),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: _C.red.withOpacity(0.3)),
      ),
      child: Row(
        children: [
          Icon(Icons.error_outline_rounded, color: _C.red, size: 20),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              _errorMessage!,
              style: TextStyle(
                color: _C.textSub,
                fontSize: 13,
              ),
            ),
          ),
          GestureDetector(
            onTap: () => setState(() => _errorMessage = null),
            child: Icon(Icons.close_rounded, color: _C.textDim, size: 18),
          ),
        ],
      ),
    );
  }

  Widget _buildLoadingState() {
    return Center(
      child: Column(
        children: [
          const SizedBox(height: 20),
          Container(
            width: 60,
            height: 60,
            decoration: BoxDecoration(
              gradient: _C.tiktokGrad,
              shape: BoxShape.circle,
              boxShadow: [
                BoxShadow(
                  color: _C.tiktokPink.withOpacity(0.3),
                  blurRadius: 20,
                  spreadRadius: 2,
                ),
              ],
            ),
            child: const Center(
              child: SizedBox(
                width: 30,
                height: 30,
                child: CircularProgressIndicator(
                  color: Colors.white,
                  strokeWidth: 3,
                ),
              ),
            ),
          ),
          const SizedBox(height: 16),
          const Text(
            'Mengintai Akun...',
            style: TextStyle(
              color: _C.textSub,
              fontSize: 14,
              fontWeight: FontWeight.w500,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildResultCard() {
    if (_userData == null) return const SizedBox();
    final data = _userData!;

    return Column(
      children: [
        Container(
          decoration: BoxDecoration(
            color: _C.surface,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: _C.border),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.04),
                blurRadius: 12,
                offset: const Offset(0, 6),
              ),
              BoxShadow(
                color: Colors.white.withOpacity(0.6),
                blurRadius: 8,
                offset: const Offset(-2, -2),
              ),
            ],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  gradient: _C.tiktokGrad,
                  borderRadius: const BorderRadius.only(
                    topLeft: Radius.circular(20),
                    topRight: Radius.circular(20),
                  ),
                ),
                child: Row(
                  children: [
                    Container(
                      width: 72,
                      height: 72,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        border: Border.all(color: Colors.white, width: 3),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withOpacity(0.2),
                            blurRadius: 12,
                            offset: const Offset(0, 4),
                          ),
                        ],
                      ),
                      child: ClipOval(
                        child: _buildProfileImage(data['avatar'] ?? ''),
                      ),
                    ),
                    const SizedBox(width: 16),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            data['nickname'] ?? data['unique_id'] ?? 'Unknown',
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 18,
                              fontWeight: FontWeight.w700,
                            ),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                          Row(
                            children: [
                              Text(
                                '@${data['unique_id'] ?? 'unknown'}',
                                style: const TextStyle(
                                  color: Colors.white70,
                                  fontSize: 13,
                                ),
                              ),
                              const SizedBox(width: 8),
                              if (data['is_verified'] == true)
                                const Icon(
                                  Icons.verified_rounded,
                                  color: Colors.white,
                                  size: 16,
                                ),
                              if (data['is_private'] == true)
                                Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                                  decoration: BoxDecoration(
                                    color: Colors.black.withOpacity(0.3),
                                    borderRadius: BorderRadius.circular(4),
                                  ),
                                  child: const Text(
                                    'PRIVATE',
                                    style: TextStyle(
                                      color: Colors.white70,
                                      fontSize: 8,
                                      fontWeight: FontWeight.w700,
                                    ),
                                  ),
                                ),
                            ],
                          ),
                          if (data['signature'] != null && data['signature'].isNotEmpty) ...[
                            const SizedBox(height: 4),
                            Text(
                              data['signature'],
                              style: const TextStyle(
                                color: Colors.white70,
                                fontSize: 12,
                              ),
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                            ),
                          ],
                        ],
                      ),
                    ),
                  ],
                ),
              ),

              Container(
                padding: const EdgeInsets.symmetric(vertical: 16),
                decoration: BoxDecoration(
                  border: Border(
                    bottom: BorderSide(color: _C.border),
                  ),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    _buildStatItem(
                      icon: Icons.video_library_rounded,
                      label: 'Videos',
                      value: _formatNumber(data['video_count']),
                      color: _C.tiktokPink,
                    ),
                    _buildStatItem(
                      icon: Icons.favorite_rounded,
                      label: 'Likes',
                      value: _formatNumber(data['heart_count']),
                      color: _C.red,
                    ),
                    _buildStatItem(
                      icon: Icons.people_alt_rounded,
                      label: 'Followers',
                      value: _formatNumber(data['follower_count']),
                      color: _C.tiktokBlue,
                    ),
                    _buildStatItem(
                      icon: Icons.person_add_alt_1_rounded,
                      label: 'Following',
                      value: _formatNumber(data['following_count']),
                      color: _C.tiktokPurple,
                    ),
                  ],
                ),
              ),

              Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  children: [
                    _buildDetailRow(
                      icon: Icons.person_outline_rounded,
                      label: 'Username',
                      value: data['unique_id'] ?? '-',
                      onCopy: () => _copyToClipboard(data['unique_id'] ?? '', 'Username'),
                    ),
                    _buildDetailRow(
                      icon: Icons.badge_rounded,
                      label: 'Nama',
                      value: data['nickname'] ?? '-',
                      onCopy: () => _copyToClipboard(data['nickname'] ?? '', 'Nama'),
                    ),
                    if (data['signature'] != null && data['signature'].isNotEmpty)
                      _buildDetailRow(
                        icon: Icons.link_rounded,
                        label: 'Bio',
                        value: data['signature'] ?? '-',
                        onCopy: () => _copyToClipboard(data['signature'] ?? '', 'Bio'),
                      ),
                    if (data['region'] != null && data['region'].isNotEmpty)
                      _buildDetailRow(
                        icon: Icons.public_rounded,
                        label: 'Region',
                        value: data['region'] ?? '-',
                      ),
                    _buildDetailRow(
                      icon: Icons.verified_rounded,
                      label: 'Verified',
                      value: data['is_verified'] == true ? '✅ Yes' : '❌ No',
                    ),
                    _buildDetailRow(
                      icon: Icons.lock_rounded,
                      label: 'Private',
                      value: data['is_private'] == true ? '🔒 Private' : '🌍 Public',
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),

        const SizedBox(height: 16),

        Container(
          decoration: BoxDecoration(
            color: _C.surface,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: _C.border),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.04),
                blurRadius: 12,
                offset: const Offset(0, 6),
              ),
              BoxShadow(
                color: Colors.white.withOpacity(0.6),
                blurRadius: 8,
                offset: const Offset(-2, -2),
              ),
            ],
          ),
          child: Column(
            children: [
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                child: Row(
                  children: [
                    Container(
                      width: 4,
                      height: 18,
                      decoration: BoxDecoration(
                        gradient: _C.tiktokGrad,
                        borderRadius: BorderRadius.circular(2),
                      ),
                    ),
                    const SizedBox(width: 10),
                    _build3DText('TikTok Videos', size: 15, color: _C.tiktokPink),
                    const Spacer(),
                    if (_isLoadingVideos)
                      const SizedBox(
                        width: 20,
                        height: 20,
                        child: CircularProgressIndicator(
                          color: _C.tiktokPink,
                          strokeWidth: 2,
                        ),
                      ),
                  ],
                ),
              ),

              if (_videoList != null && _videoList!.isNotEmpty)
                Padding(
                  padding: const EdgeInsets.all(12),
                  child: GridView.builder(
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 2,
                      crossAxisSpacing: 10,
                      mainAxisSpacing: 10,
                      childAspectRatio: 0.7,
                    ),
                    itemCount: _videoList!.length > 20 ? 20 : _videoList!.length,
                    itemBuilder: (context, index) {
                      final video = _videoList![index];
                      final cover = video['cover'] ?? '';
                      final desc = video['title'] ?? 'No description';
                      final playCount = video['play_count'] ?? 0;
                      final likeCount = video['like_count'] ?? 0;
                      final url = video['video_url'] ?? '';
                      final duration = video['duration'] ?? 0;

                      return GestureDetector(
                        onTap: () => _showVideoDetail(video),
                        child: Container(
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(16),
                            border: Border.all(color: _C.border),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.black.withOpacity(0.04),
                                blurRadius: 8,
                                offset: const Offset(0, 4),
                              ),
                            ],
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Expanded(
                                child: Stack(
                                  fit: StackFit.expand,
                                  children: [
                                    ClipRRect(
                                      borderRadius: const BorderRadius.only(
                                        topLeft: Radius.circular(16),
                                        topRight: Radius.circular(16),
                                      ),
                                      child: cover.isNotEmpty
                                          ? Image.network(
                                              cover,
                                              fit: BoxFit.cover,
                                              loadingBuilder: (_, child, progress) {
                                                if (progress == null) return child;
                                                return Container(
                                                  color: _C.bg,
                                                  child: const Center(
                                                    child: SizedBox(
                                                      width: 24,
                                                      height: 24,
                                                      child: CircularProgressIndicator(
                                                        color: _C.tiktokPink,
                                                        strokeWidth: 2,
                                                      ),
                                                    ),
                                                  ),
                                                );
                                              },
                                              errorBuilder: (_, __, ___) => Container(
                                                color: _C.bg,
                                                child: const Icon(
                                                  Icons.video_library_rounded,
                                                  color: _C.textDim,
                                                  size: 40,
                                                ),
                                              ),
                                            )
                                          : Container(
                                              color: _C.bg,
                                              child: const Icon(
                                                Icons.video_library_rounded,
                                                color: _C.textDim,
                                                size: 40,
                                              ),
                                            ),
                                    ),
                                    Positioned.fill(
                                      child: Container(
                                        decoration: BoxDecoration(
                                          borderRadius: const BorderRadius.only(
                                            topLeft: Radius.circular(16),
                                            topRight: Radius.circular(16),
                                          ),
                                          gradient: LinearGradient(
                                            begin: Alignment.topCenter,
                                            end: Alignment.bottomCenter,
                                            colors: [
                                              Colors.transparent,
                                              Colors.black.withOpacity(0.1),
                                              Colors.black.withOpacity(0.5),
                                            ],
                                          ),
                                        ),
                                        child: const Center(
                                          child: Icon(
                                            Icons.play_arrow_rounded,
                                            color: Colors.white,
                                            size: 40,
                                          ),
                                        ),
                                      ),
                                    ),
                                    Positioned(
                                      bottom: 6,
                                      left: 6,
                                      child: Container(
                                        padding: const EdgeInsets.symmetric(
                                          horizontal: 6,
                                          vertical: 3,
                                        ),
                                        decoration: BoxDecoration(
                                          color: Colors.black.withOpacity(0.7),
                                          borderRadius: BorderRadius.circular(6),
                                        ),
                                        child: Row(
                                          mainAxisSize: MainAxisSize.min,
                                          children: [
                                            const Icon(
                                              Icons.play_arrow_rounded,
                                              color: Colors.white,
                                              size: 12,
                                            ),
                                            const SizedBox(width: 2),
                                            Text(
                                              _formatNumber(playCount),
                                              style: const TextStyle(
                                                color: Colors.white,
                                                fontSize: 10,
                                                fontWeight: FontWeight.w600,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                    Positioned(
                                      bottom: 6,
                                      right: 6,
                                      child: Container(
                                        padding: const EdgeInsets.symmetric(
                                          horizontal: 6,
                                          vertical: 3,
                                        ),
                                        decoration: BoxDecoration(
                                          color: Colors.black.withOpacity(0.7),
                                          borderRadius: BorderRadius.circular(6),
                                        ),
                                        child: Row(
                                          mainAxisSize: MainAxisSize.min,
                                          children: [
                                            const Icon(
                                              Icons.favorite_rounded,
                                              color: Colors.red,
                                              size: 12,
                                            ),
                                            const SizedBox(width: 2),
                                            Text(
                                              _formatNumber(likeCount),
                                              style: const TextStyle(
                                                color: Colors.white,
                                                fontSize: 10,
                                                fontWeight: FontWeight.w600,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                    Positioned(
                                      top: 6,
                                      right: 6,
                                      child: GestureDetector(
                                        onTap: () => _downloadVideo(url, desc),
                                        child: Container(
                                          padding: const EdgeInsets.all(6),
                                          decoration: BoxDecoration(
                                            color: Colors.black.withOpacity(0.7),
                                            borderRadius: BorderRadius.circular(8),
                                          ),
                                          child: _isDownloading
                                              ? const SizedBox(
                                                  width: 16,
                                                  height: 16,
                                                  child: CircularProgressIndicator(
                                                    color: Colors.white,
                                                    strokeWidth: 2,
                                                  ),
                                                )
                                              : const Icon(
                                                  Icons.download_rounded,
                                                  color: Colors.white,
                                                  size: 16,
                                                ),
                                        ),
                                      ),
                                    ),
                                    if (duration > 0)
                                      Positioned(
                                        top: 6,
                                        left: 6,
                                        child: Container(
                                          padding: const EdgeInsets.symmetric(
                                            horizontal: 6,
                                            vertical: 3,
                                          ),
                                          decoration: BoxDecoration(
                                            color: Colors.black.withOpacity(0.7),
                                            borderRadius: BorderRadius.circular(6),
                                          ),
                                          child: Text(
                                            _formatDuration(duration),
                                            style: const TextStyle(
                                              color: Colors.white,
                                              fontSize: 10,
                                              fontWeight: FontWeight.w600,
                                            ),
                                          ),
                                        ),
                                      ),
                                  ],
                                ),
                              ),
                              Container(
                                padding: const EdgeInsets.symmetric(
                                  horizontal: 10,
                                  vertical: 8,
                                ),
                                decoration: const BoxDecoration(
                                  color: Colors.white,
                                  borderRadius: BorderRadius.only(
                                    bottomLeft: Radius.circular(16),
                                    bottomRight: Radius.circular(16),
                                  ),
                                ),
                                child: Text(
                                  desc,
                                  style: const TextStyle(
                                    color: _C.text,
                                    fontSize: 11,
                                    fontWeight: FontWeight.w500,
                                  ),
                                  maxLines: 2,
                                  overflow: TextOverflow.ellipsis,
                                ),
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
                )
              else if (!_isLoadingVideos && _videoList != null)
                const Padding(
                  padding: EdgeInsets.symmetric(vertical: 30),
                  child: Column(
                    children: [
                      Icon(Icons.video_library_rounded, color: _C.textDim, size: 40),
                      SizedBox(height: 8),
                      Text(
                        'Tidak ada video',
                        style: TextStyle(
                          color: _C.textSub,
                          fontSize: 13,
                        ),
                      ),
                    ],
                  ),
                ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildProfileImage(String url) {
    if (url.isEmpty) {
      return Container(
        color: Colors.white.withOpacity(0.3),
        child: const Icon(Icons.person, color: Colors.white, size: 32),
      );
    }
    return Image.network(
      url,
      fit: BoxFit.cover,
      errorBuilder: (_, __, ___) => Container(
        color: Colors.white.withOpacity(0.3),
        child: const Icon(Icons.person, color: Colors.white, size: 32),
      ),
    );
  }

  Widget _buildStatItem({
    required IconData icon,
    required String label,
    required String value,
    required Color color,
  }) {
    return Column(
      children: [
        Icon(icon, color: color, size: 22),
        const SizedBox(height: 4),
        Text(
          value,
          style: TextStyle(
            color: _C.text,
            fontSize: 16,
            fontWeight: FontWeight.w800,
          ),
        ),
        Text(
          label,
          style: TextStyle(
            color: _C.textSub,
            fontSize: 10,
            fontWeight: FontWeight.w500,
          ),
        ),
      ],
    );
  }

  Widget _buildDetailRow({
    required IconData icon,
    required String label,
    required String value,
    VoidCallback? onCopy,
  }) {
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      decoration: BoxDecoration(
        color: _C.bg,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: _C.border),
      ),
      child: Row(
        children: [
          Icon(icon, color: _C.tiktokPink, size: 16),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  label,
                  style: TextStyle(
                    color: _C.textSub,
                    fontSize: 10,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                Text(
                  value,
                  style: TextStyle(
                    color: _C.text,
                    fontSize: 13,
                    fontWeight: FontWeight.w500,
                  ),
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                ),
              ],
            ),
          ),
          if (onCopy != null)
            GestureDetector(
              onTap: onCopy,
              child: Container(
                padding: const EdgeInsets.all(6),
                decoration: BoxDecoration(
                  color: _C.tiktokPink.withOpacity(0.08),
                  shape: BoxShape.circle,
                ),
                child: Icon(Icons.copy_rounded, color: _C.tiktokPink, size: 14),
              ),
            ),
        ],
      ),
    );
  }

  void _showVideoDetail(Map<String, dynamic> video) {
    final url = video['video_url'] ?? '';
    final desc = video['title'] ?? 'No description';
    final playCount = video['play_count'] ?? 0;
    final likeCount = video['like_count'] ?? 0;
    final shareCount = video['share_count'] ?? 0;
    final commentCount = video['comment_count'] ?? 0;
    final cover = video['cover'] ?? '';
    final duration = video['duration'] ?? 0;

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => Container(
        height: MediaQuery.of(context).size.height * 0.85,
        decoration: BoxDecoration(
          color: _C.surface,
          borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.2),
              blurRadius: 20,
              offset: const Offset(0, -4),
            ),
          ],
        ),
        child: Column(
          children: [
            Container(
              margin: const EdgeInsets.only(top: 12),
              width: 40,
              height: 4,
              decoration: BoxDecoration(
                color: _C.border,
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            const SizedBox(height: 8),

            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              child: Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      gradient: _C.tiktokGrad,
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: const Icon(
                      Icons.play_arrow_rounded,
                      color: Colors.white,
                      size: 18,
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Text(
                      'TikTok Video',
                      style: TextStyle(
                        color: _C.text,
                        fontSize: 16,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ),
                  IconButton(
                    icon: const Icon(Icons.close_rounded, color: _C.textSub),
                    onPressed: () => Navigator.pop(context),
                    padding: EdgeInsets.zero,
                    constraints: const BoxConstraints(),
                  ),
                ],
              ),
            ),

            const Divider(height: 1, color: _C.border),

            Expanded(
              child: SingleChildScrollView(
                child: Column(
                  children: [
                    Container(
                      margin: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(16),
                        border: Border.all(color: _C.border),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withOpacity(0.08),
                            blurRadius: 12,
                            offset: const Offset(0, 4),
                          ),
                        ],
                      ),
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(16),
                        child: Stack(
                          children: [
                            cover.isNotEmpty
                                ? Image.network(
                                    cover,
                                    height: 300,
                                    width: double.infinity,
                                    fit: BoxFit.cover,
                                    loadingBuilder: (_, child, progress) {
                                      if (progress == null) return child;
                                      return Container(
                                        height: 300,
                                        color: _C.bg,
                                        child: const Center(
                                          child: SizedBox(
                                            width: 30,
                                            height: 30,
                                            child: CircularProgressIndicator(
                                              color: _C.tiktokPink,
                                              strokeWidth: 2.5,
                                            ),
                                          ),
                                        ),
                                      );
                                    },
                                    errorBuilder: (_, __, ___) => Container(
                                      height: 300,
                                      color: _C.bg,
                                      child: const Icon(
                                        Icons.broken_image_rounded,
                                        color: _C.textDim,
                                        size: 50,
                                      ),
                                    ),
                                  )
                                : Container(
                                    height: 300,
                                    color: _C.bg,
                                    child: const Icon(
                                      Icons.video_library_rounded,
                                      color: _C.textDim,
                                      size: 50,
                                    ),
                                  ),
                            Container(
                              height: 300,
                              decoration: BoxDecoration(
                                gradient: LinearGradient(
                                  begin: Alignment.topCenter,
                                  end: Alignment.bottomCenter,
                                  colors: [
                                    Colors.transparent,
                                    Colors.black.withOpacity(0.1),
                                    Colors.black.withOpacity(0.3),
                                  ],
                                ),
                              ),
                              child: const Center(
                                child: Icon(
                                  Icons.play_circle_filled_rounded,
                                  color: Colors.white,
                                  size: 60,
                                ),
                              ),
                            ),
                            if (duration > 0)
                              Positioned(
                                bottom: 12,
                                left: 12,
                                child: Container(
                                  padding: const EdgeInsets.symmetric(
                                    horizontal: 8,
                                    vertical: 4,
                                  ),
                                  decoration: BoxDecoration(
                                    color: Colors.black.withOpacity(0.7),
                                    borderRadius: BorderRadius.circular(6),
                                  ),
                                  child: Text(
                                    _formatDuration(duration),
                                    style: const TextStyle(
                                      color: Colors.white,
                                      fontSize: 12,
                                      fontWeight: FontWeight.w600,
                                    ),
                                  ),
                                ),
                              ),
                          ],
                        ),
                      ),
                    ),

                    if (desc.isNotEmpty && desc != 'No description')
                      Container(
                        margin: const EdgeInsets.symmetric(horizontal: 16),
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color: _C.bg,
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(color: _C.border),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text(
                              'Description',
                              style: TextStyle(
                                color: _C.textSub,
                                fontSize: 11,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              desc,
                              style: TextStyle(
                                color: _C.text,
                                fontSize: 14,
                                height: 1.5,
                              ),
                            ),
                          ],
                        ),
                      ),

                    Container(
                      margin: const EdgeInsets.all(16),
                      padding: const EdgeInsets.symmetric(vertical: 12),
                      decoration: BoxDecoration(
                        color: _C.bg,
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: _C.border),
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                          _buildStatSmall(
                            icon: Icons.play_arrow_rounded,
                            label: 'Views',
                            value: _formatNumber(playCount),
                            color: _C.tiktokBlue,
                          ),
                          Container(
                            width: 1,
                            height: 30,
                            color: _C.border,
                          ),
                          _buildStatSmall(
                            icon: Icons.favorite_rounded,
                            label: 'Likes',
                            value: _formatNumber(likeCount),
                            color: _C.red,
                          ),
                          Container(
                            width: 1,
                            height: 30,
                            color: _C.border,
                          ),
                          _buildStatSmall(
                            icon: Icons.share_rounded,
                            label: 'Shares',
                            value: _formatNumber(shareCount),
                            color: _C.tiktokPink,
                          ),
                          Container(
                            width: 1,
                            height: 30,
                            color: _C.border,
                          ),
                          _buildStatSmall(
                            icon: Icons.chat_bubble_outline_rounded,
                            label: 'Comments',
                            value: _formatNumber(commentCount),
                            color: _C.blue,
                          ),
                        ],
                      ),
                    ),

                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 16),
                      child: Container(
                        width: double.infinity,
                        height: 46,
                        decoration: BoxDecoration(
                          gradient: _C.tiktokGrad,
                          borderRadius: BorderRadius.circular(14),
                          boxShadow: [
                            BoxShadow(
                              color: _C.tiktokPink.withOpacity(0.3),
                              blurRadius: 12,
                              offset: const Offset(0, 4),
                            ),
                          ],
                        ),
                        child: ElevatedButton(
                          onPressed: _isDownloading ? null : () => _downloadVideo(url, desc),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.transparent,
                            shadowColor: Colors.transparent,
                          ),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(
                                _isDownloading ? Icons.hourglass_top : Icons.download_rounded,
                                color: Colors.white,
                                size: 20,
                              ),
                              const SizedBox(width: 10),
                              Text(
                                _isDownloading ? 'MENGUNDUH...' : 'DOWNLOAD VIDEO',
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.w800,
                                  fontSize: 14,
                                  letterSpacing: 0.5,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(height: 24),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStatSmall({
    required IconData icon,
    required String label,
    required String value,
    required Color color,
  }) {
    return Row(
      children: [
        Icon(icon, color: color, size: 18),
        const SizedBox(width: 6),
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              value,
              style: TextStyle(
                color: _C.text,
                fontSize: 14,
                fontWeight: FontWeight.w700,
              ),
            ),
            Text(
              label,
              style: TextStyle(
                color: _C.textSub,
                fontSize: 10,
              ),
            ),
          ],
        ),
      ],
    );
  }

  void _showInfoDialog() {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: _C.surface,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
        ),
        title: Row(
          children: [
            Container(
              width: 36,
              height: 36,
              decoration: BoxDecoration(
                gradient: _C.tiktokGrad,
                borderRadius: BorderRadius.circular(10),
              ),
              child: const Icon(Icons.info_outline_rounded, color: Colors.white, size: 18),
            ),
            const SizedBox(width: 10),
            const Text(
              'Info Stalk',
              style: TextStyle(
                color: _C.text,
                fontWeight: FontWeight.w700,
                fontSize: 16,
              ),
            ),
          ],
        ),
        content: const Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              '🔍 Fitur ini digunakan untuk melihat informasi publik akun TikTok.',
              style: TextStyle(
                color: _C.textSub,
                fontSize: 13,
                height: 1.5,
              ),
            ),
            SizedBox(height: 12),
            Text(
              '📌 Data yang tersedia:',
              style: TextStyle(
                color: _C.text,
                fontWeight: FontWeight.w600,
                fontSize: 13,
              ),
            ),
            SizedBox(height: 6),
            Text(
              '• Nama & username\n• Bio / signature\n• Followers & following\n• Jumlah video\n• Total likes\n• Video terbaru',
              style: TextStyle(
                color: _C.textSub,
                fontSize: 12,
                height: 1.6,
              ),
            ),
            SizedBox(height: 12),
            Text(
              '⚠️ Hanya menampilkan informasi publik yang tersedia.',
              style: TextStyle(
                color: _C.amber,
                fontSize: 12,
                fontStyle: FontStyle.italic,
              ),
            ),
          ],
        ),
        actions: [
          Container(
            decoration: BoxDecoration(
              gradient: _C.tiktokGrad,
              borderRadius: BorderRadius.circular(12),
            ),
            child: TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text(
                'OK',
                style: TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}