import 'dart:async';

/// PPL Project attribution + lightweight tamper check.
///
/// This is intentionally a source-level guard, not DRM. A determined person can
/// patch a compiled APK, but changing/removing the attribution without also
/// updating the guard will make the app refuse to start.
class BrandGuard {
  static const String creator = '@AmbatukamBePenat';
  static const String assistant = 'chat gpt';
  static const String appName = 'PPL Project';

  // FNV-1a 32-bit signature of "$appName|$creator|$assistant".
  static const int _expectedSignature = 0x52A259E5;
  static bool _watermarkRendered = false;

  static void enforce() {
    final signature = _fnv1a32('$appName|$creator|$assistant');
    if (signature != _expectedSignature) {
      throw StateError('PPL Project attribution integrity check failed.');
    }

    // The UI must render the attribution shortly after startup.
    Timer(const Duration(seconds: 5), () {
      if (!_watermarkRendered) {
        throw StateError('PPL Project watermark integrity check failed.');
      }
    });
  }

  static void markWatermarkRendered() {
    _watermarkRendered = true;
  }

  static int _fnv1a32(String value) {
    var hash = 0x811C9DC5;
    for (final unit in value.codeUnits) {
      hash ^= unit;
      hash = (hash * 0x01000193) & 0xFFFFFFFF;
    }
    return hash;
  }
}
