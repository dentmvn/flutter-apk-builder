// SELLER_PAGE.DART

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

// ─── TEMA WARNA PUTIH X BIRU NEW ──────────────────────────────────────────
class _C {
  static const bg         = Color(0xFFE8EDF2);
  static const surface    = Color(0xFFFFFFFF);
  static const card       = Color(0xFFFFFFFF);
  static const border     = Color(0xFFD4DCE4);
  static const borderLit  = Color(0xFFCBD5E1);

  static const blue       = Color(0xFF1A73E8);
  static const blueMid    = Color(0xFF4285F4);
  static const blueLight  = Color(0xFF8AB4F8);
  static const blueFrost  = Color(0xFFC2D8F8);
  static const blueDark   = Color(0xFF1557B0);

  static const green      = Color(0xFF34A853);
  static const amber      = Color(0xFFFBBC04);
  static const red        = Color(0xFFEA4335);
  static const orange     = Color(0xFFFB8B24);

  static const text       = Color(0xFF202124);
  static const textSub    = Color(0xFF5F6368);
  static const textDim    = Color(0xFF9AA0A6);
  static const white      = Color(0xFFFFFFFF);

  static const LinearGradient primaryGrad = LinearGradient(
    colors: [Color(0xFF1A73E8), Color(0xFF4285F4)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );
}

class SellerPage extends StatefulWidget {
  final String keyToken;

  const SellerPage({super.key, required this.keyToken});

  @override
  State<SellerPage> createState() => _SellerPageState();
}

class _SellerPageState extends State<SellerPage> {
  List<dynamic> fullUserList = [];
  List<dynamic> filteredList = [];

  final List<String> roleOptions = ['member'];
  String selectedRole = 'member';

  int currentPage = 1;
  int itemsPerPage = 25;

  final createUsernameController = TextEditingController();
  final createPasswordController = TextEditingController();
  final createDayController = TextEditingController();

  final editUsernameController = TextEditingController();
  final editDayController = TextEditingController();

  bool isLoading = false;

  // ─── 3D TEXT (MINECRAFT STYLE) ─────────────────────────────────────────────
  Widget _build3DText(String text, {double size = 16, Color? color}) {
    final textColor = color ?? _C.blue;
    return Stack(
      children: [
        Text(
          text,
          style: TextStyle(
            fontSize: size,
            fontWeight: FontWeight.w900,
            color: Colors.black.withOpacity(0.12),
            letterSpacing: 1,
          ),
        ),
        Transform.translate(
          offset: const Offset(-1.5, -1.5),
          child: Text(
            text,
            style: TextStyle(
              fontSize: size,
              fontWeight: FontWeight.w900,
              color: Colors.white.withOpacity(0.3),
              letterSpacing: 1,
            ),
          ),
        ),
        Transform.translate(
          offset: const Offset(-3, -3),
          child: Text(
            text,
            style: TextStyle(
              fontSize: size,
              fontWeight: FontWeight.w900,
              color: textColor,
              letterSpacing: 1,
              shadows: [
                Shadow(
                  color: textColor.withOpacity(0.3),
                  blurRadius: 12,
                  offset: const Offset(0, 3),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  @override
  void initState() {
    super.initState();
    _fetchUsers();
  }

  Future<void> _fetchUsers() async {
    setState(() => isLoading = true);
    try {
      final res = await http.get(
        Uri.parse('https://recommends-parameter-seating-maine.trycloudflare.com/listUsers?key=${widget.keyToken}'),
      );
      final data = jsonDecode(res.body);
      if (data['valid'] == true && data['authorized'] == true) {
        fullUserList = data['users'] ?? [];
        _filterAndPaginate();
      } else {
        _alert("Info", data['message'] ?? 'Gagal memuat user.');
      }
    } catch (_) {
      _alert("Error", "Gagal terhubung ke server.");
    }
    setState(() => isLoading = false);
  }

  void _filterAndPaginate() {
    setState(() {
      currentPage = 1;
      filteredList = fullUserList
          .where((u) => u['role'] == selectedRole)
          .toList();
    });
  }

  List<dynamic> _getCurrentPageData() {
    final start = (currentPage - 1) * itemsPerPage;
    final end = (start + itemsPerPage);
    return filteredList.sublist(
      start,
      end > filteredList.length ? filteredList.length : end,
    );
  }

  int get totalPages => (filteredList.length / itemsPerPage).ceil();

  Future<void> _createAccount() async {
    final u = createUsernameController.text.trim();
    final p = createPasswordController.text.trim();
    final d = createDayController.text.trim();

    if (u.isEmpty || p.isEmpty || d.isEmpty) {
      _alert("Peringatan", "Semua field wajib diisi.");
      return;
    }

    setState(() => isLoading = true);
    try {
      final res = await http.get(Uri.parse(
          "https://recommends-parameter-seating-maine.trycloudflare.com/createAccount?key=${widget.keyToken}&newUser=$u&pass=$p&day=$d"));
      final data = jsonDecode(res.body);

      if (data['created'] == true) {
        _alert("Sukses", "✅ Akun berhasil dibuat!");
        createUsernameController.clear();
        createPasswordController.clear();
        createDayController.clear();
        _fetchUsers();
      } else {
        String msg = data['message'] ?? 'Gagal membuat akun.';
        if (data['invalidDay'] == true) {
          msg += " (Max 30 hari untuk Reseller)";
        }
        _alert("Gagal", "❌ $msg");
      }
    } catch (e) {
      _alert("Error", "❌ Koneksi error: $e");
    }
    setState(() => isLoading = false);
  }

  Future<void> _editUser() async {
    final u = editUsernameController.text.trim();
    final d = editDayController.text.trim();

    if (u.isEmpty || d.isEmpty) {
      _alert("Peringatan", "Semua field wajib diisi.");
      return;
    }

    setState(() => isLoading = true);
    try {
      final res = await http.get(Uri.parse(
          "https://recommends-parameter-seating-maine.trycloudflare.com/editUser?key=${widget.keyToken}&username=$u&addDays=$d"));
      final data = jsonDecode(res.body);

      if (data['edited'] == true) {
        _alert("Sukses", "✅ Durasi berhasil diperbarui.");
        editUsernameController.clear();
        editDayController.clear();
        _fetchUsers();
      } else {
        _alert("Gagal", "❌ ${data['message'] ?? 'Gagal mengubah durasi.'}");
      }
    } catch (e) {
      _alert("Error", "❌ Koneksi error: $e");
    }
    setState(() => isLoading = false);
  }

  void _alert(String title, String message) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: _C.surface,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
          side: BorderSide(color: title == "Sukses" ? _C.green.withOpacity(0.3) : _C.blue.withOpacity(0.3)),
        ),
        title: Row(
          children: [
            Icon(title == "Sukses" ? Icons.check_circle : Icons.info_outline, 
                 color: title == "Sukses" ? _C.green : _C.blue),
            const SizedBox(width: 10),
            Text(title, style: TextStyle(color: _C.text)),
          ],
        ),
        content: Text(message, style: TextStyle(color: _C.textSub)),
        actions: [
          Center(
            child: Container(
              decoration: BoxDecoration(
                gradient: _C.primaryGrad,
                borderRadius: BorderRadius.circular(12),
              ),
              child: TextButton(
                onPressed: () => Navigator.pop(context),
                child: Text("OK", style: TextStyle(color: _C.white, fontWeight: FontWeight.bold)),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildInput({
    required String label,
    required TextEditingController controller,
    required IconData icon,
    TextInputType type = TextInputType.text,
    String hint = "",
  }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 15),
      child: TextField(
        controller: controller,
        keyboardType: type,
        style: const TextStyle(
          color: Colors.black,
          fontSize: 14,
          fontWeight: FontWeight.w500,
        ),
        decoration: InputDecoration(
          labelText: label,
          hintText: hint,
          hintStyle: TextStyle(color: _C.textDim),
          labelStyle: TextStyle(color: _C.textSub),
          floatingLabelStyle: TextStyle(color: _C.blue),
          prefixIcon: Icon(icon, color: _C.blue),
          filled: true,
          fillColor: Colors.white,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide(color: _C.border),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide(color: _C.border),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide(color: _C.blue, width: 1.5),
          ),
          contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
        ),
      ),
    );
  }

  Widget _buildGlassCard({
    required String title,
    required IconData icon,
    required List<Widget> children,
  }) {
    return Container(
      margin: const EdgeInsets.only(bottom: 20),
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: _C.surface,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: _C.border),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.04),
            blurRadius: 15,
            offset: const Offset(0, 5),
          ),
          BoxShadow(
            color: Colors.white.withOpacity(0.6),
            blurRadius: 10,
            offset: const Offset(-2, -2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: _C.blue.withOpacity(0.08),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Icon(icon, color: _C.blue),
              ),
              const SizedBox(width: 12),
              _build3DText(title, size: 16, color: _C.blue),
            ],
          ),
          const SizedBox(height: 20),
          ...children,
        ],
      ),
    );
  }

  Widget _buildUserItem(Map user) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      decoration: BoxDecoration(
        color: _C.bg,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: _C.border),
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: _C.blue.withOpacity(0.08),
              shape: BoxShape.circle,
            ),
            child: Icon(Icons.person, color: _C.blue, size: 18),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  user['username'],
                  style: TextStyle(
                    color: _C.text,
                    fontWeight: FontWeight.bold,
                    fontSize: 14,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  "ROLE: ${user['role'].toString().toUpperCase()} | EXP: ${user['expiredDate']}",
                  style: TextStyle(color: _C.textSub, fontSize: 11),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ─── FIXED: _buildPagination ──────────────────────────────────────────────
  Widget _buildPagination() {
    if (totalPages <= 1) return const SizedBox();
    
    return Wrap(
      spacing: 6,
      runSpacing: 6,
      alignment: WrapAlignment.center,
      children: [
        // Prev
        if (currentPage > 1)
          _buildPageButton(currentPage - 1, icon: Icons.chevron_left),
        // Pages
        ...List.generate(totalPages, (index) {
          final page = index + 1;
          final isActive = currentPage == page;
          return _buildPageButton(page, isActive: isActive);
        }),
        // Next
        if (currentPage < totalPages)
          _buildPageButton(currentPage + 1, icon: Icons.chevron_right),
      ],
    );
  }

  // ─── FIXED: _buildPageButton ──────────────────────────────────────────────
  Widget _buildPageButton(int page, {IconData? icon, bool isActive = false}) {
    return GestureDetector(
      onTap: () => setState(() => currentPage = page),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        width: icon != null ? 36 : 32,
        height: 32,
        decoration: BoxDecoration(
          color: isActive ? _C.blue : _C.bg,
          borderRadius: BorderRadius.circular(8),
          border: Border.all(
            color: isActive ? _C.blue : _C.border,
            width: isActive ? 1.5 : 1,
          ),
          boxShadow: isActive ? [
            BoxShadow(
              color: _C.blue.withOpacity(0.3),
              blurRadius: 8,
              offset: const Offset(0, 2),
            ),
          ] : null,
        ),
        child: Center(
          child: icon != null
              ? Icon(icon, color: isActive ? _C.white : _C.textSub, size: 16)
              : Text(
                  '$page',
                  style: TextStyle(
                    color: isActive ? _C.white : _C.textSub,
                    fontWeight: isActive ? FontWeight.w700 : FontWeight.w400,
                    fontSize: 12,
                  ),
                ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _C.bg,
      appBar: AppBar(
        title: _build3DText("Seller Dashboard", size: 18),
        backgroundColor: _C.surface,
        elevation: 0,
        centerTitle: true,
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(1),
          child: Container(height: 1, color: _C.border),
        ),
        leading: IconButton(
          icon: Icon(Icons.arrow_back_ios_new_rounded, color: _C.textSub),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: SingleChildScrollView(
        physics: const BouncingScrollPhysics(),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            // Header Icon
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: _C.surface,
                shape: BoxShape.circle,
                boxShadow: [
                  BoxShadow(
                    color: _C.blue.withOpacity(0.2),
                    blurRadius: 20,
                    spreadRadius: 2,
                  ),
                  BoxShadow(
                    color: Colors.white.withOpacity(0.6),
                    blurRadius: 8,
                    offset: const Offset(-2, -2),
                  ),
                ],
              ),
              child: Icon(Icons.storefront, color: _C.blue, size: 36),
            ),
            const SizedBox(height: 12),

            _buildGlassCard(
              title: "CREATE MEMBER",
              icon: FontAwesomeIcons.userPlus,
              children: [
                _buildInput(
                  label: "Username Baru",
                  controller: createUsernameController,
                  icon: FontAwesomeIcons.user,
                ),
                _buildInput(
                  label: "Password",
                  controller: createPasswordController,
                  icon: FontAwesomeIcons.lock,
                ),
                _buildInput(
                  label: "Durasi (Hari)",
                  controller: createDayController,
                  icon: FontAwesomeIcons.calendarDay,
                  type: TextInputType.number,
                  hint: "Maksimal 30 hari",
                ),
                const SizedBox(height: 10),
                _buildActionButton(
                  label: "CREATE ACCOUNT",
                  icon: Icons.add,
                  isLoading: isLoading,
                  onPressed: _createAccount,
                ),
              ],
            ),

            _buildGlassCard(
              title: "EXTEND DURATION",
              icon: FontAwesomeIcons.clock,
              children: [
                _buildInput(
                  label: "Username Target",
                  controller: editUsernameController,
                  icon: FontAwesomeIcons.userEdit,
                  hint: "Username member yang ingin diperpanjang",
                ),
                _buildInput(
                  label: "Tambah Hari",
                  controller: editDayController,
                  icon: FontAwesomeIcons.calendarPlus,
                  type: TextInputType.number,
                  hint: "Maksimal 30 hari",
                ),
                const SizedBox(height: 10),
                _buildActionButton(
                  label: "ADD DAYS",
                  icon: Icons.add,
                  isLoading: isLoading,
                  onPressed: _editUser,
                ),
              ],
            ),

            _buildGlassCard(
              title: "MEMBER LIST",
              icon: FontAwesomeIcons.users,
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                  decoration: BoxDecoration(
                    color: _C.bg,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: _C.border),
                  ),
                  child: DropdownButtonHideUnderline(
                    child: DropdownButton<String>(
                      value: selectedRole,
                      dropdownColor: _C.surface,
                      style: TextStyle(color: _C.text, fontSize: 14),
                      icon: Icon(Icons.expand_more, color: _C.textSub),
                      items: roleOptions.map((role) {
                        return DropdownMenuItem(
                          value: role,
                          child: Text(role.toUpperCase()),
                        );
                      }).toList(),
                      onChanged: (val) {
                        if (val != null) {
                          selectedRole = val;
                          _filterAndPaginate();
                        }
                      },
                    ),
                  ),
                ),
                const SizedBox(height: 16),
                if (isLoading)
                  const Center(
                    child: SizedBox(
                      width: 30,
                      height: 30,
                      child: CircularProgressIndicator(color: _C.blue),
                    ),
                  )
                else if (filteredList.isEmpty)
                  Center(
                    child: Text(
                      "Tidak ada user dengan role ini",
                      style: TextStyle(color: _C.textSub, fontSize: 13),
                    ),
                  )
                else
                  Column(
                    children: [
                      ..._getCurrentPageData()
                          .map((u) => _buildUserItem(u))
                          .toList(),
                      const SizedBox(height: 16),
                      _buildPagination(),
                    ],
                  ),
              ],
            ),
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }

  Widget _buildActionButton({
    required String label,
    required IconData icon,
    required bool isLoading,
    required VoidCallback onPressed,
  }) {
    return Container(
      height: 46,
      decoration: BoxDecoration(
        gradient: _C.primaryGrad,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: _C.blue.withOpacity(0.3),
            blurRadius: 12,
            offset: const Offset(0, 4),
          ),
          BoxShadow(
            color: Colors.white.withOpacity(0.6),
            blurRadius: 6,
            offset: const Offset(-2, -2),
          ),
        ],
      ),
      child: ElevatedButton(
        onPressed: isLoading ? null : onPressed,
        style: ElevatedButton.styleFrom(
          backgroundColor: Colors.transparent,
          shadowColor: Colors.transparent,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
          padding: const EdgeInsets.symmetric(horizontal: 20),
        ),
        child: isLoading
            ? SizedBox(
                width: 20,
                height: 20,
                child: CircularProgressIndicator(
                  strokeWidth: 2,
                  color: _C.white,
                ),
              )
            : Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(icon, size: 18, color: _C.white),
                  const SizedBox(width: 8),
                  Text(
                    label,
                    style: const TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.w700,
                      letterSpacing: 0.5,
                      fontSize: 13,
                    ),
                  ),
                ],
              ),
      ),
    );
  }
}