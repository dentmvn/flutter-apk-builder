// DASHBOARD_PAGE.DART

import 'chat_public.dart';
import 'dart:convert';
import 'dart:io';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:web_socket_channel/status.dart' as status;
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:video_player/video_player.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:http/http.dart' as http;
import 'package:audioplayers/audioplayers.dart';

import 'nik_check.dart';
import 'admin_page.dart';
import 'owner_page.dart';
import 'home_page.dart';
import 'seller_page.dart';
import 'change_password_page.dart';
import 'tools_gateway.dart';
import 'login_page.dart';
import 'bug_sender.dart';
import 'contact_page.dart';
import 'profile_page.dart';
import 'riwayat_page.dart';
import 'info_page.dart';

// ─── TEMA WARNA PUTIH X BIRU NEW ─────────────────────────────────────────────
class _C {
  static const bg        = Color(0xFFE8EDF2);
  static const surface   = Color(0xFFFFFFFF);
  static const card      = Color(0xFFFFFFFF);
  static const border    = Color(0xFFD4DCE4);
  static const borderLit = Color(0xFFC8D0D8);

  static const blue        = Color(0xFF1A73E8);
  static const blueMid     = Color(0xFF4285F4);
  static const blueLight   = Color(0xFF8AB4F8);
  static const blueFrost   = Color(0xFFC2D8F8);
  static const blueDark    = Color(0xFF1557B0);

  static const green     = Color(0xFF34A853);
  static const amber     = Color(0xFFFBBC04);
  static const gold      = Color(0xFFC9A94E); // <-- TAMBAHKAN INI
  static const red       = Color(0xFFEA4335);

  static const text      = Color(0xFF202124);
  static const textSub   = Color(0xFF5F6368);
  static const textDim   = Color(0xFF9AA0A6);
  static const white     = Color(0xFFFFFFFF);

  static const LinearGradient btnGrad = LinearGradient(
    colors: [Color(0xFF1A73E8), Color(0xFF4285F4)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );
  
  static const LinearGradient btnGradRed = LinearGradient(
    colors: [Color(0xFFD93025), Color(0xFFEA4335)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );
}

// ─── ROLE HELPERS ─────────────────────────────────────────────────────────────
Color _roleColor(String role) {
  switch (role.toLowerCase()) {
    case 'owner':   return const Color(0xFF1A73E8);
    case 'admin':   return const Color(0xFFEA4335);
    case 'reseller':return const Color(0xFF34A853);
    case 'vip':     return const Color(0xFFFBBC04);
    default:        return _C.blue;
  }
}

IconData _roleIcon(String role) {
  switch (role.toLowerCase()) {
    case 'owner':   return Icons.workspace_premium_rounded;
    case 'admin':   return Icons.admin_panel_settings_rounded;
    case 'reseller':return Icons.storefront_rounded;
    case 'vip':     return Icons.star_rounded;
    default:        return Icons.person_rounded;
  }
}

// ─── JADWAL SHOLAT (MINI) ────────────────────────────────────────────────────
class PrayerTime {
  final String name;
  final String time;
  PrayerTime({required this.name, required this.time});
}

class PrayerTimesProvider extends ChangeNotifier {
  String _selectedZone = "WIB";
  List<PrayerTime> _prayerTimes = [];
  bool _isLoading = false;
  String _errorMessage = '';
  DateTime _lastUpdate = DateTime.now();

  String get selectedZone => _selectedZone;
  List<PrayerTime> get prayerTimes => _prayerTimes;
  bool get isLoading => _isLoading;
  String get errorMessage => _errorMessage;
  DateTime get lastUpdate => _lastUpdate;

  void setZone(String zone) {
    _selectedZone = zone;
    fetchPrayerTimes();
  }

  Future<void> fetchPrayerTimes() async {
    _isLoading = true;
    _errorMessage = '';
    notifyListeners();

    try {
      String city = "";
      switch (_selectedZone) {
        case "WIB": city = "Jakarta"; break;
        case "WITA": city = "Makassar"; break;
        case "WIT": city = "Jayapura"; break;
      }
      
      final response = await http.get(
        Uri.parse("https://api.aladhan.com/v1/timingsByCity?city=$city&country=Indonesia&method=2"),
      ).timeout(const Duration(seconds: 10));
      
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        final timings = data['data']['timings'];
        
        _prayerTimes = [
          PrayerTime(name: "Imsak", time: _formatTime(timings['Imsak'])),
          PrayerTime(name: "Subuh", time: _formatTime(timings['Fajr'])),
          PrayerTime(name: "Dzuhur", time: _formatTime(timings['Dhuhr'])),
          PrayerTime(name: "Ashar", time: _formatTime(timings['Asr'])),
          PrayerTime(name: "Maghrib", time: _formatTime(timings['Maghrib'])),
          PrayerTime(name: "Isya", time: _formatTime(timings['Isha'])),
        ];
        _lastUpdate = DateTime.now();
        _isLoading = false;
        notifyListeners();
      } else {
        _errorMessage = "Gagal mengambil data";
        _isLoading = false;
        notifyListeners();
      }
    } catch (e) {
      _errorMessage = "Error: ${e.toString()}";
      _isLoading = false;
      notifyListeners();
    }
  }
  
  String _formatTime(String time) {
    if (time.contains(':')) {
      final parts = time.split(':');
      if (parts.length >= 2) {
        return "${parts[0]}:${parts[1]}";
      }
    }
    return time;
  }
}

// ─── PRAYER TIMES WIDGET (MINI) ──────────────────────────────────────────────
class PrayerTimesWidget extends StatelessWidget {
  final PrayerTimesProvider provider;
  
  const PrayerTimesWidget({super.key, required this.provider});
  
  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: _C.surface,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: _C.border),
        boxShadow: [
          BoxShadow(color: Colors.black.withOpacity(0.04), blurRadius: 8, offset: const Offset(0, 2)),
          BoxShadow(color: Colors.white.withOpacity(0.6), blurRadius: 6, offset: const Offset(-1, -1)),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(width: 3, height: 12, decoration: BoxDecoration(gradient: _C.btnGrad, borderRadius: BorderRadius.circular(1))),
              const SizedBox(width: 6),
              const Text('Jadwal Sholat', style: TextStyle(color: _C.text, fontSize: 11, fontWeight: FontWeight.w700)),
              const Spacer(),
              Icon(Icons.access_time, color: _C.blue, size: 12),
              const SizedBox(width: 4),
              Text(_formatLastUpdate(provider.lastUpdate), style: const TextStyle(color: _C.textDim, fontSize: 8)),
            ],
          ),
          const SizedBox(height: 6),
          
          Row(
            children: [
              _buildZoneBtn("WIB", provider.selectedZone == "WIB", () => provider.setZone("WIB")),
              const SizedBox(width: 6),
              _buildZoneBtn("WITA", provider.selectedZone == "WITA", () => provider.setZone("WITA")),
              const SizedBox(width: 6),
              _buildZoneBtn("WIT", provider.selectedZone == "WIT", () => provider.setZone("WIT")),
            ],
          ),
          const SizedBox(height: 6),
          
          if (provider.isLoading)
            const Center(child: SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2, color: _C.blue)))
          else if (provider.errorMessage.isNotEmpty)
            Center(child: Text(provider.errorMessage, style: const TextStyle(color: _C.red, fontSize: 9)))
          else
            GridView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 3,
                childAspectRatio: 2.2,
                crossAxisSpacing: 4,
                mainAxisSpacing: 4,
              ),
              itemCount: provider.prayerTimes.length,
              itemBuilder: (context, index) {
                final prayer = provider.prayerTimes[index];
                final isNext = _isNextPrayer(prayer.time);
                return Container(
                  padding: const EdgeInsets.symmetric(vertical: 2),
                  decoration: BoxDecoration(
                    color: isNext ? _C.blue.withOpacity(0.08) : _C.bg,
                    borderRadius: BorderRadius.circular(6),
                    border: Border.all(color: isNext ? _C.blue : _C.border, width: isNext ? 1 : 0.5),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(prayer.name, style: TextStyle(color: isNext ? _C.blue : _C.textSub, fontSize: 8, fontWeight: isNext ? FontWeight.w700 : FontWeight.w400)),
                      const SizedBox(width: 4),
                      Text(prayer.time, style: TextStyle(color: isNext ? _C.blue : _C.text, fontSize: 10, fontWeight: FontWeight.bold)),
                    ],
                  ),
                );
              },
            ),
        ],
      ),
    );
  }
  
  Widget _buildZoneBtn(String label, bool isActive, VoidCallback onTap) {
    return Expanded(
      child: GestureDetector(
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 3),
          decoration: BoxDecoration(
            color: isActive ? _C.blue.withOpacity(0.08) : _C.bg,
            borderRadius: BorderRadius.circular(6),
            border: Border.all(color: isActive ? _C.blue : _C.border),
          ),
          child: Text(label, textAlign: TextAlign.center,
              style: TextStyle(color: isActive ? _C.blue : _C.textSub, fontWeight: isActive ? FontWeight.w700 : FontWeight.w400, fontSize: 9)),
        ),
      ),
    );
  }
  
  bool _isNextPrayer(String time) {
    final now = DateTime.now();
    final nowHour = now.hour;
    final nowMinute = now.minute;
    final timeParts = time.split(':');
    if (timeParts.length >= 2) {
      final prayerHour = int.tryParse(timeParts[0]) ?? 0;
      final prayerMinute = int.tryParse(timeParts[1]) ?? 0;
      if (prayerHour > nowHour) return true;
      if (prayerHour == nowHour && prayerMinute > nowMinute) return true;
    }
    return false;
  }
  
  String _formatLastUpdate(DateTime dt) {
    final hour = dt.hour.toString().padLeft(2, '0');
    final minute = dt.minute.toString().padLeft(2, '0');
    return "$hour:$minute";
  }
}

// ─── DASHBOARD PAGE ──────────────────────────────────────────────────────────
class DashboardPage extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listDoos;
  final List<dynamic> news;

  const DashboardPage({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.listBug,
    required this.listDoos,
    required this.sessionKey,
    required this.news,
  });

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage>
    with TickerProviderStateMixin {
  late String sessionKey, username, password, role, expiredDate;
  late List<Map<String, dynamic>> listBug, listDoos;
  late List<dynamic> newsList;

  late WebSocketChannel channel;
  String androidId    = 'unknown';
  File?  _profileImage;
  VideoPlayerController? _menuVideoCtrl;

  int _navIndex      = 0;
  Widget _body       = const SizedBox();
  int onlineUsers    = 0;
  int activeConns    = 0;

  late PrayerTimesProvider _prayerProvider;

  late AnimationController _bgCtrl;
  late AnimationController _pageCtrl;

  late Animation<double> _pageFade;
  late Animation<Offset>  _pageSlide;

  final PageController _newsPageCtrl = PageController(viewportFraction: 0.88);
  int _newsPage = 0;

  final ScrollController _updateScrollCtrl = ScrollController();
  bool _showLeftArrow = false;
  bool _showRightArrow = true;

  // ─── MUSIC PLAYER ──────────────────────────────────────────────────────────
  late AudioPlayer _audioPlayer;
  bool _isPlaying = false;
  int _currentIndex = 0;
  bool _isLoading = false;

  // ─── WELCOME VIDEO ─────────────────────────────────────────────────────────
  late VideoPlayerController _welcomeVideoCtrl;
  bool _isWelcomeVideoPlaying = false;

  // ─── DAFTAR LAGU (LINK DARI CATBOX) ──────────────────────────────────────
  final List<String> _songUrls = [
    'https://files.catbox.moe/vaht0e.mp3',
    'https://files.catbox.moe/ulz300.mp3',
    'https://files.catbox.moe/cocu6u.mp3',
    'https://files.catbox.moe/mu1thg.mp3',
    'https://files.catbox.moe/pl42b6.mp3',
  ];

  final List<Map<String, String>> _playlist = const [
    {'title': 'Lagu 1', 'artist': 'Unknown'},
    {'title': 'Lagu 2', 'artist': 'Unknown'},
    {'title': 'Lagu 3', 'artist': 'Unknown'},
    {'title': 'Lagu 4', 'artist': 'Unknown'},
    {'title': 'Lagu 5', 'artist': 'Unknown'},
  ];
  
  String _currentSongTitle = 'Select a song';

  // ─── MUSIC FUNCTIONS ──────────────────────────────────────────────────────
  void _onPlayerComplete() {
    if (mounted) _nextSong();
  }

  void _togglePlayPause() async {
    if (_isLoading) return;

    if (_isPlaying) {
      await _audioPlayer.pause();
      setState(() => _isPlaying = false);
    } else {
      setState(() => _isLoading = true);
      try {
        final url = _songUrls[_currentIndex];
        await _audioPlayer.play(UrlSource(url));
        setState(() {
          _isPlaying = true;
          _isLoading = false;
          _currentSongTitle = _playlist[_currentIndex]['title']!;
        });
      } catch (e) {
        print('❌ Error playing: $e');
        setState(() => _isLoading = false);
        _nextSong();
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('⚠️ Gagal memutar, lanjut ke next...'),
              backgroundColor: Colors.orange,
              duration: Duration(seconds: 2),
            ),
          );
        }
      }
    }
  }

  void _nextSong() {
    setState(() {
      _currentIndex = (_currentIndex + 1) % _songUrls.length;
      _currentSongTitle = _playlist[_currentIndex]['title']!;
      _isPlaying = false;
      _isLoading = false;
    });
    Future.delayed(const Duration(milliseconds: 300), () {
      if (mounted && !_isPlaying) {
        _togglePlayPause();
      }
    });
  }

  void _prevSong() {
    setState(() {
      _currentIndex = (_currentIndex - 1) % _songUrls.length;
      if (_currentIndex < 0) _currentIndex = _songUrls.length - 1;
      _currentSongTitle = _playlist[_currentIndex]['title']!;
      _isPlaying = false;
      _isLoading = false;
    });
    Future.delayed(const Duration(milliseconds: 300), () {
      if (mounted && !_isPlaying) {
        _togglePlayPause();
      }
    });
  }

  // ─── WELCOME VIDEO FUNCTIONS ─────────────────────────────────────────────
  void _toggleWelcomeVideo() {
    if (_welcomeVideoCtrl.value.isInitialized) {
      setState(() {
        if (_welcomeVideoCtrl.value.isPlaying) {
          _welcomeVideoCtrl.pause();
          _isWelcomeVideoPlaying = false;
        } else {
          _welcomeVideoCtrl.play();
          _isWelcomeVideoPlaying = true;
        }
      });
    }
  }

  @override
  void initState() {
    super.initState();
    
    _audioPlayer = AudioPlayer();
    
    _audioPlayer.onPlayerComplete.listen((event) {
      if (mounted) _onPlayerComplete();
    });

    // ─── INIT WELCOME VIDEO ──────────────────────────────────────────────────
    _welcomeVideoCtrl = VideoPlayerController.asset('assets/videos/welcome.mp4')
      ..initialize().then((_) {
        if (mounted) setState(() {});
        _welcomeVideoCtrl.setLooping(true);
        _welcomeVideoCtrl.setVolume(0);
        _welcomeVideoCtrl.play();
        setState(() => _isWelcomeVideoPlaying = true);
      });

    sessionKey  = widget.sessionKey;
    username    = widget.username;
    password    = widget.password;
    role        = widget.role;
    expiredDate = widget.expiredDate;
    listBug     = widget.listBug;
    listDoos    = widget.listDoos;
    newsList    = widget.news;

    _prayerProvider = PrayerTimesProvider();
    _prayerProvider.fetchPrayerTimes();

    _bgCtrl = AnimationController(
      vsync: this, duration: const Duration(seconds: 20),
    )..repeat();

    _pageCtrl = AnimationController(
      vsync: this, duration: const Duration(milliseconds: 400),
    );
    _pageFade  = CurvedAnimation(parent: _pageCtrl, curve: Curves.easeOut);
    _pageSlide = Tween<Offset>(begin: const Offset(0, 0.04), end: Offset.zero)
        .animate(CurvedAnimation(parent: _pageCtrl, curve: Curves.easeOutCubic));

    _body = _newsPage_();
    _pageCtrl.forward();

    _initAndroidId();
    _loadProfileImage();
    _initMenuVideo();

    _updateScrollCtrl.addListener(_updateScrollArrows);

    _currentSongTitle = _playlist[0]['title']!;
  }

  @override
  void dispose() {
    _audioPlayer.dispose();
    _welcomeVideoCtrl.dispose();
    channel.sink.close(status.goingAway);
    _bgCtrl.dispose();
    _pageCtrl.dispose();
    _menuVideoCtrl?.dispose();
    _newsPageCtrl.dispose();
    _prayerProvider.dispose();
    _updateScrollCtrl.removeListener(_updateScrollArrows);
    _updateScrollCtrl.dispose();
    super.dispose();
  }

  void _updateScrollArrows() {
    setState(() {
      if (_updateScrollCtrl.hasClients) {
        _showLeftArrow = _updateScrollCtrl.position.pixels > 10;
        _showRightArrow = _updateScrollCtrl.position.pixels < 
            _updateScrollCtrl.position.maxScrollExtent - 10;
      }
    });
  }

  Future<void> _loadProfileImage() async {
    final prefs = await SharedPreferences.getInstance();
    final path  = prefs.getString('profile_image_$username');
    if (path != null && path.isNotEmpty && mounted) {
      setState(() => _profileImage = File(path));
    }
  }

  void _initMenuVideo() {
    _menuVideoCtrl = VideoPlayerController.asset('assets/videos/banner.mp4')
      ..initialize().then((_) {
        if (mounted) setState(() {});
        _menuVideoCtrl?.setLooping(true);
        _menuVideoCtrl?.play();
      });
  }

  Future<void> _initAndroidId() async {
    final info = await DeviceInfoPlugin().androidInfo;
    androidId = info.id;
    _connectWS();
  }

  void _connectWS() {
    channel = WebSocketChannel.connect(
        Uri.parse('https://recommends-parameter-seating-maine.trycloudflare.com'));
    channel.sink.add(jsonEncode({
      'type': 'validate', 'key': sessionKey, 'androidId': androidId,
    }));
    channel.sink.add(jsonEncode({'type': 'stats'}));

    channel.stream.listen((event) {
      final data = jsonDecode(event);
      if (data['type'] == 'myInfo' && data['valid'] == false) {
        final reason = data['reason'];
        _handleInvalidSession(reason == 'androidIdMismatch'
            ? 'Akun ini login di perangkat lain.'
            : 'Sesi tidak valid. Silakan login ulang.');
      }
      if (data['type'] == 'stats' && mounted) {
        setState(() {
          onlineUsers  = data['onlineUsers']       ?? 0;
          activeConns  = data['activeConnections'] ?? 0;
        });
      }
    });
  }

  Future<void> _openUrl(String url) async {
    await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
  }

  void _handleInvalidSession(String message) async {
    await Future.delayed(const Duration(milliseconds: 300));
    final prefs = await SharedPreferences.getInstance();
    await prefs.clear();
    if (!mounted) return;
    _showSystemDialog(
      title: 'Sesi Berakhir',
      message: message,
      icon: Icons.lock_outline_rounded,
      color: _C.btnGradRed.colors.first,
      onOk: () => Navigator.of(context).pushAndRemoveUntil(
        MaterialPageRoute(builder: (_) => const LoginPage()),
        (_) => false,
      ),
    );
  }

  void _navigate(Widget page) {
    setState(() => _body = page);
    _pageCtrl.forward(from: 0);
  }

  void _onNavTap(int index) {
    setState(() => _navIndex = index);
    switch (index) {
      case 0:
        _navigate(_newsPage_());
        break;
      case 1:
        _navigate(HomePage(
          username: username, password: password,
          listBug: listBug, role: role,
          expiredDate: expiredDate, sessionKey: sessionKey,
        ));
        break;
      case 2:
        _navigate(InfoPage(sessionKey: sessionKey));
        break;
      case 3:
        _navigate(ToolsPage(
            sessionKey: sessionKey, userRole: role, listDoos: listDoos));
        break;
    }
  }

  void _onDrawerNav(int index) {
    Navigator.pop(context);
    switch (index) {
      case 1: _navigate(SellerPage(keyToken: sessionKey)); break;
      case 2: _navigate(OwnerPage(sessionKey: sessionKey, username: username)); break;
    }
  }

  void _showSystemDialog({
    required String title,
    required String message,
    required IconData icon,
    required Color color,
    VoidCallback? onOk,
  }) {
    showGeneralDialog(
      context: context,
      barrierDismissible: false,
      barrierLabel: '',
      barrierColor: Colors.black54,
      transitionDuration: const Duration(milliseconds: 320),
      transitionBuilder: (_, anim, __, child) => ScaleTransition(
        scale: CurvedAnimation(parent: anim, curve: Curves.easeOutBack),
        child: FadeTransition(opacity: anim, child: child),
      ),
      pageBuilder: (ctx, _, __) => Dialog(
        backgroundColor: Colors.transparent,
        insetPadding: const EdgeInsets.symmetric(horizontal: 28),
        child: Container(
          decoration: BoxDecoration(
            color: _C.surface,
            borderRadius: BorderRadius.circular(24),
            border: Border.all(color: color.withOpacity(0.3), width: 1.5),
            boxShadow: [
              BoxShadow(color: color.withOpacity(0.15), blurRadius: 50),
              BoxShadow(color: Colors.white.withOpacity(0.6), blurRadius: 20, offset: const Offset(-2, -2)),
            ],
          ),
          padding: const EdgeInsets.all(28),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Container(
              width: 56, height: 56,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: color.withOpacity(0.1),
                border: Border.all(color: color.withOpacity(0.3)),
              ),
              child: Icon(icon, color: color, size: 26),
            ),
            const SizedBox(height: 16),
            Text(title,
                style: const TextStyle(
                    color: _C.text, fontSize: 18, fontWeight: FontWeight.w800)),
            const SizedBox(height: 8),
            Text(message,
                textAlign: TextAlign.center,
                style: const TextStyle(
                    color: _C.textSub, fontSize: 13, height: 1.5)),
            const SizedBox(height: 24),
            _GradBtn(label: 'OK', fullWidth: true, onTap: () {
              Navigator.pop(ctx);
              onOk?.call();
            }),
          ]),
        ),
      ),
    );
  }

  // ─── MUSIC PLAYER WIDGET ──────────────────────────────────────────────────
  Widget _buildMusicPlayer() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16),
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: BoxDecoration(
        color: _C.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: _C.border),
        boxShadow: [
          BoxShadow(color: Colors.black.withOpacity(0.04), blurRadius: 10, offset: const Offset(0, 4)),
          BoxShadow(color: Colors.white.withOpacity(0.6), blurRadius: 8, offset: const Offset(-2, -2)),
        ],
      ),
      child: Row(
        children: [
          Container(
            width: 50,
            height: 50,
            decoration: BoxDecoration(
              gradient: _C.btnGrad,
              borderRadius: BorderRadius.circular(12),
              boxShadow: [
                BoxShadow(color: _C.blue.withOpacity(0.3), blurRadius: 10, offset: const Offset(0, 4)),
                BoxShadow(color: Colors.white.withOpacity(0.6), blurRadius: 6, offset: const Offset(-2, -2)),
              ],
            ),
            child: _isLoading
                ? const Center(
                    child: SizedBox(
                      width: 20,
                      height: 20,
                      child: CircularProgressIndicator(
                        color: Colors.white,
                        strokeWidth: 2,
                      ),
                    ),
                  )
                : Icon(
                    _isPlaying ? Icons.music_note_rounded : Icons.music_off_rounded,
                    color: Colors.white,
                    size: 24,
                  ),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Text(
                      _isPlaying ? '🎵 Now Playing' : '⏸️ Paused',
                      style: TextStyle(
                        color: _isPlaying ? _C.green : _C.textSub,
                        fontSize: 10,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    const SizedBox(width: 8),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                      decoration: BoxDecoration(
                        color: _C.blue.withOpacity(0.08),
                        borderRadius: BorderRadius.circular(4),
                        border: Border.all(color: _C.blue.withOpacity(0.2)),
                      ),
                      child: Text(
                        '${_currentIndex + 1}/${_playlist.length}',
                        style: TextStyle(color: _C.blue, fontSize: 8, fontWeight: FontWeight.w700),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 2),
                Text(
                  _currentSongTitle,
                  style: const TextStyle(
                    color: _C.text,
                    fontSize: 14,
                    fontWeight: FontWeight.w700,
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
                Text(
                  _playlist[_currentIndex]['artist'] ?? '',
                  style: const TextStyle(
                    color: _C.textSub,
                    fontSize: 10,
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ],
            ),
          ),
          Row(
            children: [
              _MusicControlBtn(
                icon: Icons.skip_previous_rounded,
                onTap: _prevSong,
              ),
              _MusicControlBtn(
                icon: _isPlaying ? Icons.pause_rounded : Icons.play_arrow_rounded,
                onTap: _togglePlayPause,
                isMain: true,
              ),
              _MusicControlBtn(
                icon: Icons.skip_next_rounded,
                onTap: _nextSong,
              ),
            ],
          ),
        ],
      ),
    );
  }

  // ─── WELCOME VIDEO WIDGET ─────────────────────────────────────────────────
  Widget _buildWelcomeVideo() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16),
      decoration: BoxDecoration(
        color: _C.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: _C.border),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.04),
            blurRadius: 12,
            offset: const Offset(0, 4),
          ),
          BoxShadow(
            color: Colors.white.withOpacity(0.6),
            blurRadius: 8,
            offset: const Offset(-2, -2),
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(16),
        child: Stack(
          children: [
            if (_welcomeVideoCtrl.value.isInitialized)
              AspectRatio(
                aspectRatio: _welcomeVideoCtrl.value.aspectRatio,
                child: VideoPlayer(_welcomeVideoCtrl),
              )
            else
              Container(
                height: 180,
                color: _C.bg,
                child: const Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      SizedBox(
                        width: 30,
                        height: 30,
                        child: CircularProgressIndicator(
                          color: _C.blue,
                          strokeWidth: 2,
                        ),
                      ),
                      SizedBox(height: 10),
                      Text(
                        'Memuat Video...',
                        style: TextStyle(
                          color: _C.textSub,
                          fontSize: 12,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            Positioned.fill(
              child: Material(
                color: Colors.transparent,
                child: InkWell(
                  onTap: _toggleWelcomeVideo,
                  child: Container(
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                        colors: [
                          Colors.transparent,
                          Colors.black.withOpacity(0.1),
                        ],
                      ),
                    ),
                    child: Center(
                      child: Container(
                        width: 50,
                        height: 50,
                        decoration: BoxDecoration(
                          color: Colors.white.withOpacity(0.9),
                          shape: BoxShape.circle,
                          boxShadow: [
                            BoxShadow(
                              color: Colors.black.withOpacity(0.2),
                              blurRadius: 12,
                              offset: const Offset(0, 4),
                            ),
                          ],
                        ),
                        child: Icon(
                          _isWelcomeVideoPlaying
                              ? Icons.pause_rounded
                              : Icons.play_arrow_rounded,
                          color: _C.blue,
                          size: 28,
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              bottom: 0,
              left: 0,
              right: 0,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [
                      Colors.transparent,
                      Colors.black.withOpacity(0.5),
                    ],
                  ),
                ),
                child: Row(
                  children: [
                    Container(
                      width: 3,
                      height: 14,
                      decoration: BoxDecoration(
                        color: _C.gold, // <-- SEKARANG _C.gold TERSEDIA
                        borderRadius: BorderRadius.circular(2),
                      ),
                    ),
                    const SizedBox(width: 10),
                    const Text(
                      'WELCOME TO APPS VOLCANIC',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 12,
                        fontWeight: FontWeight.w700,
                        letterSpacing: 0.5,
                      ),
                    ),
                    const Spacer(),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                      decoration: BoxDecoration(
                        color: Colors.white.withOpacity(0.15),
                        borderRadius: BorderRadius.circular(6),
                        border: Border.all(color: Colors.white.withOpacity(0.2)),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(
                            _isWelcomeVideoPlaying
                                ? Icons.pause_rounded
                                : Icons.play_arrow_rounded,
                            color: Colors.white,
                            size: 12,
                          ),
                          const SizedBox(width: 4),
                          Text(
                            _isWelcomeVideoPlaying ? 'Pause' : 'Play',
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 9,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ─── NEWS PAGE ────────────────────────────────────────────────────────────
  Widget _newsPage_() {
    return SingleChildScrollView(
      physics: const BouncingScrollPhysics(),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const SizedBox(height: 8),

          _StatsStrip(online: onlineUsers, connections: activeConns),
          const SizedBox(height: 16),

          _buildUpdateScroll(),
          const SizedBox(height: 16),

          _buildWelcomeVideo(),
          const SizedBox(height: 16),

          _buildChatPublicButton(),
          const SizedBox(height: 12),

          _buildMusicPlayer(),
          const SizedBox(height: 16),

          _buildScaryText(),
          const SizedBox(height: 12),

          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: Row(children: [
              Container(
                width: 4, height: 18,
                decoration: BoxDecoration(
                  gradient: _C.btnGrad,
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
              const SizedBox(width: 10),
              const Text('Berita Terbaru',
                  style: TextStyle(
                      color: _C.text, fontSize: 15, fontWeight: FontWeight.w700)),
              const Spacer(),
              Text('${newsList.length} artikel',
                  style: const TextStyle(color: _C.textSub, fontSize: 11)),
            ]),
          ),
          const SizedBox(height: 14),

          if (newsList.isNotEmpty) ...[
            SizedBox(
              height: 210,
              child: PageView.builder(
                controller: _newsPageCtrl,
                onPageChanged: (i) => setState(() => _newsPage = i),
                itemCount: newsList.length,
                itemBuilder: (_, i) {
                  final item = newsList[i];
                  final isActive = i == _newsPage;
                  return AnimatedScale(
                    scale: isActive ? 1.0 : 0.94,
                    duration: const Duration(milliseconds: 300),
                    curve: Curves.easeOutCubic,
                    child: _NewsCard(
                      item: item,
                      isActive: isActive,
                    ),
                  );
                },
              ),
            ),
            const SizedBox(height: 12),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: List.generate(newsList.length, (i) {
                final active = i == _newsPage;
                return AnimatedContainer(
                  duration: const Duration(milliseconds: 250),
                  margin: const EdgeInsets.symmetric(horizontal: 3),
                  width: active ? 20 : 6,
                  height: 6,
                  decoration: BoxDecoration(
                    color: active ? _C.blue : _C.border,
                    borderRadius: BorderRadius.circular(3),
                  ),
                );
              }),
            ),
          ],

          const SizedBox(height: 24),

          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: Row(children: [
              Container(
                width: 4, height: 18,
                decoration: BoxDecoration(
                  gradient: _C.btnGrad,
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
              const SizedBox(width: 10),
              const Text('Aksi Cepat',
                  style: TextStyle(
                      color: _C.text, fontSize: 15, fontWeight: FontWeight.w700)),
            ]),
          ),
          const SizedBox(height: 12),

          Row(
            children: [
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.only(left: 20, right: 6),
                  child: _MiniActionBtn(
                    icon: FontAwesomeIcons.telegram,
                    label: 'Info Channel',
                    color: const Color(0xFF1A73E8),
                    bgColor: const Color(0xFFE8F0FE),
                    onTap: () => _openUrl('https://t.me/aboutdis1'),
                  ),
                ),
              ),
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.only(left: 6, right: 20),
                  child: _MiniActionBtn(
                    icon: Icons.wifi_tethering_error_rounded,
                    label: 'Bug Sender',
                    color: _C.blue,
                    bgColor: _C.blue.withOpacity(0.1),
                    onTap: () => Navigator.push(
                      context,
                      _slideRoute(BugSenderPage(
                          sessionKey: sessionKey, username: username, role: role)),
                    ),
                  ),
                ),
              ),
            ],
          ),

          const SizedBox(height: 24),

          PrayerTimesWidget(provider: _prayerProvider),

          const SizedBox(height: 32),
        ],
      ),
    );
  }

  // ─── INFO UPDATE SCROLL ──────────────────────────────────────────────────
  Widget _buildUpdateScroll() {
    final updates = [
      'VOLCANIC WHATSAPP BUG',
      'VOLCANIC TOOLS PREMIUM',
      'VOLCANIC NEW RELEASE',
      'THANKS SUPPORT VOLCANIC',
      'INFORMATION UPDATE',
      'NEWS UPDATES',
    ];

    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16),
      decoration: BoxDecoration(
        color: _C.surface,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: _C.border),
        boxShadow: [
          BoxShadow(color: Colors.black.withOpacity(0.04), blurRadius: 8, offset: const Offset(0, 2)),
          BoxShadow(color: Colors.white.withOpacity(0.6), blurRadius: 6, offset: const Offset(-1, -1)),
        ],
      ),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 6),
        child: Stack(
          children: [
            if (_showLeftArrow)
              Positioned(
                left: 0,
                top: 0,
                bottom: 0,
                child: Container(
                  width: 24,
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [_C.surface, _C.surface.withOpacity(0)],
                      begin: Alignment.centerLeft,
                      end: Alignment.centerRight,
                    ),
                  ),
                  child: const Icon(Icons.chevron_left, color: _C.textSub, size: 18),
                ),
              ),
            
            if (_showRightArrow)
              Positioned(
                right: 0,
                top: 0,
                bottom: 0,
                child: Container(
                  width: 24,
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [_C.surface.withOpacity(0), _C.surface],
                      begin: Alignment.centerLeft,
                      end: Alignment.centerRight,
                    ),
                  ),
                  child: const Icon(Icons.chevron_right, color: _C.textSub, size: 18),
                ),
              ),
            
            SizedBox(
              height: 28,
              child: ListView.builder(
                controller: _updateScrollCtrl,
                scrollDirection: Axis.horizontal,
                physics: const BouncingScrollPhysics(),
                itemCount: updates.length,
                padding: const EdgeInsets.symmetric(horizontal: 20),
                itemBuilder: (context, index) {
                  return Container(
                    margin: const EdgeInsets.symmetric(horizontal: 8),
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
                    decoration: BoxDecoration(
                      gradient: _C.btnGrad,
                      borderRadius: BorderRadius.circular(20),
                      boxShadow: [
                        BoxShadow(color: _C.blue.withOpacity(0.25), blurRadius: 6, offset: const Offset(0, 2)),
                      ],
                    ),
                    child: Center(
                      child: Text(
                        updates[index],
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 11,
                          fontWeight: FontWeight.w700,
                          letterSpacing: 0.3,
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ─── VOLCANIC TEXT ──────────────────────────────────────────────────────
  Widget _buildScaryText() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16),
      padding: const EdgeInsets.symmetric(vertical: 8),
      decoration: BoxDecoration(
        color: _C.surface,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: _C.border),
        boxShadow: [
          BoxShadow(color: Colors.black.withOpacity(0.04), blurRadius: 8, offset: const Offset(0, 2)),
          BoxShadow(color: Colors.white.withOpacity(0.6), blurRadius: 6, offset: const Offset(-1, -1)),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(14),
        child: Stack(
          children: [
            Positioned.fill(
              child: Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [
                      _C.blue.withOpacity(0.05),
                      _C.blueLight.withOpacity(0.05),
                      _C.blue.withOpacity(0.05),
                    ],
                    begin: Alignment.centerLeft,
                    end: Alignment.centerRight,
                  ),
                ),
              ),
            ),
            _MarqueeText(
              text: 'VOLCANIC DASHBOARD',
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w900,
                letterSpacing: 2.5,
                foreground: Paint()
                  ..shader = LinearGradient(
                    colors: [
                      _C.blueDark,
                      _C.blue,
                      _C.blueLight,
                      _C.blue,
                      _C.blueDark,
                    ],
                    begin: Alignment.centerLeft,
                    end: Alignment.centerRight,
                  ).createShader(Rect.fromLTWH(0, 0, 300, 50)),
                shadows: [
                  Shadow(
                    color: _C.blue.withOpacity(0.3),
                    blurRadius: 12,
                    offset: Offset(0, 2),
                  ),
                  Shadow(
                    color: _C.blueLight.withOpacity(0.2),
                    blurRadius: 20,
                    offset: Offset(0, 0),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ─── CHAT PUBLIC BUTTON ─────────────────────────────────────────────────
  Widget _buildChatPublicButton() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: GestureDetector(
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => const ChatScreen(),
            ),
          );
        },
        child: Container(
          height: 48,
          decoration: BoxDecoration(
            gradient: _C.btnGrad,
            borderRadius: BorderRadius.circular(14),
            boxShadow: [
              BoxShadow(color: _C.blue.withOpacity(0.35), blurRadius: 12, offset: const Offset(0, 4)),
              BoxShadow(color: Colors.white.withOpacity(0.6), blurRadius: 8, offset: const Offset(-2, -2)),
            ],
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                width: 28,
                height: 28,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: Colors.white.withOpacity(0.15),
                ),
                child: const Icon(Icons.chat_bubble_outline_rounded, color: Colors.white, size: 16),
              ),
              const SizedBox(width: 10),
              const Text('Chat Public', style: TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.w800, letterSpacing: 0.5)),
              const SizedBox(width: 6),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.15),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: const Text('LIVE', style: TextStyle(color: Colors.white, fontSize: 8, fontWeight: FontWeight.w800)),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ─── BUILD ──────────────────────────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _C.bg,
      extendBodyBehindAppBar: true,
      appBar: _buildAppBar(),
      drawer: _buildDrawer(),
      body: Stack(
        children: [
          Positioned.fill(child: _AnimatedBg(controller: _bgCtrl)),
          SafeArea(
            child: FadeTransition(
              opacity: _pageFade,
              child: SlideTransition(
                position: _pageSlide,
                child: _body,
              ),
            ),
          ),
        ],
      ),
      bottomNavigationBar: _buildBottomNav(),
    );
  }

  PreferredSizeWidget _buildAppBar() {
  return AppBar(
    backgroundColor: Colors.transparent,
    elevation: 0,
    titleSpacing: 0,
    leading: Builder(builder: (ctx) => _MenuBtn(onTap: () => Scaffold.of(ctx).openDrawer())),
    title: Padding(
      padding: const EdgeInsets.only(left: 4),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          TweenAnimationBuilder<double>(
            tween: Tween(begin: -0.5, end: 0.0),
            duration: const Duration(milliseconds: 600),
            curve: Curves.easeOutBack,
            builder: (_, value, __) {
              return Transform.translate(
                offset: Offset(value * 100, 0),
                child: Opacity(
                  opacity: value + 0.5,
                  child: Text(
                    'Halo, $username 👋',
                    style: const TextStyle(
                      color: _C.text,
                      fontSize: 16,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ),
              );
            },
          ),
          Row(children: [
            Container(width: 6, height: 6, decoration: const BoxDecoration(shape: BoxShape.circle, color: _C.green, boxShadow: [BoxShadow(color: Color(0x5534A853), blurRadius: 6)])),
            const SizedBox(width: 5),
            Text(role.toUpperCase(), style: TextStyle(color: _roleColor(role), fontSize: 10, fontWeight: FontWeight.w700, letterSpacing: 1)),
            const SizedBox(width: 8),
            Text('· Exp: $expiredDate', style: const TextStyle(color: _C.textSub, fontSize: 10)),
          ]),
        ],
      ),
    ),
    actions: [
      _AppBarIconBtn(
        icon: Icons.headset_mic_outlined,
        onTap: () => Navigator.push(context, _slideRoute(const ContactPage())),
      ),
      _AppBarIconBtn(
        icon: Icons.account_circle_outlined,
        onTap: () => Navigator.push(context, _slideRoute(ProfilePage(
          username: username, password: password,
          role: role, expiredDate: expiredDate,
          sessionKey: sessionKey,
        ))),
      ),
      const SizedBox(width: 8),
    ],
  );
}

  Widget _buildBottomNav() {
    final items = [
      _NavItem(icon: Icons.home_rounded, label: 'HOME'),
      _NavItem(icon: FontAwesomeIcons.whatsapp, label: 'WHATSAPP'),
      _NavItem(icon: Icons.campaign_rounded, label: 'INFO'),
      _NavItem(icon: Icons.tune_rounded, label: 'TOOLS'),
    ];

    return Container(
      decoration: BoxDecoration(
        color: _C.surface,
        border: const Border(top: BorderSide(color: _C.border)),
        boxShadow: [
          BoxShadow(color: Colors.black.withOpacity(0.06), blurRadius: 12, offset: const Offset(0, -4)),
          BoxShadow(color: Colors.white.withOpacity(0.6), blurRadius: 8, offset: const Offset(-2, 0)),
        ],
      ),
      child: SafeArea(
        top: false,
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 6, horizontal: 6),
          child: Row(
            children: items.asMap().entries.map((e) {
              final i = e.key;
              final item = e.value;
              final active = _navIndex == i;
              return Expanded(
                child: _NavButton3D(
                  icon: item.icon,
                  label: item.label,
                  active: active,
                  onTap: () => _onNavTap(i),
                ),
              );
            }).toList(),
          ),
        ),
      ),
    );
  }

  Widget _buildDrawer() {
    return Drawer(
      backgroundColor: Colors.transparent,
      width: MediaQuery.of(context).size.width * 0.78,
      child: Container(
        decoration: BoxDecoration(
          color: _C.surface,
          border: const Border(right: BorderSide(color: _C.border)),
          boxShadow: [
            BoxShadow(color: Colors.black.withOpacity(0.06), blurRadius: 15, offset: const Offset(4, 0)),
          ],
        ),
        child: Column(
          children: [
            _DrawerHeader(
              username: username,
              role: role,
              expiredDate: expiredDate,
              profileImage: _profileImage,
              videoCtrl: _menuVideoCtrl,
            ),
            Expanded(
              child: ListView(
                padding: const EdgeInsets.fromLTRB(16, 16, 16, 0),
                children: [
                  if (role == 'reseller')
                    _DrawerItem(
                      icon: Icons.storefront_rounded,
                      label: 'Seller Page',
                      onTap: () => _onDrawerNav(1),
                    ),
                  if (role == 'owner')
                    _DrawerItem(
                      icon: Icons.workspace_premium_rounded,
                      label: 'Owner Page',
                      onTap: () => _onDrawerNav(2),
                    ),
                  _DrawerItem(
                    icon: Icons.history_rounded,
                    label: 'Riwayat Aktivitas',
                    onTap: () {
                      Navigator.pop(context);
                      Navigator.push(context, _slideRoute(RiwayatPage(sessionKey: sessionKey, role: role)));
                    },
                  ),
                  _DrawerItem(
                    icon: Icons.lock_outline_rounded,
                    label: 'Ganti Password',
                    onTap: () {
                      Navigator.pop(context);
                      Navigator.push(context, _slideRoute(ChangePasswordPage(username: username, sessionKey: sessionKey)));
                    },
                  ),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
              child: _DrawerItem(
                icon: Icons.logout_rounded,
                label: 'Keluar',
                isDestructive: true,
                onTap: () async {
                  Navigator.pop(context);
                  final prefs = await SharedPreferences.getInstance();
                  await prefs.clear();
                  if (!mounted) return;
                  Navigator.of(context).pushAndRemoveUntil(
                    MaterialPageRoute(builder: (_) => const LoginPage()),
                    (_) => false,
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ─── STATS STRIP ──────────────────────────────────────────────────────────────
class _StatsStrip extends StatelessWidget {
  final int online;
  final int connections;
  const _StatsStrip({required this.online, required this.connections});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
        decoration: BoxDecoration(
          color: _C.surface,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: _C.border),
          boxShadow: [
            BoxShadow(color: Colors.black.withOpacity(0.04), blurRadius: 10, offset: const Offset(0, 3)),
            BoxShadow(color: Colors.white.withOpacity(0.6), blurRadius: 6, offset: const Offset(-1, -1)),
          ],
        ),
        child: Row(
          children: [
            _StatItem(icon: Icons.people_alt_rounded, label: 'Online', value: '$online', color: _C.green),
            Container(width: 1, height: 28, color: _C.border, margin: const EdgeInsets.symmetric(horizontal: 12)),
            _StatItem(icon: Icons.wifi_rounded, label: 'Koneksi', value: '$connections', color: _C.blue),
            const Spacer(),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
              decoration: BoxDecoration(
                color: _C.green.withOpacity(0.1),
                borderRadius: BorderRadius.circular(6),
                border: Border.all(color: _C.green.withOpacity(0.3)),
              ),
              child: const Text('LIVE', style: TextStyle(color: _C.green, fontSize: 9, fontWeight: FontWeight.w700)),
            ),
          ],
        ),
      ),
    );
  }
}

class _StatItem extends StatelessWidget {
  final IconData icon; final String label; final String value; final Color color;
  const _StatItem({required this.icon, required this.label, required this.value, required this.color});

  @override
  Widget build(BuildContext context) {
    return Row(children: [
      Icon(icon, color: color, size: 14),
      const SizedBox(width: 6),
      Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(value, style: TextStyle(color: color, fontSize: 13, fontWeight: FontWeight.w800)),
        Text(label, style: const TextStyle(color: _C.textSub, fontSize: 9)),
      ]),
    ]);
  }
}

// ─── MINI ACTION BUTTON ──────────────────────────────────────────────────────
class _MiniActionBtn extends StatefulWidget {
  final IconData icon;
  final String label;
  final Color color;
  final Color bgColor;
  final VoidCallback onTap;

  const _MiniActionBtn({
    required this.icon,
    required this.label,
    required this.color,
    required this.bgColor,
    required this.onTap,
  });

  @override
  State<_MiniActionBtn> createState() => _MiniActionBtnState();
}

class _MiniActionBtnState extends State<_MiniActionBtn> {
  bool _pressed = false;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => setState(() => _pressed = true),
      onTapUp: (_) { setState(() => _pressed = false); widget.onTap(); },
      onTapCancel: () => setState(() => _pressed = false),
      child: AnimatedScale(
        scale: _pressed ? 0.94 : 1.0,
        duration: const Duration(milliseconds: 120),
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 8),
          decoration: BoxDecoration(
            color: _C.surface,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: _pressed ? widget.color.withOpacity(0.4) : _C.border),
            boxShadow: _pressed
                ? [BoxShadow(color: widget.color.withOpacity(0.12), blurRadius: 8, offset: const Offset(0, 2))]
                : [
                    BoxShadow(color: Colors.black.withOpacity(0.04), blurRadius: 6, offset: const Offset(0, 2)),
                    BoxShadow(color: Colors.white.withOpacity(0.6), blurRadius: 4, offset: const Offset(-1, -1)),
                  ],
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 36, height: 36,
                decoration: BoxDecoration(
                  color: widget.bgColor,
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: widget.color.withOpacity(0.2)),
                ),
                child: Icon(widget.icon, color: widget.color, size: 16),
              ),
              const SizedBox(height: 4),
              Text(widget.label, style: TextStyle(color: _C.text, fontSize: 10, fontWeight: FontWeight.w600)),
            ],
          ),
        ),
      ),
    );
  }
}

// ─── NEWS CARD ────────────────────────────────────────────────────────────────
class _NewsCard extends StatelessWidget {
  final dynamic item;
  final bool isActive;
  const _NewsCard({required this.item, required this.isActive});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 6),
      decoration: BoxDecoration(
        color: _C.surface,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: isActive ? _C.blue : _C.border, width: isActive ? 1.5 : 1),
        boxShadow: isActive
            ? [
                BoxShadow(color: _C.blue.withOpacity(0.15), blurRadius: 20, offset: const Offset(0, 8)),
                BoxShadow(color: Colors.white.withOpacity(0.6), blurRadius: 10, offset: const Offset(-2, -2)),
              ]
            : [BoxShadow(color: Colors.black.withOpacity(0.04), blurRadius: 10, offset: const Offset(0, 4))],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(20),
        child: Stack(
          fit: StackFit.expand,
          children: [
            if (item['image'] != null && item['image'].toString().isNotEmpty)
              NewsMedia(url: item['image']),
            Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [_C.text.withOpacity(0.6), Colors.transparent],
                  begin: Alignment.bottomCenter,
                  end: Alignment.topCenter,
                  stops: const [0.0, 0.6],
                ),
              ),
            ),
            Positioned(
              bottom: 16, left: 16, right: 16,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                    decoration: BoxDecoration(
                      color: _C.blue.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(6),
                      border: Border.all(color: _C.blue.withOpacity(0.3)),
                    ),
                    child: const Text('NEWS', style: TextStyle(color: _C.blue, fontSize: 9, fontWeight: FontWeight.w800)),
                  ),
                  const SizedBox(height: 6),
                  Text(item['title'] ?? 'No Title', style: const TextStyle(color: Colors.white, fontSize: 15, fontWeight: FontWeight.w700), maxLines: 2, overflow: TextOverflow.ellipsis),
                  if (item['desc'] != null && item['desc'].toString().isNotEmpty) ...[
                    const SizedBox(height: 4),
                    Text(item['desc'], style: const TextStyle(color: Colors.white70, fontSize: 11, height: 1.4), maxLines: 1, overflow: TextOverflow.ellipsis),
                  ],
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ─── DRAWER HEADER ────────────────────────────────────────────────────────────
class _DrawerHeader extends StatefulWidget {
  final String username; final String role; final String expiredDate;
  final File? profileImage; final VideoPlayerController? videoCtrl;
  const _DrawerHeader({required this.username, required this.role, required this.expiredDate, this.profileImage, this.videoCtrl});

  @override
  State<_DrawerHeader> createState() => _DrawerHeaderState();
}

class _DrawerHeaderState extends State<_DrawerHeader> with SingleTickerProviderStateMixin {
  late AnimationController _c; late Animation<double> _fade; late Animation<Offset> _slide;

  @override
  void initState() {
    super.initState();
    _c = AnimationController(vsync: this, duration: const Duration(milliseconds: 600));
    _fade = CurvedAnimation(parent: _c, curve: Curves.easeOut);
    _slide = Tween<Offset>(begin: const Offset(0, 0.2), end: Offset.zero).animate(CurvedAnimation(parent: _c, curve: Curves.easeOutCubic));
    _c.forward();
  }

  @override
  void dispose() { _c.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    final rColor = _roleColor(widget.role);
    return Container(
      height: 200,
      clipBehavior: Clip.hardEdge,
      decoration: BoxDecoration(
        color: _C.surface,
        border: const Border(bottom: BorderSide(color: _C.border)),
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.04), blurRadius: 10, offset: const Offset(0, 2))],
      ),
      child: Stack(
        children: [
          if (widget.videoCtrl != null && widget.videoCtrl!.value.isInitialized)
            Positioned.fill(child: FittedBox(fit: BoxFit.cover, child: SizedBox(width: widget.videoCtrl!.value.size.width, height: widget.videoCtrl!.value.size.height, child: VideoPlayer(widget.videoCtrl!)))),
          Positioned.fill(
            child: Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [Colors.white.withOpacity(0.3), Colors.white.withOpacity(0.85)],
                ),
              ),
            ),
          ),
          Positioned.fill(
            child: SafeArea(
              child: FadeTransition(
                opacity: _fade,
                child: SlideTransition(
                  position: _slide,
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Stack(
                        children: [
                          Container(
                            width: 64, height: 64,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              border: Border.all(color: rColor, width: 2.5),
                              boxShadow: [
                                BoxShadow(color: rColor.withOpacity(0.3), blurRadius: 18),
                                BoxShadow(color: Colors.white.withOpacity(0.6), blurRadius: 8, offset: const Offset(-2, -2)),
                              ],
                            ),
                            child: ClipOval(
                              child: widget.profileImage != null
                                  ? Image.file(widget.profileImage!, fit: BoxFit.cover)
                                  : Container(color: _C.bg, child: Icon(_roleIcon(widget.role), size: 30, color: rColor.withOpacity(0.9))),
                            ),
                          ),
                          Positioned(
                            right: 0, bottom: 0,
                            child: Container(
                              padding: const EdgeInsets.all(3),
                              decoration: BoxDecoration(
                                color: rColor,
                                shape: BoxShape.circle,
                                border: Border.all(color: _C.surface, width: 2),
                              ),
                              child: Icon(_roleIcon(widget.role), size: 8, color: Colors.white),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 8),
                      Text(widget.username, style: const TextStyle(color: _C.text, fontSize: 16, fontWeight: FontWeight.w800)),
                      const SizedBox(height: 2),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
                        decoration: BoxDecoration(
                          color: rColor.withOpacity(0.08),
                          borderRadius: BorderRadius.circular(16),
                          border: Border.all(color: rColor.withOpacity(0.3)),
                        ),
                        child: Text(widget.role.toUpperCase(), style: TextStyle(color: rColor, fontSize: 10, fontWeight: FontWeight.w700)),
                      ),
                      const SizedBox(height: 4),
                      Text('Exp: ${widget.expiredDate}', style: const TextStyle(color: _C.textSub, fontSize: 10)),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ─── DRAWER ITEM ──────────────────────────────────────────────────────────────
class _DrawerItem extends StatefulWidget {
  final IconData icon; final String label; final VoidCallback onTap; final bool isDestructive;
  const _DrawerItem({required this.icon, required this.label, required this.onTap, this.isDestructive = false});

  @override
  State<_DrawerItem> createState() => _DrawerItemState();
}

class _DrawerItemState extends State<_DrawerItem> {
  bool _pressed = false;

  @override
  Widget build(BuildContext context) {
    final color = widget.isDestructive ? _C.btnGradRed.colors.first : _C.text;
    return GestureDetector(
      onTapDown: (_) => setState(() => _pressed = true),
      onTapUp: (_) { setState(() => _pressed = false); widget.onTap(); },
      onTapCancel: () => setState(() => _pressed = false),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 140),
        margin: const EdgeInsets.only(bottom: 4),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
        decoration: BoxDecoration(
          color: _pressed ? color.withOpacity(0.08) : Colors.transparent,
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: _pressed ? color.withOpacity(0.2) : _C.border),
        ),
        child: Row(children: [
          Icon(widget.icon, color: color, size: 16),
          const SizedBox(width: 12),
          Text(widget.label, style: TextStyle(color: widget.isDestructive ? _C.btnGradRed.colors.first : _C.text, fontSize: 13, fontWeight: FontWeight.w600)),
          const Spacer(),
          Icon(Icons.arrow_forward_ios_rounded, color: _C.textDim, size: 10),
        ]),
      ),
    );
  }
}

// ─── NAV BUTTON 3D ────────────────────────────────────────────────────────────
class _NavButton3D extends StatefulWidget {
  final IconData icon; final String label; final bool active; final VoidCallback onTap;
  const _NavButton3D({required this.icon, required this.label, required this.active, required this.onTap});

  @override
  State<_NavButton3D> createState() => _NavButton3DState();
}

class _NavButton3DState extends State<_NavButton3D> with SingleTickerProviderStateMixin {
  bool _pressed = false;
  late AnimationController _scaleCtrl;
  late Animation<double> _scaleAnim;

  @override
  void initState() {
    super.initState();
    _scaleCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 150));
    _scaleAnim = Tween<double>(begin: 1.0, end: 0.92).animate(
      CurvedAnimation(parent: _scaleCtrl, curve: Curves.easeOutCubic),
    );
  }

  @override
  void dispose() { _scaleCtrl.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) { setState(() => _pressed = true); _scaleCtrl.forward(); },
      onTapUp: (_) { setState(() => _pressed = false); _scaleCtrl.reverse(); widget.onTap(); },
      onTapCancel: () { setState(() => _pressed = false); _scaleCtrl.reverse(); },
      child: AnimatedBuilder(
        animation: _scaleAnim,
        builder: (_, __) => Transform.scale(
          scale: _scaleAnim.value,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              AnimatedContainer(
                duration: const Duration(milliseconds: 200),
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                decoration: BoxDecoration(
                  color: widget.active ? _C.blue.withOpacity(0.1) : Colors.transparent,
                  borderRadius: BorderRadius.circular(10),
                  border: widget.active ? Border.all(color: _C.blue.withOpacity(0.3)) : null,
                  boxShadow: widget.active ? [
                    BoxShadow(color: _C.blue.withOpacity(0.15), blurRadius: 8, offset: const Offset(0, 2)),
                  ] : null,
                ),
                child: Icon(widget.icon, size: 20, color: widget.active ? _C.blue : _C.textDim),
              ),
              const SizedBox(height: 2),
              AnimatedDefaultTextStyle(
                duration: const Duration(milliseconds: 200),
                style: TextStyle(
                  color: widget.active ? _C.blue : _C.textDim,
                  fontSize: 9,
                  fontWeight: widget.active ? FontWeight.w700 : FontWeight.w400,
                ),
                child: Text(widget.label),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ─── APP BAR ICON BUTTON ──────────────────────────────────────────────────────
class _AppBarIconBtn extends StatefulWidget {
  final IconData icon; final VoidCallback onTap;
  const _AppBarIconBtn({required this.icon, required this.onTap});

  @override
  State<_AppBarIconBtn> createState() => _AppBarIconBtnState();
}

class _AppBarIconBtnState extends State<_AppBarIconBtn> {
  bool _down = false;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 2, vertical: 6),
      child: GestureDetector(
        onTapDown: (_) => setState(() => _down = true),
        onTapUp: (_) { setState(() => _down = false); widget.onTap(); },
        onTapCancel: () => setState(() => _down = false),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 120),
          width: 32, height: 32,
          decoration: BoxDecoration(
            color: _down ? _C.border : _C.surface,
            borderRadius: BorderRadius.circular(8),
            border: Border.all(color: _C.border),
            boxShadow: _down ? null : [
              BoxShadow(color: Colors.white.withOpacity(0.6), blurRadius: 4, offset: const Offset(-1, -1)),
            ],
          ),
          child: Icon(widget.icon, color: _C.textSub, size: 16),
        ),
      ),
    );
  }
}

// ─── MENU BUTTON ──────────────────────────────────────────────────────────────
class _MenuBtn extends StatefulWidget {
  final VoidCallback onTap;
  const _MenuBtn({required this.onTap});

  @override
  State<_MenuBtn> createState() => _MenuBtnState();
}

class _MenuBtnState extends State<_MenuBtn> {
  bool _down = false;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(8),
      child: GestureDetector(
        onTapDown: (_) => setState(() => _down = true),
        onTapUp: (_) { setState(() => _down = false); widget.onTap(); },
        onTapCancel: () => setState(() => _down = false),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 120),
          width: 36, height: 36,
          decoration: BoxDecoration(
            color: _down ? _C.border : _C.surface,
            borderRadius: BorderRadius.circular(8),
            border: Border.all(color: _C.border),
            boxShadow: _down ? null : [
              BoxShadow(color: Colors.white.withOpacity(0.6), blurRadius: 4, offset: const Offset(-1, -1)),
            ],
          ),
          child: const Icon(Icons.menu_rounded, color: _C.text, size: 18),
        ),
      ),
    );
  }
}

// ─── ANIMATED BACKGROUND ──────────────────────────────────────────────────────
class _AnimatedBg extends StatelessWidget {
  final AnimationController controller;
  const _AnimatedBg({required this.controller});

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: controller,
      builder: (_, __) => CustomPaint(painter: _BgPainter(controller.value)),
    );
  }
}

class _BgPainter extends CustomPainter {
  final double t;
  _BgPainter(this.t);

  @override
  void paint(Canvas canvas, Size size) {
    final grid = Paint()..color = _C.border.withOpacity(0.2)..strokeWidth = 0.5;
    const step = 38.0;
    for (double x = 0; x < size.width; x += step) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), grid);
    }
    for (double y = 0; y < size.height; y += step) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), grid);
    }
    final glow = Paint()
      ..shader = RadialGradient(colors: [
        _C.blue.withOpacity(0.04 + math.sin(t * math.pi * 2) * 0.015),
        Colors.transparent,
      ], radius: 0.9).createShader(
          Rect.fromCircle(center: Offset(size.width / 2, 0), radius: size.width));
    canvas.drawCircle(Offset(size.width / 2, 0), size.width, glow);
  }

  @override
  bool shouldRepaint(_BgPainter old) => old.t != t;
}

// ─── SHARED PRIMITIVES ────────────────────────────────────────────────────────
class _NavItem {
  final IconData icon; final String label;
  const _NavItem({required this.icon, required this.label});
}

PageRoute _slideRoute(Widget page) => PageRouteBuilder(
  pageBuilder: (_, __, ___) => page,
  transitionDuration: const Duration(milliseconds: 350),
  transitionsBuilder: (_, anim, __, child) => SlideTransition(
    position: Tween<Offset>(begin: const Offset(1, 0), end: Offset.zero)
        .animate(CurvedAnimation(parent: anim, curve: Curves.easeOutCubic)),
    child: FadeTransition(opacity: anim, child: child),
  ),
);

class _GradBtn extends StatefulWidget {
  final String label; final VoidCallback onTap; final bool fullWidth; final LinearGradient gradient;
  const _GradBtn({required this.label, required this.onTap, this.fullWidth = false, this.gradient = _C.btnGrad});

  @override
  State<_GradBtn> createState() => _GradBtnState();
}

class _GradBtnState extends State<_GradBtn> {
  bool _down = false;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => setState(() => _down = true),
      onTapUp: (_) { setState(() => _down = false); widget.onTap(); },
      onTapCancel: () => setState(() => _down = false),
      child: AnimatedScale(
        scale: _down ? 0.96 : 1.0,
        duration: const Duration(milliseconds: 120),
        child: Container(
          height: 44,
          width: widget.fullWidth ? double.infinity : null,
          padding: widget.fullWidth ? EdgeInsets.zero : const EdgeInsets.symmetric(horizontal: 24),
          decoration: BoxDecoration(
            gradient: widget.gradient,
            borderRadius: BorderRadius.circular(12),
            boxShadow: _down ? [] : [
              BoxShadow(color: _C.blue.withOpacity(0.3), blurRadius: 12, offset: const Offset(0, 4)),
              BoxShadow(color: Colors.white.withOpacity(0.6), blurRadius: 6, offset: const Offset(-2, -2)),
            ],
          ),
          child: Center(child: Text(widget.label, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 13))),
        ),
      ),
    );
  }
}

// ─── MUSIC CONTROL BUTTON ──────────────────────────────────────────────────────
class _MusicControlBtn extends StatelessWidget {
  final IconData icon;
  final VoidCallback onTap;
  final bool isMain;

  const _MusicControlBtn({
    required this.icon,
    required this.onTap,
    this.isMain = false,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: isMain ? 40 : 32,
        height: isMain ? 40 : 32,
        margin: const EdgeInsets.symmetric(horizontal: 2),
        decoration: BoxDecoration(
          color: isMain ? _C.blue : Colors.transparent,
          shape: BoxShape.circle,
          boxShadow: isMain ? [
            BoxShadow(
              color: _C.blue.withOpacity(0.3),
              blurRadius: 12,
              offset: const Offset(0, 4),
            ),
            BoxShadow(
              color: Colors.white.withOpacity(0.6),
              blurRadius: 6,
              offset: const Offset(-2, -2),
            ),
          ] : null,
        ),
        child: Icon(
          icon,
          color: isMain ? Colors.white : _C.text,
          size: isMain ? 22 : 18,
        ),
      ),
    );
  }
}

// ─── NEWSMEDIA ────────────────────────────────────────────────────────────────
class NewsMedia extends StatefulWidget {
  final String url;
  const NewsMedia({super.key, required this.url});

  @override
  State<NewsMedia> createState() => _NewsMediaState();
}

class _NewsMediaState extends State<NewsMedia> {
  VideoPlayerController? _ctrl;

  @override
  void initState() {
    super.initState();
    if (_isVideo(widget.url)) {
      _ctrl = VideoPlayerController.networkUrl(Uri.parse(widget.url))
        ..initialize().then((_) {
          if (mounted) setState(() {});
          _ctrl?.setLooping(true);
          _ctrl?.setVolume(0);
          _ctrl?.play();
        });
    }
  }

  bool _isVideo(String url) => url.endsWith('.mp4') || url.endsWith('.webm') || url.endsWith('.mov') || url.endsWith('.mkv');

  @override
  void dispose() { _ctrl?.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    if (_isVideo(widget.url)) {
      if (_ctrl?.value.isInitialized == true) {
        return AspectRatio(aspectRatio: _ctrl!.value.aspectRatio, child: VideoPlayer(_ctrl!));
      }
      return Container(color: _C.bg, child: const Center(child: SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2, color: _C.blue))));
    }
    return Image.network(
      widget.url,
      fit: BoxFit.cover,
      loadingBuilder: (_, child, progress) => progress == null
          ? child
          : Container(
              color: _C.bg,
              child: Center(
                child: CircularProgressIndicator(
                  value: progress.expectedTotalBytes != null
                      ? progress.cumulativeBytesLoaded / progress.expectedTotalBytes!
                      : null,
                  strokeWidth: 2,
                  color: _C.blue,
                ),
              ),
            ),
      errorBuilder: (_, __, ___) => Container(color: _C.bg, child: const Icon(Icons.broken_image_outlined, color: _C.textDim, size: 32)),
    );
  }
}

// ─── MARQUEE TEXT WIDGET ────────────────────────────────────────────────────
class _MarqueeText extends StatefulWidget {
  final String text;
  final TextStyle style;

  const _MarqueeText({
    required this.text,
    required this.style,
  });

  @override
  State<_MarqueeText> createState() => _MarqueeTextState();
}

class _MarqueeTextState extends State<_MarqueeText>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _animation;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 10),
    )..repeat();

    _animation = Tween<double>(begin: 0.0, end: -1.0).animate(
      CurvedAnimation(parent: _controller, curve: Curves.linear),
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final screenWidth = constraints.maxWidth;
        final fullText = '   ${widget.text}    ${widget.text}    ${widget.text}   ';
        
        return AnimatedBuilder(
          animation: _animation,
          builder: (context, child) {
            return ShaderMask(
              shaderCallback: (bounds) {
                return LinearGradient(
                  colors: [
                    Colors.transparent,
                    Colors.white,
                    Colors.white,
                    Colors.white,
                    Colors.white,
                    Colors.white,
                    Colors.transparent,
                  ],
                  begin: Alignment.centerLeft,
                  end: Alignment.centerRight,
                  stops: const [0.0, 0.05, 0.2, 0.5, 0.8, 0.95, 1.0],
                ).createShader(bounds);
              },
              blendMode: BlendMode.dstIn,
              child: SizedBox(
                height: 40,
                child: Stack(
                  clipBehavior: Clip.none,
                  children: [
                    Positioned(
                      left: _animation.value * screenWidth,
                      child: SizedBox(
                        width: screenWidth * 3.5,
                        child: Row(
                          children: [
                            _buildTextItem(fullText),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }

  Widget _buildTextItem(String text) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Text(
          text,
          style: widget.style,
        ),
      ],
    );
  }
}