// QURAN_PAGE.DART - HALAMAN AL-QURAN
// Kode ini adalah halaman untuk menampilkan daftar surat dan ayat Al-Quran

import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

// ─── TEMA WARNA PUTIH X BIRU BARU ─────────────────────────────────────────────────────────────
// Kelas untuk menyimpan konstanta warna yang digunakan di seluruh aplikasi
class _C {
  static const bg        = Color(0xFFE8EDF2); // Warna latar belakang
  static const surface   = Color(0xFFFFFFFF); // Warna permukaan/kartu
  static const card      = Color(0xFFFFFFFF); // Warna kartu
  static const border    = Color(0xFFD4DCE4); // Warna border
  static const borderLit = Color(0xFFCBD5E1); // Warna border terang

  static const green     = Color(0xFF2E7D32); // Warna hijau
  static const gold      = Color(0xFFC9A94E); // Warna emas
  static const goldLight = Color(0xFFE8D5A3); // Warna emas terang
  static const blue      = Color(0xFF1A73E8); // Warna biru
  static const blueMid   = Color(0xFF4285F4); // Warna biru sedang
  static const blueLight = Color(0xFF8AB4F8); // Warna biru terang

  static const text      = Color(0xFF202124); // Warna teks utama
  static const textSub   = Color(0xFF5F6368); // Warna teks sekunder
  static const textDim   = Color(0xFF9AA0A6); // Warna teks redup
  static const white     = Color(0xFFFFFFFF); // Warna putih
}

// Kelas utama halaman Al-Quran
class QuranPage extends StatefulWidget {
  const QuranPage({super.key});

  @override
  State<QuranPage> createState() => _QuranPageState();
}

// State dari halaman Al-Quran
class _QuranPageState extends State<QuranPage> with SingleTickerProviderStateMixin {
  // Variabel untuk menyimpan data
  List<dynamic> _surahList = []; // Daftar surat
  List<dynamic> _ayahList = []; // Daftar ayat
  bool _isLoading = true; // Status loading
  bool _isLoadingAyah = false; // Status loading ayat
  int _selectedSurahIndex = 0; // Indeks surat yang dipilih
  String _errorMessage = ''; // Pesan error
  String _currentSurahName = ''; // Nama surat saat ini
  
  late TabController _tabController; // Pengontrol tab
  
  // Daftar nama juz
  final List<String> _juzNames = [
    'Juz 1', 'Juz 2', 'Juz 3', 'Juz 4', 'Juz 5', 'Juz 6', 'Juz 7', 'Juz 8', 'Juz 9', 'Juz 10',
    'Juz 11', 'Juz 12', 'Juz 13', 'Juz 14', 'Juz 15', 'Juz 16', 'Juz 17', 'Juz 18', 'Juz 19', 'Juz 20',
    'Juz 21', 'Juz 22', 'Juz 23', 'Juz 24', 'Juz 25', 'Juz 26', 'Juz 27', 'Juz 28', 'Juz 29', 'Juz 30'
  ];

  // ─── URL API (CADANGAN MULTIPLE) ──────────────────────────────────
  static const String _apiPrimary = 'https://api.quran.gading.dev'; // API utama
  static const String _apiBackup = 'https://api.alquran.cloud/v1'; // API cadangan
  static const String _apiEquran = 'https://equran.id/api/v2'; // API EQuran

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
    _fetchSurahList(); // Ambil daftar surat saat halaman dibuka
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  // ─── AMBIL DAFTAR SURAT ────────────────────────────────────────────────────
  Future<void> _fetchSurahList() async {
    setState(() {
      _isLoading = true;
      _errorMessage = '';
    });

    // Coba API Utama dulu
    try {
      final response = await http.get(
        Uri.parse('$_apiPrimary/surah'),
      ).timeout(const Duration(seconds: 8));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['code'] == 200 && data['data'] != null) {
          setState(() {
            _surahList = data['data'];
            _isLoading = false;
          });
          if (_surahList.isNotEmpty) {
            _fetchAyahBySurah(_surahList[0]['number']);
          }
          return;
        }
      }
    } catch (e) {
      // Gagal, coba cadangan
      print('API Utama gagal: $e');
    }

    // Coba API Cadangan (Alquran Cloud)
    try {
      final response = await http.get(
        Uri.parse('$_apiBackup/surah'),
      ).timeout(const Duration(seconds: 8));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['code'] == 200 && data['data'] != null) {
          // Konversi format ke format yang sama
          final surahs = data['data'] as List;
          setState(() {
            _surahList = surahs.map((s) => {
              'number': s['number'],
              'name': {
                'short': s['name'],
                'transliteration': {
                  'id': s['name'],
                },
                'translation': {
                  'id': s['englishName'],
                },
              },
              'numberOfVerses': s['numberOfAyahs'],
              'revelation': {
                'id': s['revelationType'] == 'Meccan' ? 'Mekah' : 'Madinah',
              },
            }).toList();
            _isLoading = false;
          });
          if (_surahList.isNotEmpty) {
            _fetchAyahBySurah(_surahList[0]['number']);
          }
          return;
        }
      }
    } catch (e) {
      print('API Cadangan gagal: $e');
    }

    // Coba API EQuran
    try {
      final response = await http.get(
        Uri.parse('$_apiEquran/surat'),
      ).timeout(const Duration(seconds: 8));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['code'] == 200 && data['data'] != null) {
          final surahs = data['data'] as List;
          setState(() {
            _surahList = surahs.map((s) => {
              'number': s['nomor'],
              'name': {
                'short': s['nama'],
                'transliteration': {
                  'id': s['nama'],
                },
                'translation': {
                  'id': s['nama'],
                },
              },
              'numberOfVerses': s['jumlahAyat'],
              'revelation': {
                'id': s['tempatTurun'] == 'Mekah' ? 'Mekah' : 'Madinah',
              },
            }).toList();
            _isLoading = false;
          });
          if (_surahList.isNotEmpty) {
            _fetchAyahBySurah(_surahList[0]['number']);
          }
          return;
        }
      }
    } catch (e) {
      print('API EQuran gagal: $e');
    }

    // Semua gagal
    setState(() {
      _errorMessage = 'Tidak dapat terhubung ke server. Periksa koneksi internet.';
      _isLoading = false;
    });
  }

  // ─── AMBIL AYAT BERDASARKAN SURAT ─────────────────────────────────────────────────
  Future<void> _fetchAyahBySurah(int surahNumber) async {
    setState(() {
      _isLoadingAyah = true;
      _ayahList = [];
      _currentSurahName = '';
    });

    // Cari nama surat
    try {
      final surah = _surahList.firstWhere((s) => s['number'] == surahNumber);
      setState(() {
        _currentSurahName = surah['name']['transliteration']['id'] ?? 'Surat $surahNumber';
      });
    } catch (e) {
      _currentSurahName = 'Surat $surahNumber';
    }

    // Coba API Utama
    try {
      final response = await http.get(
        Uri.parse('$_apiPrimary/surah/$surahNumber'),
      ).timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['code'] == 200 && data['data'] != null) {
          setState(() {
            _ayahList = data['data']['verses'] ?? [];
            _isLoadingAyah = false;
          });
          return;
        }
      }
    } catch (e) {
      print('API ayat utama gagal: $e');
    }

    // Coba API EQuran
    try {
      final response = await http.get(
        Uri.parse('$_apiEquran/surat/$surahNumber'),
      ).timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['code'] == 200 && data['data'] != null) {
          final verses = data['data']['ayat'] as List? ?? [];
          setState(() {
            _ayahList = verses.map((v) => {
              'text': {
                'arab': v['teks'],
                'translation': {
                  'id': v['arti'] ?? 'Terjemahan tidak tersedia',
                },
              },
              'number': {
                'inSurah': v['nomor'],
              },
            }).toList();
            _isLoadingAyah = false;
          });
          return;
        }
      }
    } catch (e) {
      print('API EQuran ayat gagal: $e');
    }

    // Coba API Cadangan
    try {
      final response = await http.get(
        Uri.parse('$_apiBackup/surah/$surahNumber'),
      ).timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['code'] == 200 && data['data'] != null) {
          final verses = data['data']['ayahs'] as List? ?? [];
          setState(() {
            _ayahList = verses.map((v) => {
              'text': {
                'arab': v['text'],
                'translation': {
                  'id': v['translation']['id'] ?? 'Terjemahan tidak tersedia',
                },
              },
              'number': {
                'inSurah': v['numberInSurah'],
              },
            }).toList();
            _isLoadingAyah = false;
          });
          return;
        }
      }
    } catch (e) {
      print('API cadangan ayat gagal: $e');
    }

    // Gagal semua
    setState(() {
      _isLoadingAyah = false;
      _errorMessage = 'Gagal memuat ayat. Coba lagi nanti.';
    });
  }

  // ─── AMBIL AYAT BERDASARKAN JUZ ─────────────────────────────────────────────────
  Future<void> _fetchAyahByJuz(int juzNumber) async {
    setState(() {
      _isLoadingAyah = true;
      _ayahList = [];
      _currentSurahName = 'Juz $juzNumber';
    });

    try {
      // Coba API EQuran untuk juz
      final response = await http.get(
        Uri.parse('$_apiEquran/juz/$juzNumber'),
      ).timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['code'] == 200 && data['data'] != null) {
          final verses = data['data']['ayat'] as List? ?? [];
          setState(() {
            _ayahList = verses.map((v) => ({
              'text': {
                'arab': v['teks'] ?? '',
                'translation': {
                  'id': v['arti'] ?? 'Terjemahan tidak tersedia',
                },
              },
              'number': {
                'inSurah': v['nomor'] ?? 0,
              },
            })).toList();
            _isLoadingAyah = false;
          });
          return;
        }
      }
    } catch (e) {
      print('API Juz gagal: $e');
    }

    // Fallback: coba ambil dari surat
    setState(() {
      _isLoadingAyah = false;
      _errorMessage = 'Gagal memuat Juz. Coba pilih surat langsung.';
    });
  }

  // ─── FUNGSI SAAT SURAT DIPILIH ─────────────────────────────────────────────────
  void _onSurahSelected(int index) {
    setState(() {
      _selectedSurahIndex = index;
    });
    final surah = _surahList[index];
    _fetchAyahBySurah(surah['number']);
    _tabController.animateTo(1); // Pindah ke tab ayat
  }

  // ─── FUNGSI SAAT JUZ DIPILIH ─────────────────────────────────────────────────
  void _onJuzSelected(int juzNumber) {
    _fetchAyahByJuz(juzNumber);
    _tabController.animateTo(1); // Pindah ke tab ayat
  }

  // ─── BUILD WIDGET ─────────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _C.bg,
      appBar: _buildAppBar(),
      body: _isLoading
          ? _buildLoadingState()
          : _errorMessage.isNotEmpty
              ? _buildErrorState()
              : _buildMainContent(),
    );
  }

  // ─── BUILD APP BAR ─────────────────────────────────────────────────
  PreferredSizeWidget _buildAppBar() {
    return AppBar(
      title: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            padding: const EdgeInsets.all(6),
            decoration: BoxDecoration(
              color: _C.gold.withOpacity(0.15),
              borderRadius: BorderRadius.circular(8),
            ),
            child: const Icon(Icons.menu_book_rounded, color: _C.gold, size: 18),
          ),
          const SizedBox(width: 10),
          const Text(
            'Al-Quran',
            style: TextStyle(
              color: _C.text,
              fontSize: 18,
              fontWeight: FontWeight.w700,
              letterSpacing: 0.5,
            ),
          ),
        ],
      ),
      backgroundColor: _C.surface,
      elevation: 0,
      centerTitle: true,
      bottom: PreferredSize(
        preferredSize: const Size.fromHeight(1),
        child: Container(height: 1, color: _C.border),
      ),
      leading: IconButton(
        icon: const Icon(Icons.arrow_back_ios_new_rounded, color: _C.textSub),
        onPressed: () => Navigator.pop(context),
      ),
      actions: [
        IconButton(
          icon: const Icon(Icons.refresh_rounded, color: _C.textSub),
          onPressed: _fetchSurahList,
        ),
        const SizedBox(width: 4),
      ],
    );
  }

  // ─── BUILD TAMPILAN LOADING ─────────────────────────────────────────────────
  Widget _buildLoadingState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            width: 60,
            height: 60,
            decoration: BoxDecoration(
              color: _C.surface,
              shape: BoxShape.circle,
              border: Border.all(color: _C.gold.withOpacity(0.3)),
              boxShadow: [
                BoxShadow(
                  color: Colors.white.withOpacity(0.6),
                  blurRadius: 8,
                  offset: const Offset(-2, -2),
                ),
              ],
            ),
            child: const Icon(Icons.menu_book_rounded, color: _C.gold, size: 28),
          ),
          const SizedBox(height: 20),
          const Text(
            'Memuat Al-Quran...',
            style: TextStyle(
              color: _C.textSub,
              fontSize: 14,
              fontWeight: FontWeight.w500,
            ),
          ),
          const SizedBox(height: 16),
          const SizedBox(
            width: 30,
            height: 30,
            child: CircularProgressIndicator(
              color: _C.gold,
              strokeWidth: 2.5,
            ),
          ),
        ],
      ),
    );
  }

  // ─── BUILD TAMPILAN ERROR ─────────────────────────────────────────────────
  Widget _buildErrorState() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 80,
              height: 80,
              decoration: BoxDecoration(
                color: _C.surface,
                shape: BoxShape.circle,
                border: Border.all(color: _C.border),
                boxShadow: [
                  BoxShadow(
                    color: Colors.white.withOpacity(0.6),
                    blurRadius: 8,
                    offset: const Offset(-2, -2),
                  ),
                ],
              ),
              child: const Icon(Icons.error_outline_rounded, color: _C.textDim, size: 36),
            ),
            const SizedBox(height: 20),
            Text(
              _errorMessage,
              style: const TextStyle(
                color: _C.textSub,
                fontSize: 14,
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 24),
            Container(
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [_C.gold, _C.goldLight],
                ),
                borderRadius: BorderRadius.circular(12),
                boxShadow: [
                  BoxShadow(
                    color: _C.gold.withOpacity(0.3),
                    blurRadius: 12,
                    offset: const Offset(0, 4),
                  ),
                  BoxShadow(
                    color: Colors.white.withOpacity(0.6),
                    blurRadius: 6,
                    offset: const Offset(-2, -2),
                  ),
                ],
              ),
              child: ElevatedButton(
                onPressed: _fetchSurahList,
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.transparent,
                  shadowColor: Colors.transparent,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                  padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 14),
                ),
                child: const Text(
                  'Coba Lagi',
                  style: TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.w700,
                    fontSize: 14,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ─── BUILD KONTEN UTAMA ─────────────────────────────────────────────────
  Widget _buildMainContent() {
    return Column(
      children: [
        TabBar(
          controller: _tabController,
          labelColor: _C.gold,
          unselectedLabelColor: _C.textSub,
          indicatorColor: _C.gold,
          indicatorWeight: 3,
          indicatorSize: TabBarIndicatorSize.label,
          labelStyle: const TextStyle(
            fontWeight: FontWeight.w700,
            fontSize: 13,
            letterSpacing: 0.5,
          ),
          unselectedLabelStyle: const TextStyle(
            fontWeight: FontWeight.w500,
            fontSize: 13,
          ),
          tabs: const [
            Tab(text: '📖 Surat'),
            Tab(text: '📜 Ayat'),
          ],
        ),
        Expanded(
          child: TabBarView(
            controller: _tabController,
            children: [
              _buildSurahList(),
              _buildAyahView(),
            ],
          ),
        ),
      ],
    );
  }

  // ─── BUILD DAFTAR SURAT ─────────────────────────────────────────────────
  Widget _buildSurahList() {
    if (_surahList.isEmpty) {
      return _buildEmptyState('Tidak ada surat');
    }

    return ListView.builder(
      padding: const EdgeInsets.all(12),
      itemCount: _surahList.length,
      itemBuilder: (context, index) {
        final surah = _surahList[index];
        final isSelected = index == _selectedSurahIndex;
        return GestureDetector(
          onTap: () => _onSurahSelected(index),
          child: Container(
            margin: const EdgeInsets.only(bottom: 8),
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            decoration: BoxDecoration(
              color: isSelected ? _C.gold.withOpacity(0.08) : _C.surface,
              borderRadius: BorderRadius.circular(14),
              border: Border.all(
                color: isSelected ? _C.gold : _C.border,
                width: isSelected ? 1.5 : 1,
              ),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.03),
                  blurRadius: 8,
                  offset: const Offset(0, 3),
                ),
                BoxShadow(
                  color: Colors.white.withOpacity(0.6),
                  blurRadius: 4,
                  offset: const Offset(-1, -1),
                ),
              ],
            ),
            child: Row(
              children: [
                Container(
                  width: 36,
                  height: 36,
                  decoration: BoxDecoration(
                    color: isSelected ? _C.gold : _C.bg,
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(
                      color: isSelected ? _C.gold : _C.border,
                    ),
                  ),
                  child: Center(
                    child: Text(
                      '${surah['number']}',
                      style: TextStyle(
                        color: isSelected ? _C.gold : _C.textSub,
                        fontSize: 14,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Text(
                            surah['name']['transliteration']['id'] ?? 'Unknown',
                            style: TextStyle(
                              color: isSelected ? _C.gold : _C.text,
                              fontSize: 15,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                          const SizedBox(width: 8),
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                            decoration: BoxDecoration(
                              color: isSelected ? _C.gold.withOpacity(0.15) : _C.bg,
                              borderRadius: BorderRadius.circular(4),
                              border: Border.all(
                                color: isSelected ? _C.gold.withOpacity(0.3) : _C.border,
                              ),
                            ),
                            child: Text(
                              surah['name']['translation']['id'] ?? '',
                              style: TextStyle(
                                color: isSelected ? _C.gold : _C.textSub,
                                fontSize: 10,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 2),
                      Text(
                        '${surah['numberOfVerses']} ayat · ${surah['revelation']['id']}',
                        style: TextStyle(
                          color: isSelected ? _C.gold.withOpacity(0.7) : _C.textSub,
                          fontSize: 11,
                        ),
                      ),
                    ],
                  ),
                ),
                Text(
                  surah['name']['short'] ?? '',
                  style: TextStyle(
                    color: isSelected ? _C.gold : _C.text,
                    fontSize: 18,
                    fontWeight: FontWeight.w700,
                    fontFamily: 'serif',
                  ),
                ),
                const SizedBox(width: 4),
                Icon(
                  isSelected ? Icons.check_circle_rounded : Icons.chevron_right_rounded,
                  color: isSelected ? _C.gold : _C.textDim,
                  size: 20,
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  // ─── BUILD TAMPILAN AYAT ─────────────────────────────────────────────────
  Widget _buildAyahView() {
    if (_isLoadingAyah) {
      return _buildLoadingAyah();
    }

    if (_ayahList.isEmpty) {
      return _buildEmptyState('Pilih surat atau juz untuk melihat ayat');
    }

    return Column(
      children: [
        // Header nama surat
        if (_currentSurahName.isNotEmpty)
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
            margin: const EdgeInsets.only(top: 8, left: 16, right: 16),
            decoration: BoxDecoration(
              color: _C.gold.withOpacity(0.08),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: _C.gold.withOpacity(0.2)),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(Icons.menu_book_rounded, color: _C.gold, size: 16),
                const SizedBox(width: 8),
                Text(
                  _currentSurahName,
                  style: TextStyle(
                    color: _C.gold,
                    fontSize: 14,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ],
            ),
          ),
        Expanded(
          child: ListView.builder(
            padding: const EdgeInsets.all(16),
            itemCount: _ayahList.length,
            itemBuilder: (context, index) {
              final ayah = _ayahList[index];
              final number = ayah['number']?['inSurah'] ?? index + 1;
              return _buildAyahCard(ayah, number);
            },
          ),
        ),
      ],
    );
  }

  // ─── BUILD KARTU AYAT ─────────────────────────────────────────────────
  Widget _buildAyahCard(Map<String, dynamic> ayah, int number) {
    final arabText = ayah['text']['arab'] ?? '';
    final translation = ayah['text']['translation']?['id'] ?? 'Terjemahan tidak tersedia';

    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: _C.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: _C.border),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.03),
            blurRadius: 8,
            offset: const Offset(0, 3),
          ),
          BoxShadow(
            color: Colors.white.withOpacity(0.6),
            blurRadius: 4,
            offset: const Offset(-1, -1),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Nomor ayat
          Row(
            children: [
              Container(
                width: 28,
                height: 28,
                decoration: BoxDecoration(
                  color: _C.gold.withOpacity(0.12),
                  shape: BoxShape.circle,
                  border: Border.all(color: _C.gold.withOpacity(0.3)),
                ),
                child: Center(
                  child: Text(
                    '$number',
                    style: TextStyle(
                      color: _C.gold,
                      fontSize: 12,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 12),
              if (number == 1)
                Expanded(
                  child: Text(
                    'بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ',
                    textAlign: TextAlign.right,
                    style: TextStyle(
                      color: _C.gold,
                      fontSize: 14,
                      fontWeight: FontWeight.w600,
                      fontFamily: 'serif',
                    ),
                  ),
                ),
            ],
          ),
          const SizedBox(height: 12),
          // Teks Arab
          if (arabText.isNotEmpty)
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: _C.bg,
                borderRadius: BorderRadius.circular(12),
              ),
              child: Text(
                arabText,
                textAlign: TextAlign.right,
                style: TextStyle(
                  color: _C.text,
                  fontSize: 22,
                  fontWeight: FontWeight.w600,
                  fontFamily: 'serif',
                  height: 1.8,
                ),
              ),
            ),
          const SizedBox(height: 12),
          // Terjemahan
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: _C.blue.withOpacity(0.04),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: _C.blue.withOpacity(0.1)),
            ),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  width: 20,
                  height: 20,
                  decoration: BoxDecoration(
                    color: _C.blue.withOpacity(0.08),
                    shape: BoxShape.circle,
                  ),
                  child: const Icon(Icons.translate_rounded, color: _C.blue, size: 12),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(
                    translation,
                    style: TextStyle(
                      color: _C.textSub,
                      fontSize: 14,
                      height: 1.6,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ─── BUILD TAMPILAN LOADING AYAT ─────────────────────────────────────────────────
  Widget _buildLoadingAyah() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            width: 50,
            height: 50,
            decoration: BoxDecoration(
              color: _C.surface,
              shape: BoxShape.circle,
              border: Border.all(color: _C.border),
            ),
            child: const Icon(Icons.menu_book_rounded, color: _C.gold, size: 24),
          ),
          const SizedBox(height: 16),
          const Text(
            'Memuat Ayat...',
            style: TextStyle(
              color: _C.textSub,
              fontSize: 13,
              fontWeight: FontWeight.w500,
            ),
          ),
          const SizedBox(height: 12),
          const SizedBox(
            width: 24,
            height: 24,
            child: CircularProgressIndicator(
              color: _C.gold,
              strokeWidth: 2,
            ),
          ),
        ],
      ),
    );
  }

  // ─── BUILD TAMPILAN KOSONG ─────────────────────────────────────────────────
  Widget _buildEmptyState(String message) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            width: 70,
            height: 70,
            decoration: BoxDecoration(
              color: _C.surface,
              shape: BoxShape.circle,
              border: Border.all(color: _C.border),
              boxShadow: [
                BoxShadow(
                  color: Colors.white.withOpacity(0.6),
                  blurRadius: 8,
                  offset: const Offset(-2, -2),
                ),
              ],
            ),
            child: const Icon(Icons.menu_book_rounded, color: _C.textDim, size: 32),
          ),
          const SizedBox(height: 16),
          Text(
            message,
            style: const TextStyle(
              color: _C.textSub,
              fontSize: 14,
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }
}