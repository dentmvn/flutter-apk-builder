// CHESS_GAME.DART - GAME CATUR 3D HD DENGAN TEMA AL-QURAN
import 'package:flutter/material.dart';
import 'dart:math';

// ─── TEMA WARNA AL-QURAN ─────────────────────────────────────────────────────────────
class _C {
  static const bg = Color(0xFFE8EDF2);
  static const surface = Color(0xFFFFFFFF);
  static const border = Color(0xFFD4DCE4);
  static const gold = Color(0xFFC9A94E);
  static const goldLight = Color(0xFFE8D5A3);
  static const blue = Color(0xFF1A73E8);
  static const blueMid = Color(0xFF4285F4);
  static const blueLight = Color(0xFF8AB4F8);
  static const text = Color(0xFF202124);
  static const textSub = Color(0xFF5F6368);
  static const textDim = Color(0xFF9AA0A6);
  static const white = Color(0xFFFFFFFF);
  static const darkSquare = Color(0xFFB58863);
  static const lightSquare = Color(0xFFF0D9B5);
  static const darkSquareGold = Color(0xFFC9A94E);
  static const lightSquareGold = Color(0xFFE8D5A3);
}

// ─── MODEL BIDAK CATUR ─────────────────────────────────────────────────────────────
enum PieceType { pawn, knight, bishop, rook, queen, king }
enum PieceColor { white, black }

class ChessPiece {
  final PieceType type;
  final PieceColor color;
  bool hasMoved = false;

  ChessPiece(this.type, this.color);

  String get symbol {
    switch (type) {
      case PieceType.pawn:
        return color == PieceColor.white ? '♙' : '♟';
      case PieceType.knight:
        return color == PieceColor.white ? '♘' : '♞';
      case PieceType.bishop:
        return color == PieceColor.white ? '♗' : '♝';
      case PieceType.rook:
        return color == PieceColor.white ? '♖' : '♜';
      case PieceType.queen:
        return color == PieceColor.white ? '♕' : '♛';
      case PieceType.king:
        return color == PieceColor.white ? '♔' : '♚';
    }
  }

  String get name {
    switch (type) {
      case PieceType.pawn:
        return 'Pawn';
      case PieceType.knight:
        return 'Knight';
      case PieceType.bishop:
        return 'Bishop';
      case PieceType.rook:
        return 'Rook';
      case PieceType.queen:
        return 'Queen';
      case PieceType.king:
        return 'King';
    }
  }

  @override
  String toString() => '$color $name';
}

// ─── MODEL GERAKAN ─────────────────────────────────────────────────────────────
class Move {
  final int fromRow;
  final int fromCol;
  final int toRow;
  final int toCol;
  final ChessPiece? piece;
  final ChessPiece? captured;

  Move({
    required this.fromRow,
    required this.fromCol,
    required this.toRow,
    required this.toCol,
    this.piece,
    this.captured,
  });

  @override
  String toString() => '${String.fromCharCode(97 + fromCol)}${8 - fromRow} -> ${String.fromCharCode(97 + toCol)}${8 - toRow}';
}

// ─── STATE PERMAINAN CATUR ─────────────────────────────────────────────────────────────
class ChessGame {
  List<List<ChessPiece?>> board = [];
  PieceColor currentTurn = PieceColor.white;
  List<Move> moveHistory = [];
  bool isCheck = false;
  bool isCheckmate = false;
  bool isStalemate = false;
  ChessPiece? selectedPiece;
  int? selectedRow;
  int? selectedCol;
  List<List<int>> validMoves = [];
  bool isPromotion = false;
  int promotionRow = -1;
  int promotionCol = -1;

  ChessGame() {
    _initializeBoard();
  }

  void _initializeBoard() {
    board = List.generate(8, (row) => List.generate(8, (col) => null));

    // Setup pawns
    for (int col = 0; col < 8; col++) {
      board[1][col] = ChessPiece(PieceType.pawn, PieceColor.black);
      board[6][col] = ChessPiece(PieceType.pawn, PieceColor.white);
    }

    // Setup other pieces
    final backRow = [
      PieceType.rook,
      PieceType.knight,
      PieceType.bishop,
      PieceType.queen,
      PieceType.king,
      PieceType.bishop,
      PieceType.knight,
      PieceType.rook,
    ];

    for (int col = 0; col < 8; col++) {
      board[0][col] = ChessPiece(backRow[col], PieceColor.black);
      board[7][col] = ChessPiece(backRow[col], PieceColor.white);
    }

    currentTurn = PieceColor.white;
    moveHistory.clear();
    isCheck = false;
    isCheckmate = false;
    isStalemate = false;
    selectedPiece = null;
    selectedRow = null;
    selectedCol = null;
    validMoves = [];
    isPromotion = false;
  }

  // ─── GET PIECE AT POSITION ─────────────────────────────────────────────
  ChessPiece? getPiece(int row, int col) {
    if (row < 0 || row > 7 || col < 0 || col > 7) return null;
    return board[row][col];
  }

  // ─── GET VALID MOVES FOR PIECE ─────────────────────────────────────────────
  List<List<int>> getValidMoves(int row, int col) {
    final piece = getPiece(row, col);
    if (piece == null) return [];
    if (piece.color != currentTurn) return [];

    List<List<int>> moves = [];

    switch (piece.type) {
      case PieceType.pawn:
        moves = _getPawnMoves(row, col, piece);
        break;
      case PieceType.knight:
        moves = _getKnightMoves(row, col, piece);
        break;
      case PieceType.bishop:
        moves = _getBishopMoves(row, col, piece);
        break;
      case PieceType.rook:
        moves = _getRookMoves(row, col, piece);
        break;
      case PieceType.queen:
        moves = _getQueenMoves(row, col, piece);
        break;
      case PieceType.king:
        moves = _getKingMoves(row, col, piece);
        break;
    }

    // Filter moves that would leave king in check
    return moves.where((move) {
      return !_wouldBeInCheck(row, col, move[0], move[1], piece);
    }).toList();
  }

  // ─── PAWN MOVES ─────────────────────────────────────────────
  List<List<int>> _getPawnMoves(int row, int col, ChessPiece piece) {
    List<List<int>> moves = [];
    int direction = piece.color == PieceColor.white ? -1 : 1;
    int startRow = piece.color == PieceColor.white ? 6 : 1;

    // Move forward
    int newRow = row + direction;
    if (newRow >= 0 && newRow <= 7 && getPiece(newRow, col) == null) {
      moves.add([newRow, col]);
      // Double move from start
      if (row == startRow) {
        int newRow2 = row + 2 * direction;
        if (getPiece(newRow2, col) == null) {
          moves.add([newRow2, col]);
        }
      }
    }

    // Capture diagonally
    for (int dCol in [-1, 1]) {
      int newCol = col + dCol;
      if (newCol >= 0 && newCol <= 7 && newRow >= 0 && newRow <= 7) {
        final target = getPiece(newRow, newCol);
        if (target != null && target.color != piece.color) {
          moves.add([newRow, newCol]);
        }
        // En passant
        if (moveHistory.isNotEmpty) {
          final lastMove = moveHistory.last;
          if (lastMove.piece?.type == PieceType.pawn &&
              (lastMove.fromRow - lastMove.toRow).abs() == 2 &&
              lastMove.toRow == row &&
              lastMove.toCol == newCol) {
            moves.add([newRow, newCol]);
          }
        }
      }
    }

    return moves;
  }

  // ─── KNIGHT MOVES ─────────────────────────────────────────────
  List<List<int>> _getKnightMoves(int row, int col, ChessPiece piece) {
    List<List<int>> moves = [];
    final offsets = [
      [-2, -1],
      [-2, 1],
      [-1, -2],
      [-1, 2],
      [1, -2],
      [1, 2],
      [2, -1],
      [2, 1]
    ];

    for (var offset in offsets) {
      int newRow = row + offset[0];
      int newCol = col + offset[1];
      if (newRow >= 0 && newRow <= 7 && newCol >= 0 && newCol <= 7) {
        final target = getPiece(newRow, newCol);
        if (target == null || target.color != piece.color) {
          moves.add([newRow, newCol]);
        }
      }
    }
    return moves;
  }

  // ─── BISHOP MOVES ─────────────────────────────────────────────
  List<List<int>> _getBishopMoves(int row, int col, ChessPiece piece) {
    List<List<int>> moves = [];
    final directions = [
      [-1, -1],
      [-1, 1],
      [1, -1],
      [1, 1]
    ];

    for (var dir in directions) {
      for (int i = 1; i < 8; i++) {
        int newRow = row + dir[0] * i;
        int newCol = col + dir[1] * i;
        if (newRow < 0 || newRow > 7 || newCol < 0 || newCol > 7) break;
        final target = getPiece(newRow, newCol);
        if (target != null) {
          if (target.color != piece.color) moves.add([newRow, newCol]);
          break;
        }
        moves.add([newRow, newCol]);
      }
    }
    return moves;
  }

  // ─── ROOK MOVES ─────────────────────────────────────────────
  List<List<int>> _getRookMoves(int row, int col, ChessPiece piece) {
    List<List<int>> moves = [];
    final directions = [
      [-1, 0],
      [1, 0],
      [0, -1],
      [0, 1]
    ];

    for (var dir in directions) {
      for (int i = 1; i < 8; i++) {
        int newRow = row + dir[0] * i;
        int newCol = col + dir[1] * i;
        if (newRow < 0 || newRow > 7 || newCol < 0 || newCol > 7) break;
        final target = getPiece(newRow, newCol);
        if (target != null) {
          if (target.color != piece.color) moves.add([newRow, newCol]);
          break;
        }
        moves.add([newRow, newCol]);
      }
    }
    return moves;
  }

  // ─── QUEEN MOVES ─────────────────────────────────────────────
  List<List<int>> _getQueenMoves(int row, int col, ChessPiece piece) {
    return _getBishopMoves(row, col, piece) + _getRookMoves(row, col, piece);
  }

  // ─── KING MOVES ─────────────────────────────────────────────
  List<List<int>> _getKingMoves(int row, int col, ChessPiece piece) {
    List<List<int>> moves = [];
    for (int dRow = -1; dRow <= 1; dRow++) {
      for (int dCol = -1; dCol <= 1; dCol++) {
        if (dRow == 0 && dCol == 0) continue;
        int newRow = row + dRow;
        int newCol = col + dCol;
        if (newRow >= 0 && newRow <= 7 && newCol >= 0 && newCol <= 7) {
          final target = getPiece(newRow, newCol);
          if (target == null || target.color != piece.color) {
            // Check if target square is under attack
            if (!_isSquareAttacked(newRow, newCol, piece.color)) {
              moves.add([newRow, newCol]);
            }
          }
        }
      }
    }

    // Castling
    if (!piece.hasMoved && !isInCheck(piece.color)) {
      // King side
      if (_canCastle(row, col, piece, 1)) {
        moves.add([row, col + 2]);
      }
      // Queen side
      if (_canCastle(row, col, piece, -1)) {
        moves.add([row, col - 2]);
      }
    }

    return moves;
  }

  bool _canCastle(int row, int col, ChessPiece piece, int direction) {
    int kingCol = col;
    int rookCol = direction == 1 ? 7 : 0;
    final rook = getPiece(row, rookCol);
    if (rook == null || rook.type != PieceType.rook || rook.hasMoved) return false;

    // Check if squares between king and rook are empty
    int step = direction;
    for (int c = kingCol + step; c != rookCol; c += step) {
      if (getPiece(row, c) != null) return false;
    }

    // Check if king passes through attacked squares
    for (int c = kingCol; c != kingCol + 2 * step + step; c += step) {
      if (_isSquareAttacked(row, c, piece.color)) return false;
    }

    return true;
  }

  // ─── CHECK ATTACKS ─────────────────────────────────────────────
  bool _isSquareAttacked(int row, int col, PieceColor defendingColor) {
    PieceColor attackingColor = defendingColor == PieceColor.white ? PieceColor.black : PieceColor.white;

    // Check all pieces of attacking color
    for (int r = 0; r < 8; r++) {
      for (int c = 0; c < 8; c++) {
        final piece = getPiece(r, c);
        if (piece == null || piece.color != attackingColor) continue;

        List<List<int>> attacks = [];
        switch (piece.type) {
          case PieceType.pawn:
            int direction = piece.color == PieceColor.white ? -1 : 1;
            for (int dCol in [-1, 1]) {
              int newRow = r + direction;
              int newCol = c + dCol;
              if (newRow >= 0 && newRow <= 7 && newCol >= 0 && newCol <= 7) {
                attacks.add([newRow, newCol]);
              }
            }
            break;
          case PieceType.knight:
            final offsets = [
              [-2, -1],
              [-2, 1],
              [-1, -2],
              [-1, 2],
              [1, -2],
              [1, 2],
              [2, -1],
              [2, 1]
            ];
            for (var offset in offsets) {
              int newRow = r + offset[0];
              int newCol = c + offset[1];
              if (newRow >= 0 && newRow <= 7 && newCol >= 0 && newCol <= 7) {
                attacks.add([newRow, newCol]);
              }
            }
            break;
          case PieceType.bishop:
            final bDirs = [
              [-1, -1],
              [-1, 1],
              [1, -1],
              [1, 1]
            ];
            for (var dir in bDirs) {
              for (int i = 1; i < 8; i++) {
                int newRow = r + dir[0] * i;
                int newCol = c + dir[1] * i;
                if (newRow < 0 || newRow > 7 || newCol < 0 || newCol > 7) break;
                final target = getPiece(newRow, newCol);
                if (target != null) {
                  if (target.color != piece.color) attacks.add([newRow, newCol]);
                  break;
                }
                attacks.add([newRow, newCol]);
              }
            }
            break;
          case PieceType.rook:
            final rDirs = [
              [-1, 0],
              [1, 0],
              [0, -1],
              [0, 1]
            ];
            for (var dir in rDirs) {
              for (int i = 1; i < 8; i++) {
                int newRow = r + dir[0] * i;
                int newCol = c + dir[1] * i;
                if (newRow < 0 || newRow > 7 || newCol < 0 || newCol > 7) break;
                final target = getPiece(newRow, newCol);
                if (target != null) {
                  if (target.color != piece.color) attacks.add([newRow, newCol]);
                  break;
                }
                attacks.add([newRow, newCol]);
              }
            }
            break;
          case PieceType.queen:
            final qDirs = [
              [-1, -1],
              [-1, 0],
              [-1, 1],
              [0, -1],
              [0, 1],
              [1, -1],
              [1, 0],
              [1, 1]
            ];
            for (var dir in qDirs) {
              for (int i = 1; i < 8; i++) {
                int newRow = r + dir[0] * i;
                int newCol = c + dir[1] * i;
                if (newRow < 0 || newRow > 7 || newCol < 0 || newCol > 7) break;
                final target = getPiece(newRow, newCol);
                if (target != null) {
                  if (target.color != piece.color) attacks.add([newRow, newCol]);
                  break;
                }
                attacks.add([newRow, newCol]);
              }
            }
            break;
          case PieceType.king:
            for (int dRow = -1; dRow <= 1; dRow++) {
              for (int dCol = -1; dCol <= 1; dCol++) {
                if (dRow == 0 && dCol == 0) continue;
                int newRow = r + dRow;
                int newCol = c + dCol;
                if (newRow >= 0 && newRow <= 7 && newCol >= 0 && newCol <= 7) {
                  attacks.add([newRow, newCol]);
                }
              }
            }
            break;
        }

        if (attacks.any((attack) => attack[0] == row && attack[1] == col)) {
          return true;
        }
      }
    }
    return false;
  }

  bool isInCheck(PieceColor color) {
    // Find king
    for (int r = 0; r < 8; r++) {
      for (int c = 0; c < 8; c++) {
        final piece = getPiece(r, c);
        if (piece != null && piece.type == PieceType.king && piece.color == color) {
          return _isSquareAttacked(r, c, color);
        }
      }
    }
    return false;
  }

  bool _wouldBeInCheck(int fromRow, int fromCol, int toRow, int toCol, ChessPiece piece) {
    // Simulate move
    final captured = getPiece(toRow, toCol);
    board[toRow][toCol] = piece;
    board[fromRow][fromCol] = null;

    bool inCheck = isInCheck(piece.color);

    // Undo
    board[fromRow][fromCol] = piece;
    board[toRow][toCol] = captured;

    return inCheck;
  }

  // ─── MAKE MOVE ─────────────────────────────────────────────
  bool makeMove(int fromRow, int fromCol, int toRow, int toCol) {
    final piece = getPiece(fromRow, fromCol);
    if (piece == null) return false;

    final validMoves = getValidMoves(fromRow, fromCol);
    bool isValid = validMoves.any((move) => move[0] == toRow && move[1] == toCol);
    if (!isValid) return false;

    final captured = getPiece(toRow, toCol);
    Move move = Move(
      fromRow: fromRow,
      fromCol: fromCol,
      toRow: toRow,
      toCol: toCol,
      piece: piece,
      captured: captured,
    );

    // Check for promotion
    if (piece.type == PieceType.pawn && (toRow == 0 || toRow == 7)) {
      isPromotion = true;
      promotionRow = toRow;
      promotionCol = toCol;
      moveHistory.add(move);
      return true;
    }

    _executeMove(fromRow, fromCol, toRow, toCol, piece);

    // Castling
    if (piece.type == PieceType.king && (toCol - fromCol).abs() == 2) {
      // Move rook
      int rookFromCol = toCol > fromCol ? 7 : 0;
      int rookToCol = toCol > fromCol ? toCol - 1 : toCol + 1;
      final rook = getPiece(fromRow, rookFromCol);
      if (rook != null) {
        board[fromRow][rookToCol] = rook;
        board[fromRow][rookFromCol] = null;
        rook.hasMoved = true;
      }
    }

    moveHistory.add(move);
    piece.hasMoved = true;

    // Switch turn
    currentTurn = currentTurn == PieceColor.white ? PieceColor.black : PieceColor.white;

    // Check game state
    _updateGameState();

    return true;
  }

  void _executeMove(int fromRow, int fromCol, int toRow, int toCol, ChessPiece piece) {
    board[toRow][toCol] = piece;
    board[fromRow][fromCol] = null;
  }

  // ─── PROMOTE PAWN (FIXED) ─────────────────────────────────────────────
  void promotePawn(int row, int col, PieceType type) {
    if (!isPromotion) return;
    final piece = getPiece(row, col);
    if (piece == null || piece.type != PieceType.pawn) return;

    // Ganti pawn dengan piece baru
    board[row][col] = ChessPiece(type, piece.color);
    isPromotion = false;

    // Update move history
    if (moveHistory.isNotEmpty) {
      final lastMove = moveHistory.last;
      // Buat move baru dengan piece yang sudah di-promote
      final newMove = Move(
        fromRow: lastMove.fromRow,
        fromCol: lastMove.fromCol,
        toRow: lastMove.toRow,
        toCol: lastMove.toCol,
        piece: board[row][col],
        captured: lastMove.captured,
      );
      // Ganti move terakhir
      moveHistory.removeLast();
      moveHistory.add(newMove);
    }

    currentTurn = currentTurn == PieceColor.white ? PieceColor.black : PieceColor.white;
    _updateGameState();
  }

  void _updateGameState() {
    isCheck = isInCheck(currentTurn);

    // Check if any valid moves exist
    bool hasValidMoves = false;
    for (int r = 0; r < 8; r++) {
      for (int c = 0; c < 8; c++) {
        final piece = getPiece(r, c);
        if (piece != null && piece.color == currentTurn) {
          if (getValidMoves(r, c).isNotEmpty) {
            hasValidMoves = true;
            break;
          }
        }
      }
      if (hasValidMoves) break;
    }

    if (!hasValidMoves) {
      if (isCheck) {
        isCheckmate = true;
      } else {
        isStalemate = true;
      }
    }
  }

  // ─── GET KING POSITION ─────────────────────────────────────────────
  List<int>? findKing(PieceColor color) {
    for (int r = 0; r < 8; r++) {
      for (int c = 0; c < 8; c++) {
        final piece = getPiece(r, c);
        if (piece != null && piece.type == PieceType.king && piece.color == color) {
          return [r, c];
        }
      }
    }
    return null;
  }
}

// ─── MAIN WIDGET ─────────────────────────────────────────────────────────────
class ChessGameApp extends StatelessWidget {
  const ChessGameApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Chess Game',
      theme: ThemeData(
        brightness: Brightness.light,
        primaryColor: _C.gold,
        scaffoldBackgroundColor: _C.bg,
        appBarTheme: const AppBarTheme(
          backgroundColor: _C.surface,
          foregroundColor: _C.text,
          elevation: 0,
          centerTitle: true,
        ),
      ),
      debugShowCheckedModeBanner: false,
      home: const ChessHomePage(),
    );
  }
}

// ─── HOME PAGE ─────────────────────────────────────────────────────────────
class ChessHomePage extends StatefulWidget {
  const ChessHomePage({super.key});

  @override
  State<ChessHomePage> createState() => _ChessHomePageState();
}

class _ChessHomePageState extends State<ChessHomePage> {
  late ChessGame _game;
  bool _isGameOver = false;
  String _gameStatus = '';
  bool _showPromotion = false;

  @override
  void initState() {
    super.initState();
    _game = ChessGame();
  }

  void _resetGame() {
    setState(() {
      _game = ChessGame();
      _isGameOver = false;
      _gameStatus = '';
      _showPromotion = false;
    });
  }

  void _onSquareTap(int row, int col) {
    if (_isGameOver || _game.isPromotion) return;

    setState(() {
      final piece = _game.getPiece(row, col);

      // If piece is selected and tapping on valid move
      if (_game.selectedPiece != null &&
          _game.selectedRow != null &&
          _game.selectedCol != null) {
        bool isValid = _game.validMoves.any((move) => move[0] == row && move[1] == col);
        if (isValid) {
          bool success = _game.makeMove(
            _game.selectedRow!,
            _game.selectedCol!,
            row,
            col,
          );

          if (success) {
            _game.selectedPiece = null;
            _game.selectedRow = null;
            _game.selectedCol = null;
            _game.validMoves = [];

            if (_game.isCheckmate) {
              _isGameOver = true;
              _gameStatus = 'Checkmate! ${_game.currentTurn == PieceColor.white ? "Black" : "White"} wins!';
            } else if (_game.isStalemate) {
              _isGameOver = true;
              _gameStatus = 'Stalemate! Draw!';
            } else if (_game.isCheck) {
              _gameStatus = 'Check!';
            } else {
              _gameStatus = '';
            }

            if (_game.isPromotion) {
              _showPromotion = true;
            }
          }
          return;
        }

        // If tapping on own piece, select it
        if (piece != null && piece.color == _game.currentTurn) {
          _game.selectedPiece = piece;
          _game.selectedRow = row;
          _game.selectedCol = col;
          _game.validMoves = _game.getValidMoves(row, col);
          return;
        }

        // Deselect
        _game.selectedPiece = null;
        _game.selectedRow = null;
        _game.selectedCol = null;
        _game.validMoves = [];
        return;
      }

      // Select piece
      if (piece != null && piece.color == _game.currentTurn) {
        _game.selectedPiece = piece;
        _game.selectedRow = row;
        _game.selectedCol = col;
        _game.validMoves = _game.getValidMoves(row, col);
      }
    });
  }

  void _promotePawn(PieceType type) {
    setState(() {
      _game.promotePawn(_game.promotionRow, _game.promotionCol, type);
      _showPromotion = false;

      if (_game.isCheckmate) {
        _isGameOver = true;
        _gameStatus = 'Checkmate! ${_game.currentTurn == PieceColor.white ? "Black" : "White"} wins!';
      } else if (_game.isStalemate) {
        _isGameOver = true;
        _gameStatus = 'Stalemate! Draw!';
      } else if (_game.isCheck) {
        _gameStatus = 'Check!';
      } else {
        _gameStatus = '';
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _C.bg,
      appBar: AppBar(
        title: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              padding: const EdgeInsets.all(6),
              decoration: BoxDecoration(
                color: _C.gold.withOpacity(0.15),
                borderRadius: BorderRadius.circular(8),
              ),
              child: const Icon(Icons.games_rounded, color: _C.gold, size: 18),
            ),
            const SizedBox(width: 10),
            const Text(
              'Chess Game',
              style: TextStyle(
                color: _C.text,
                fontSize: 18,
                fontWeight: FontWeight.w700,
                letterSpacing: 0.5,
              ),
            ),
          ],
        ),
        backgroundColor: _C.surface,
        elevation: 0,
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(1),
          child: Container(height: 1, color: _C.border),
        ),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new_rounded, color: _C.textSub),
          onPressed: () => Navigator.pop(context),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh_rounded, color: _C.textSub),
            onPressed: _resetGame,
          ),
          const SizedBox(width: 4),
        ],
      ),
      body: Stack(
        children: [
          Center(
            child: Container(
              padding: const EdgeInsets.all(16),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  // Status Bar
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                    margin: const EdgeInsets.only(bottom: 12),
                    decoration: BoxDecoration(
                      color: _C.surface,
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: _C.border),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(0.03),
                          blurRadius: 8,
                          offset: const Offset(0, 3),
                        ),
                      ],
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Row(
                          children: [
                            Container(
                              width: 12,
                              height: 12,
                              decoration: BoxDecoration(
                                color: _game.currentTurn == PieceColor.white ? _C.white : _C.text,
                                shape: BoxShape.circle,
                                border: Border.all(color: _C.border),
                              ),
                            ),
                            const SizedBox(width: 8),
                            Text(
                              _game.currentTurn == PieceColor.white ? 'White turn' : 'Black turn',
                              style: const TextStyle(
                                color: _C.text,
                                fontSize: 14,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ],
                        ),
                        if (_gameStatus.isNotEmpty)
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                            decoration: BoxDecoration(
                              color: _game.isCheckmate ? _C.gold.withOpacity(0.2) :
                                     _game.isCheck ? _C.blue.withOpacity(0.15) :
                                     _C.bg,
                              borderRadius: BorderRadius.circular(8),
                              border: Border.all(
                                color: _game.isCheckmate ? _C.gold :
                                       _game.isCheck ? _C.blue :
                                       _C.border,
                              ),
                            ),
                            child: Text(
                              _gameStatus,
                              style: TextStyle(
                                color: _game.isCheckmate ? _C.gold :
                                       _game.isCheck ? _C.blue :
                                       _C.textSub,
                                fontSize: 12,
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                          ),
                      ],
                    ),
                  ),
                  // Chess Board
                  Container(
                    constraints: const BoxConstraints(maxWidth: 400, maxHeight: 400),
                    child: AspectRatio(
                      aspectRatio: 1,
                      child: Container(
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(16),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.black.withOpacity(0.15),
                              blurRadius: 20,
                              offset: const Offset(0, 8),
                            ),
                            BoxShadow(
                              color: Colors.white.withOpacity(0.6),
                              blurRadius: 10,
                              offset: const Offset(-2, -2),
                            ),
                          ],
                        ),
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(16),
                          child: Container(
                            decoration: BoxDecoration(
                              border: Border.all(color: _C.gold, width: 3),
                              borderRadius: BorderRadius.circular(16),
                            ),
                            child: GridView.builder(
                              physics: const NeverScrollableScrollPhysics(),
                              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                                crossAxisCount: 8,
                              ),
                              itemCount: 64,
                              itemBuilder: (context, index) {
                                int row = index ~/ 8;
                                int col = index % 8;
                                bool isDark = (row + col) % 2 == 1;
                                final piece = _game.getPiece(row, col);
                                bool isSelected = _game.selectedRow == row &&
                                    _game.selectedCol == col;
                                bool isValidMove = _game.validMoves.any(
                                    (move) => move[0] == row && move[1] == col);
                                bool isLastMove = false;
                                if (_game.moveHistory.isNotEmpty) {
                                  final lastMove = _game.moveHistory.last;
                                  isLastMove =
                                      (lastMove.toRow == row && lastMove.toCol == col) ||
                                      (lastMove.fromRow == row && lastMove.fromCol == col);
                                }
                                bool isKingInCheck = false;
                                if (_game.isCheck) {
                                  final kingPos = _game.findKing(_game.currentTurn);
                                  if (kingPos != null &&
                                      kingPos[0] == row &&
                                      kingPos[1] == col) {
                                    isKingInCheck = true;
                                  }
                                }

                                return GestureDetector(
                                  onTap: () => _onSquareTap(row, col),
                                  child: Container(
                                    decoration: BoxDecoration(
                                      color: isDark ? _C.darkSquareGold : _C.lightSquareGold,
                                      border: isLastMove
                                          ? Border.all(color: _C.gold, width: 3)
                                          : isKingInCheck
                                              ? Border.all(color: Colors.red, width: 3)
                                              : null,
                                      boxShadow: isSelected
                                          ? [
                                              BoxShadow(
                                                color: _C.gold.withOpacity(0.5),
                                                spreadRadius: 2,
                                                blurRadius: 8,
                                              ),
                                            ]
                                          : null,
                                    ),
                                    child: Stack(
                                      children: [
                                        Center(
                                          child: piece != null
                                              ? Container(
                                                  decoration: BoxDecoration(
                                                    shape: BoxShape.circle,
                                                    gradient: LinearGradient(
                                                      begin: Alignment.topLeft,
                                                      end: Alignment.bottomRight,
                                                      colors: piece.color == PieceColor.white
                                                          ? [Colors.white, Colors.grey.shade200]
                                                          : [Colors.grey.shade800, Colors.black],
                                                    ),
                                                    boxShadow: [
                                                      BoxShadow(
                                                        color: Colors.black.withOpacity(0.3),
                                                        blurRadius: 6,
                                                        offset: const Offset(0, 3),
                                                      ),
                                                    ],
                                                  ),
                                                  child: Padding(
                                                    padding: const EdgeInsets.all(2.0),
                                                    child: Text(
                                                      piece.symbol,
                                                      style: TextStyle(
                                                        fontSize: MediaQuery.of(context).size.width < 400 ? 28 : 36,
                                                        color: piece.color == PieceColor.white
                                                            ? _C.text
                                                            : Colors.white,
                                                        fontWeight: FontWeight.bold,
                                                        shadows: const [
                                                          Shadow(
                                                            blurRadius: 2,
                                                            color: Colors.black26,
                                                            offset: Offset(1, 1),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ),
                                                )
                                              : null,
                                        ),
                                        if (isValidMove)
                                          Container(
                                            decoration: BoxDecoration(
                                              color: piece == null
                                                  ? _C.gold.withOpacity(0.3)
                                                  : _C.gold.withOpacity(0.15),
                                              shape: piece == null ? BoxShape.circle : BoxShape.rectangle,
                                              border: piece != null
                                                  ? Border.all(color: _C.gold, width: 2)
                                                  : null,
                                            ),
                                            child: piece == null
                                                ? Center(
                                                    child: Container(
                                                      width: 16,
                                                      height: 16,
                                                      decoration: BoxDecoration(
                                                        color: _C.gold,
                                                        shape: BoxShape.circle,
                                                        boxShadow: [
                                                          BoxShadow(
                                                            color: _C.gold.withOpacity(0.5),
                                                            blurRadius: 4,
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  )
                                                : null,
                                          ),
                                      ],
                                    ),
                                  ),
                                );
                              },
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  // Game Over Message
                  if (_isGameOver)
                    Container(
                      margin: const EdgeInsets.only(top: 20),
                      padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                      decoration: BoxDecoration(
                        gradient: const LinearGradient(
                          colors: [_C.gold, _C.goldLight],
                        ),
                        borderRadius: BorderRadius.circular(12),
                        boxShadow: [
                          BoxShadow(
                            color: _C.gold.withOpacity(0.3),
                            blurRadius: 12,
                            offset: const Offset(0, 4),
                          ),
                        ],
                      ),
                      child: Text(
                        _gameStatus,
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 18,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ),
                ],
              ),
            ),
          ),
          // Promotion Dialog
          if (_showPromotion)
            Center(
              child: Container(
                padding: const EdgeInsets.all(24),
                decoration: BoxDecoration(
                  color: _C.surface,
                  borderRadius: BorderRadius.circular(20),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.3),
                      blurRadius: 30,
                      offset: const Offset(0, 10),
                    ),
                  ],
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Text(
                      'Promote Pawn',
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.w700,
                        color: _C.text,
                      ),
                    ),
                    const SizedBox(height: 16),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        _buildPromotionButton(PieceType.queen),
                        _buildPromotionButton(PieceType.rook),
                        _buildPromotionButton(PieceType.bishop),
                        _buildPromotionButton(PieceType.knight),
                      ],
                    ),
                  ],
                ),
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildPromotionButton(PieceType type) {
    final color = _game.currentTurn == PieceColor.white ? PieceColor.black : PieceColor.white;
    final piece = ChessPiece(type, color);
    return GestureDetector(
      onTap: () => _promotePawn(type),
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 8),
        width: 60,
        height: 60,
        decoration: BoxDecoration(
          color: _C.bg,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: _C.gold, width: 2),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.1),
              blurRadius: 8,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Center(
          child: Text(
            piece.symbol,
            style: TextStyle(
              fontSize: 36,
              color: color == PieceColor.white ? _C.text : Colors.black,
            ),
          ),
        ),
      ),
    );
  }
}