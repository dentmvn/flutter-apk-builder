import 'package:flutter/material.dart';
import 'dart:math' as math;

void main() {
  runApp(const MaterialApp(
    debugShowCheckedModeBanner: false,
    home: DrawingPage(),
  ));
}

class DrawingPage extends StatefulWidget {
  const DrawingPage({super.key});

  @override
  State<DrawingPage> createState() => _DrawingPageState();
}

class _DrawingPageState extends State<DrawingPage> {
  // 1. Variabel State
  List<DrawingPoint?> points = []; // List titik gambar
  Color selectedColor = Colors.white;
  double strokeWidth = 5.0;
  bool isEraser = false;
  Color backgroundColor = Colors.black; // Warna background canvas

  // Daftar warna favorit (Pallete)
  final List<Color> colors = [
    Colors.white,
    Colors.red,
    Color(0xFF8B0000), // Dark Red
    Colors.blue,
    Colors.green,
    Colors.yellow,
    Colors.purple,
    Colors.orange,
    Colors.pink,
  ];

  // 2. Logika Gambar
  void _onPanStart(DragStartDetails details) {
    _addPoint(details.localPosition);
  }

  void _onPanUpdate(DragUpdateDetails details) {
    _addPoint(details.localPosition);
  }

  void _onPanEnd(DragEndDetails details) {
    // Tambahkan null sebagai penanda garis berhenti (lift the pen)
    setState(() {
      points.add(null);
    });
  }

  void _addPoint(Offset position) {
    setState(() {
      points.add(DrawingPoint(
        point: position,
        paint: Paint()
          ..color = isEraser ? backgroundColor : selectedColor
          ..strokeWidth = strokeWidth
          ..strokeCap = StrokeCap.round
          ..style = PaintingStyle.stroke,
      ));
    });
  }

  void _clearCanvas() {
    setState(() {
      points.clear();
    });
  }

  void _toggleEraser() {
    setState(() {
      isEraser = !isEraser;
    });
  }

  // 3. Build UI
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF7F8FC),
      appBar: AppBar(
        title: const Text("PPL DRAWING CANVAS", style: TextStyle(fontWeight: FontWeight.bold)),
        centerTitle: true,
        backgroundColor: const Color(0xFFF7F8FC),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh, color: const Color(0xFFFFC52E)),
            onPressed: _clearCanvas,
            tooltip: "Hapus Semua",
          )
        ],
      ),
      body: Column(
        children: [
          // Area Canvas Utama
          Expanded(
            child: ClipRRect(
              child: GestureDetector(
                onPanStart: _onPanStart,
                onPanUpdate: _onPanUpdate,
                onPanEnd: _onPanEnd,
                child: CustomPaint(
                  painter: DrawingPainter(points),
                  size: Size.infinite,
                ),
              ),
            ),
          ),
          
          // Toolbar Bawah
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 15),
            decoration: BoxDecoration(
              color: Colors.white,
              boxShadow: [
                BoxShadow(
                  color: const Color(0xFFFFC52E).withOpacity(0.2),
                  blurRadius: 10,
                  offset: const Offset(0, -3),
                ),
              ],
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                // Row Atas: Slider Ukuran
                Row(
                  children: [
                    Icon(Icons.brush, color: Colors.grey[400]),
                    Expanded(
                      child: Slider(
                        value: strokeWidth,
                        min: 1,
                        max: 50,
                        activeColor: const Color(0xFF1698E5),
                        inactiveColor: Colors.grey[700],
                        onChanged: (val) {
                          setState(() {
                            strokeWidth = val;
                          });
                        },
                      ),
                    ),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                      decoration: BoxDecoration(
                        color: Colors.black,
                        borderRadius: BorderRadius.circular(8),
                        border: Border.all(color: const Color(0xFFFFC52E)),
                      ),
                      child: Text("${strokeWidth.toInt()} px", style: TextStyle(color: Colors.white, fontSize: 12)),
                    ),
                  ],
                ),
                
                const SizedBox(height: 10),
                
                // Row Bawah: Warna & Tools
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    // Tombol Eraser
                    IconButton(
                      icon: Icon(
                        Icons.cleaning_services_rounded,
                        color: isEraser ? Colors.red : Colors.grey[500],
                        size: 30,
                      ),
                      onPressed: _toggleEraser,
                      tooltip: "Penghapus",
                    ),
                    
                    // Palet Warna
                    Expanded(
                      child: SingleChildScrollView(
                        scrollDirection: Axis.horizontal,
                        child: Row(
                          children: colors.map((color) {
                            return GestureDetector(
                              onTap: () {
                                setState(() {
                                  selectedColor = color;
                                  isEraser = false; // Matikan eraser saat pilih warna
                                });
                              },
                              child: Container(
                                margin: const EdgeInsets.symmetric(horizontal: 4),
                                width: 35,
                                height: 35,
                                decoration: BoxDecoration(
                                  color: color,
                                  shape: BoxShape.circle,
                                  border: Border.all(
                                    color: selectedColor == color && !isEraser 
                                        ? Colors.white 
                                        : Colors.transparent,
                                    width: 3,
                                  ),
                                  boxShadow: [
                                    if (color == Colors.black || color == Colors.grey[900])
                                      BoxShadow(color: Colors.white24, blurRadius: 2)
                                  ],
                                ),
                              ),
                            );
                          }).toList(),
                        ),
                      ),
                    ),
                    
                    // Color Picker Custom (Opsional)
                    IconButton(
                      icon: Icon(Icons.colorize, color: Colors.grey[400]),
                      onPressed: () {
                        // Logika color picker sederhana
                        showDialog(
                          context: context,
                          builder: (context) => AlertDialog(
                            backgroundColor: Colors.grey[900],
                            title: Text("Pilih Warna", style: TextStyle(color: Colors.white)),
                            content: SingleChildScrollView(
                              child: ColorPickerWidget(
                                pickedColor: selectedColor,
                                onColorChanged: (color) {
                                  setState(() {
                                    selectedColor = color;
                                    isEraser = false;
                                  });
                                  Navigator.pop(context);
                                },
                              ),
                            ),
                          ),
                        );
                      },
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// 4. Class Model Titik
class DrawingPoint {
  final Offset point;
  final Paint paint;

  DrawingPoint({required this.point, required this.paint});
}

// 5. Class CustomPainter
class DrawingPainter extends CustomPainter {
  final List<DrawingPoint?> points;

  DrawingPainter(this.points);

  @override
  void paint(Canvas canvas, Size size) {
    for (int i = 0; i < points.length - 1; i++) {
      // Jika titik sekarang dan selanjutnya tidak null, gambar garis
      if (points[i] != null && points[i + 1] != null) {
        canvas.drawLine(
          points[i]!.point,
          points[i + 1]!.point,
          points[i]!.paint,
        );
      }
      // Jika titik selanjutnya null (angkat jari), jangan gambar garis
    }
  }

  @override
  bool shouldRepaint(covariant DrawingPainter oldDelegate) {
    return oldDelegate.points != points;
  }
}

// Widget helper sederhana untuk color picker (tanpa library eksternal)
class ColorPickerWidget extends StatefulWidget {
  final Color pickedColor;
  final ValueChanged<Color> onColorChanged;
  const ColorPickerWidget({super.key, required this.pickedColor, required this.onColorChanged});

  @override
  State<ColorPickerWidget> createState() => _ColorPickerWidgetState();
}

class _ColorPickerWidgetState extends State<ColorPickerWidget> {
  late Color currentColor;

  @override
  void initState() {
    super.initState();
    currentColor = widget.pickedColor;
  }

  @override
  Widget build(BuildContext context) {
    // Hanya menampilkan grid warna standar material
    List<Color> materialColors = [
      Colors.red, Colors.pink, Colors.purple, Colors.deepPurple,
      Colors.indigo, Colors.blue, Colors.lightBlue, Colors.cyan,
      Colors.teal, Colors.green, Colors.lightGreen, Colors.lime,
      Colors.yellow, Colors.amber, Colors.orange, Colors.deepOrange,
      Colors.brown, Colors.grey, Colors.blueGrey, Colors.black, Colors.white
    ];

    return Wrap(
      spacing: 8,
      runSpacing: 8,
      children: materialColors.map((color) {
        return GestureDetector(
          onTap: () => widget.onColorChanged(color),
          child: Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              color: color,
              shape: BoxShape.circle,
              border: Border.all(
                color: currentColor == color ? Colors.white : Colors.transparent,
                width: 2,
              ),
            ),
          ),
        );
      }).toList(),
    );
  }
}