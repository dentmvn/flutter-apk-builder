import 'package:flutter/material.dart';

class CalculatorPage extends StatefulWidget {
  const CalculatorPage({super.key});
  @override
  State<CalculatorPage> createState() => _CalculatorPageState();
}

class _CalculatorPageState extends State<CalculatorPage> {
  String display = '0';
  double? first;
  String op = '';
  bool reset = false;

  void press(String value) {
    setState(() {
      if (value == 'C') {
        display = '0'; first = null; op = ''; reset = false; return;
      }
      if ('0123456789.'.contains(value)) {
        if (reset || display == '0') display = value == '.' ? '0.' : value;
        else if (value != '.' || !display.contains('.')) display += value;
        reset = false;
        return;
      }
      if (value == '=') {
        if (first == null || op.isEmpty) return;
        final b = double.tryParse(display) ?? 0;
        final result = _calculate(first!, b, op);
        display = _fmt(result);
        first = null; op = ''; reset = true;
        return;
      }
      first = double.tryParse(display) ?? 0;
      op = value;
      reset = true;
    });
  }

  double _calculate(double a, double b, String o) {
    switch (o) {
      case '+': return a + b;
      case '-': return a - b;
      case '×': return a * b;
      case '÷': return b == 0 ? 0 : a / b;
      default: return b;
    }
  }

  String _fmt(double v) => v == v.roundToDouble() ? v.toInt().toString() : v.toStringAsFixed(6).replaceFirst(RegExp(r'0+$'), '').replaceFirst(RegExp(r'\.$'), '');

  @override
  Widget build(BuildContext context) {
    const ink = Color(0xFF202124), yellow = Color(0xFFFFC52E), blue = Color(0xFF1698E5), bg = Color(0xFFF7F8FC);
    const keys = ['C','÷','×','-','7','8','9','+','4','5','6','=','1','2','3','0','.'];
    return Scaffold(
      backgroundColor: bg,
      appBar: AppBar(
        backgroundColor: bg, foregroundColor: ink, elevation: 0,
        title: const Text('PPL KALKULATOR', style: TextStyle(fontFamily: 'Orbitron', fontWeight: FontWeight.bold)),
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(children: [
          Container(
            width: double.infinity, padding: const EdgeInsets.all(22),
            alignment: Alignment.centerRight,
            decoration: BoxDecoration(color: Colors.white, border: Border.all(color: ink, width: 2.5), borderRadius: BorderRadius.circular(18), boxShadow: const [BoxShadow(color: ink, offset: Offset(0,4))]),
            child: Text(display, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontFamily: 'Orbitron', fontSize: 32, fontWeight: FontWeight.bold)),
          ),
          const SizedBox(height: 20),
          Expanded(child: GridView.count(
            crossAxisCount: 4, crossAxisSpacing: 10, mainAxisSpacing: 10,
            children: keys.map((k) {
              final isOp = ['÷','×','-','+','='].contains(k);
              return ElevatedButton(
                onPressed: () => press(k),
                style: ElevatedButton.styleFrom(
                  backgroundColor: k == '=' ? blue : (isOp || k == 'C' ? yellow : Colors.white),
                  foregroundColor: ink,
                  side: const BorderSide(color: ink, width: 2),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                  elevation: 3,
                ),
                child: Text(k, style: const TextStyle(fontFamily: 'ShareTechMono', fontSize: 20, fontWeight: FontWeight.bold)),
              );
            }).toList(),
          )),
        ]),
      ),
    );
  }
}
