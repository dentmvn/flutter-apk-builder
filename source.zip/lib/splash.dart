// SPLASH.DART

import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'dart:ui';

// Import DashboardPage
import 'dashboard_page.dart';

// ─── TEMA WARNA PUTIH X BIRU NEW ─────────────────────────────────────────────────────────────
class _C {
  static const blue = Color(0xFF1A73E8);
  static const blueMid = Color(0xFF4285F4);
  static const blueLight = Color(0xFF8AB4F8);
  static const green = Color(0xFF34A853);
  static const red = Color(0xFFEA4335);
  static const amber = Color(0xFFFBBC04);
  static const text = Color(0xFF202124);
  static const textSub = Color(0xFF5F6368);
  static const textDim = Color(0xFF9AA0A6);
  static const border = Color(0xFFD4DCE4);
  static const surface = Color(0xFFFFFFFF);
  static const bg = Color(0xFFE8EDF2);
}

class SplashScreen extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listDoos;
  final List<dynamic> news;

  const SplashScreen({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.sessionKey,
    required this.listBug,
    required this.listDoos,
    required this.news,
  });

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> with TickerProviderStateMixin {
  // ─── ANIMATIONS ──────────────────────────────────────────────────────────
  late AnimationController _fadeController;
  late AnimationController _glowController;
  late AnimationController _pulseController;
  late AnimationController _rotateController;
  late AnimationController _slideController;
  late AnimationController _scanController;
  late Animation<double> _fadeAnimation;
  late Animation<double> _glowAnimation;
  late Animation<double> _pulseAnimation;
  late Animation<double> _rotateAnimation;
  late Animation<Offset> _slideAnimation;
  late Animation<double> _scanAnimation;

  // ─── SOFT THEME (Gak Sakit Mata) ─────────────────────────────────────────
  final Color _bgColor       = const Color(0xFFE8EDF2);
  final Color _bgSoft        = const Color(0xFFF0F4F8);
  final Color _cardColor     = const Color(0xFFFFFFFF);
  final Color _glowColor1    = const Color(0xFF1A73E8);
  final Color _glowColor2    = const Color(0xFF4285F4);
  final Color _glowColor3    = const Color(0xFF8AB4F8);
  final Color _successColor  = const Color(0xFF34A853);
  final Color _textColor     = const Color(0xFF202124);
  final Color _textSubColor  = const Color(0xFF5F6368);

  @override
  void initState() {
    super.initState();
    _initializeAnimations();
    _autoNavigate();
  }

  void _initializeAnimations() {
    _fadeController = AnimationController(
      duration: const Duration(milliseconds: 1400),
      vsync: this,
    );
    _glowController = AnimationController(
      duration: const Duration(milliseconds: 2500),
      vsync: this,
    )..repeat(reverse: true);

    _pulseController = AnimationController(
      duration: const Duration(milliseconds: 1800),
      vsync: this,
    )..repeat(reverse: true);

    _rotateController = AnimationController(
      duration: const Duration(seconds: 15),
      vsync: this,
    )..repeat();

    _slideController = AnimationController(
      duration: const Duration(milliseconds: 900),
      vsync: this,
    );

    _scanController = AnimationController(
      duration: const Duration(milliseconds: 2200),
      vsync: this,
    )..repeat();

    _fadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _fadeController, curve: Curves.easeOutCubic),
    );
    _glowAnimation = Tween<double>(begin: 0.2, end: 1.0).animate(
      CurvedAnimation(parent: _glowController, curve: Curves.easeInOutSine),
    );
    _pulseAnimation = Tween<double>(begin: 0.93, end: 1.07).animate(
      CurvedAnimation(parent: _pulseController, curve: Curves.easeInOutSine),
    );
    _rotateAnimation = Tween<double>(begin: 0, end: 1).animate(
      CurvedAnimation(parent: _rotateController, curve: Curves.linear),
    );
    _slideAnimation = Tween<Offset>(
      begin: const Offset(0, 0.25),
      end: Offset.zero,
    ).animate(
      CurvedAnimation(parent: _slideController, curve: Curves.easeOutCubic),
    );
    _scanAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _scanController, curve: Curves.easeInOut),
    );

    _fadeController.forward();
    _slideController.forward();
  }

  void _autoNavigate() {
    Future.delayed(const Duration(seconds: 4), _navigateToDashboard);
  }

  void _navigateToDashboard() {
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    if (mounted) {
      Navigator.of(context).pushReplacement(
        PageRouteBuilder(
          pageBuilder: (_, __, ___) => DashboardPage(
            username: widget.username,
            password: widget.password,
            role: widget.role,
            expiredDate: widget.expiredDate,
            sessionKey: widget.sessionKey,
            listBug: widget.listBug,
            listDoos: widget.listDoos,
            news: widget.news,
          ),
          transitionDuration: const Duration(milliseconds: 600),
          transitionsBuilder: (_, anim, __, child) => FadeTransition(
            opacity: CurvedAnimation(parent: anim, curve: Curves.easeOut),
            child: child,
          ),
        ),
      );
    }
  }

  @override
  void dispose() {
    _fadeController.dispose();
    _glowController.dispose();
    _pulseController.dispose();
    _rotateController.dispose();
    _slideController.dispose();
    _scanController.dispose();
    super.dispose();
  }

  // ─── ROTATING RING + ORBS ─────────────────────────────────────────────────
  Widget _buildDecorLayer(Size size) {
    return AnimatedBuilder(
      animation: _rotateAnimation,
      builder: (context, _) {
        return Stack(
          children: [
            // Large rotating ring
            Positioned(
              bottom: -size.height * 0.18,
              right: -size.width * 0.22,
              child: Transform.rotate(
                angle: _rotateAnimation.value * pi * 2,
                child: Container(
                  width: size.width * 0.72,
                  height: size.width * 0.72,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    border: Border.all(
                      color: _glowColor1.withOpacity(0.06),
                      width: 1.5,
                    ),
                  ),
                ),
              ),
            ),
            // Medium ring
            Positioned(
              top: -size.height * 0.08,
              left: -size.width * 0.18,
              child: Transform.rotate(
                angle: -_rotateAnimation.value * pi,
                child: Container(
                  width: size.width * 0.55,
                  height: size.width * 0.55,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    border: Border.all(
                      color: _glowColor2.withOpacity(0.07),
                      width: 1,
                    ),
                  ),
                ),
              ),
            ),
            // Glow orb top-left
            Positioned(
              top: -60,
              left: -40,
              child: Container(
                width: 200,
                height: 200,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: RadialGradient(
                    colors: [_glowColor1.withOpacity(0.06), Colors.transparent],
                  ),
                ),
              ),
            ),
            // Glow orb bottom-right
            Positioned(
              bottom: -50,
              right: -50,
              child: Container(
                width: 180,
                height: 180,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: RadialGradient(
                    colors: [_glowColor2.withOpacity(0.06), Colors.transparent],
                  ),
                ),
              ),
            ),
          ],
        );
      },
    );
  }

  // ─── SCAN LINE ────────────────────────────────────────────────────────────
  Widget _buildScanLine(Size size) {
    return AnimatedBuilder(
      animation: _scanAnimation,
      builder: (context, _) {
        final top = _scanAnimation.value * size.height;
        return Positioned(
          top: top,
          left: 0,
          right: 0,
          child: Container(
            height: 1.5,
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  Colors.transparent,
                  _glowColor1.withOpacity(0.1),
                  _glowColor1.withOpacity(0.2),
                  _glowColor1.withOpacity(0.1),
                  Colors.transparent,
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  // ─── SOFT VIGNETTE ──────────────────────────────────────────────────────
  Widget _buildVignette() {
    return Container(
      decoration: BoxDecoration(
        gradient: RadialGradient(
          center: Alignment.center,
          radius: 1.0,
          colors: [
            Colors.transparent,
            _bgSoft.withOpacity(0.3),
          ],
        ),
      ),
    );
  }

  // ─── TOP LEFT CORNER TAG ──────────────────────────────────────────────────
  Widget _buildCornerTag() {
    return Positioned(
      top: 52,
      left: 22,
      child: FadeTransition(
        opacity: _fadeAnimation,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(children: [
              Container(
                width: 4, height: 18,
                decoration: BoxDecoration(
                  gradient: LinearGradient(colors: [_glowColor1, _glowColor2]),
                  borderRadius: BorderRadius.circular(2),
                  boxShadow: [BoxShadow(color: _glowColor1.withOpacity(0.4), blurRadius: 6)],
                ),
              ),
              const SizedBox(width: 10),
              Text("NEKOPOI8CORE",
                style: TextStyle(
                  color: _glowColor1.withOpacity(0.7),
                  fontSize: 10,
                  letterSpacing: 4,
                  fontWeight: FontWeight.w800,
                ),
              ),
            ]),
            const SizedBox(height: 6),
            Text("SYSTEM BOOT v1.0",
              style: TextStyle(
                color: _glowColor1.withOpacity(0.25),
                fontSize: 8,
                letterSpacing: 2.5,
                fontWeight: FontWeight.w500,
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ─── SKIP BUTTON ──────────────────────────────────────────────────────────
  Widget _buildSkipButton() {
    return Positioned(
      top: 52,
      right: 20,
      child: FadeTransition(
        opacity: _fadeAnimation,
        child: GestureDetector(
          onTap: _navigateToDashboard,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 9),
            decoration: BoxDecoration(
              color: _cardColor,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: _glowColor1.withOpacity(0.15), width: 1),
              boxShadow: [
                BoxShadow(
                  color: _glowColor1.withOpacity(0.06),
                  blurRadius: 10,
                  offset: const Offset(0, 4),
                ),
                BoxShadow(
                  color: Colors.white.withOpacity(0.6),
                  blurRadius: 6,
                  offset: const Offset(-1, -1),
                ),
              ],
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text("SKIP",
                  style: TextStyle(
                    color: _glowColor1.withOpacity(0.6),
                    fontWeight: FontWeight.w800,
                    fontSize: 10,
                    letterSpacing: 3,
                  ),
                ),
                const SizedBox(width: 6),
                Icon(Icons.arrow_forward_ios_rounded, color: _glowColor1.withOpacity(0.4), size: 10),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // ─── MINECRAFT-STYLE 3D TEXT ──────────────────────────────────────────────
  Widget _build3DText(String text, {double size = 56, Color color = _C.blue}) {
    return Stack(
      children: [
        Text(
          text,
          style: TextStyle(
            fontSize: size,
            fontWeight: FontWeight.w900,
            color: Colors.black.withOpacity(0.15),
            letterSpacing: 2,
          ),
        ),
        Transform.translate(
          offset: const Offset(-2, -2),
          child: Text(
            text,
            style: TextStyle(
              fontSize: size,
              fontWeight: FontWeight.w900,
              color: Colors.white.withOpacity(0.3),
              letterSpacing: 2,
            ),
          ),
        ),
        Transform.translate(
          offset: const Offset(-4, -4),
          child: Text(
            text,
            style: TextStyle(
              fontSize: size,
              fontWeight: FontWeight.w900,
              color: color,
              letterSpacing: 2,
              shadows: [
                Shadow(
                  color: color.withOpacity(0.4),
                  blurRadius: 20,
                  offset: const Offset(0, 4),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  // ─── MAIN LOGO BLOCK ──────────────────────────────────────────────────────
  Widget _buildLogoBlock() {
    return AnimatedBuilder(
      animation: Listenable.merge([_pulseAnimation, _glowAnimation]),
      builder: (context, _) {
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Logo + title
            Row(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                // Logo square with 3D effect
                Container(
                  width: 80,
                  height: 80,
                  decoration: BoxDecoration(
                    color: _cardColor,
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(
                      color: _glowColor1.withOpacity(0.4),
                      width: 2,
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: _glowColor1.withOpacity(0.2 * _glowAnimation.value),
                        blurRadius: 25,
                        spreadRadius: 2,
                        offset: const Offset(0, 6),
                      ),
                      BoxShadow(
                        color: Colors.white.withOpacity(0.6),
                        blurRadius: 10,
                        offset: const Offset(-3, -3),
                      ),
                    ],
                  ),
                  child: Center(
                    child: ShaderMask(
                      shaderCallback: (bounds) => LinearGradient(
                        colors: [_glowColor1, _glowColor2],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ).createShader(bounds),
                      child: Text("A",
                        style: TextStyle(
                          fontSize: 32,
                          fontWeight: FontWeight.w900,
                          color: Colors.white,
                          shadows: [
                            Shadow(color: _glowColor1.withOpacity(0.4 * _glowAnimation.value), blurRadius: 14),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 20),
                // Title stacked - 3D MINECRAFT STYLE
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _build3DText("NEKOPOI8CORE", size: 48, color: _glowColor1),
                    _build3DText("TEAM", size: 32, color: _glowColor2),
                    Row(children: [
                      Container(
                        width: 28, height: 2,
                        decoration: BoxDecoration(
                          gradient: LinearGradient(colors: [_glowColor1, _glowColor2]),
                        ),
                      ),
                      const SizedBox(width: 8),
                      Text("SECURITY PLATFORM",
                        style: TextStyle(
                          color: _glowColor2.withOpacity(0.5),
                          fontSize: 8,
                          letterSpacing: 3.5,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                    ]),
                  ],
                ),
              ],
            ),

            const SizedBox(height: 28),

            // Glow progress bar with 3D effect
            _buildGlowBar(),
          ],
        );
      },
    );
  }

  Widget _buildGlowBar() {
    return AnimatedBuilder(
      animation: _glowAnimation,
      builder: (context, _) {
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Bar track with 3D effect
            Stack(children: [
              Container(
                height: 3,
                decoration: BoxDecoration(
                  color: _glowColor1.withOpacity(0.05),
                  borderRadius: BorderRadius.circular(3),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.white.withOpacity(0.4),
                      blurRadius: 4,
                      offset: const Offset(0, 1),
                    ),
                  ],
                ),
              ),
              FractionallySizedBox(
                widthFactor: _glowAnimation.value,
                child: Container(
                  height: 3,
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [_glowColor1, _glowColor2],
                    ),
                    borderRadius: BorderRadius.circular(3),
                    boxShadow: [
                      BoxShadow(color: _glowColor1.withOpacity(0.3), blurRadius: 8),
                    ],
                  ),
                ),
              ),
            ]),
            const SizedBox(height: 10),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text("INITIALIZING SYSTEM",
                  style: TextStyle(
                    color: _glowColor2.withOpacity(0.5),
                    fontSize: 8,
                    letterSpacing: 3.5,
                    fontWeight: FontWeight.w800,
                  ),
                ),
                Text("${(_glowAnimation.value * 100).toInt()}%",
                  style: TextStyle(
                    color: _glowColor1.withOpacity(0.5),
                    fontSize: 10,
                    fontWeight: FontWeight.w800,
                    letterSpacing: 1,
                  ),
                ),
              ],
            ),
          ],
        );
      },
    );
  }

  // ─── VERTICAL STATUS TAGS ─────────────────────────────────────────────────
  Widget _buildVerticalTags() {
    final tags = ["ACTIVE", "SECURE", "ENCRYPTED", "AUDITED"];
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: tags.asMap().entries.map((e) {
        return TweenAnimationBuilder<double>(
          tween: Tween(begin: 0, end: 1),
          duration: Duration(milliseconds: 600 + e.key * 120),
          curve: Curves.easeOutCubic,
          builder: (context, v, child) {
            return Opacity(
              opacity: v,
              child: Transform.translate(offset: Offset(20 * (1 - v), 0), child: child),
            );
          },
          child: Container(
            margin: const EdgeInsets.only(bottom: 10),
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
            decoration: BoxDecoration(
              color: _cardColor,
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: _glowColor1.withOpacity(0.12), width: 1),
              boxShadow: [
                BoxShadow(
                  color: Colors.white.withOpacity(0.4),
                  blurRadius: 4,
                  offset: const Offset(-1, -1),
                ),
              ],
            ),
            child: Row(mainAxisSize: MainAxisSize.min, children: [
              Container(
                width: 5, height: 5,
                decoration: BoxDecoration(
                  color: _glowColor1,
                  shape: BoxShape.circle,
                  boxShadow: [BoxShadow(color: _glowColor1.withOpacity(0.4), blurRadius: 4)],
                ),
              ),
              const SizedBox(width: 6),
              Text(e.value,
                style: TextStyle(
                  color: _glowColor1.withOpacity(0.6),
                  fontSize: 8,
                  letterSpacing: 2.5,
                  fontWeight: FontWeight.w800,
                ),
              ),
            ]),
          ),
        );
      }).toList(),
    );
  }

  // ─── STATUS CHIP ─────────────────────────────────────────────────────────
  Widget _buildStatusChip() {
    return AnimatedBuilder(
      animation: _glowAnimation,
      builder: (context, _) {
        return Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
          decoration: BoxDecoration(
            color: _cardColor,
            borderRadius: BorderRadius.circular(30),
            border: Border.all(color: _successColor.withOpacity(0.25), width: 1),
            boxShadow: [
              BoxShadow(
                color: _successColor.withOpacity(0.06),
                blurRadius: 10,
                offset: const Offset(0, 4),
              ),
              BoxShadow(
                color: Colors.white.withOpacity(0.6),
                blurRadius: 6,
                offset: const Offset(-1, -1),
              ),
            ],
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 7, height: 7,
                decoration: BoxDecoration(
                  color: _successColor,
                  shape: BoxShape.circle,
                  boxShadow: [
                    BoxShadow(
                      color: _successColor.withOpacity(0.5 * _glowAnimation.value),
                      blurRadius: 8,
                      spreadRadius: 2,
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 10),
              Text("SECURE BOOT  •  ONLINE",
                style: TextStyle(
                  color: _successColor.withOpacity(0.8),
                  fontSize: 9,
                  fontWeight: FontWeight.w800,
                  letterSpacing: 3,
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  // ─── FOOTER ───────────────────────────────────────────────────────────────
  Widget _buildFooter() {
    return Column(
      children: [
        Container(
          height: 1,
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [Colors.transparent, _glowColor1.withOpacity(0.12), Colors.transparent],
            ),
          ),
        ),
        const SizedBox(height: 14),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            _dot(_glowColor3),
            const SizedBox(width: 6),
            _footerLabel("SECURE"),
            const SizedBox(width: 16),
            Container(width: 1, height: 10, color: Colors.black.withOpacity(0.06)),
            const SizedBox(width: 16),
            _dot(_glowColor2),
            const SizedBox(width: 6),
            _footerLabel("ENCRYPTED"),
            const SizedBox(width: 16),
            Container(width: 1, height: 10, color: Colors.black.withOpacity(0.06)),
            const SizedBox(width: 16),
            Icon(Icons.fingerprint, color: _glowColor1.withOpacity(0.15), size: 12),
          ],
        ),
        const SizedBox(height: 10),
        Text("NEKOPOI8 TEAM v1.0  •  NEXT GEN SECURITY",
          style: TextStyle(
            fontSize: 7,
            color: Colors.black.withOpacity(0.1),
            letterSpacing: 3,
            fontWeight: FontWeight.w600,
          ),
        ),
      ],
    );
  }

  Widget _dot(Color c) => Container(
    width: 4, height: 4,
    decoration: BoxDecoration(
      color: c, shape: BoxShape.circle,
      boxShadow: [BoxShadow(color: c.withOpacity(0.3), blurRadius: 4)],
    ),
  );

  Widget _footerLabel(String t) => Text(t,
    style: TextStyle(
      color: Colors.black.withOpacity(0.2),
      fontSize: 7,
      fontWeight: FontWeight.w800,
      letterSpacing: 2,
    ),
  );

  // ─── INFO GRID ────────────────────────────────────────────────────────────
  Widget _buildInfoGrid() {
    final items = [
      {"label": "PROTOCOL", "value": "AES-256"},
      {"label": "STATUS", "value": "ONLINE"},
      {"label": "BUILD", "value": "V1.0"},
    ];
    return Row(
      children: items.asMap().entries.map((e) {
        return Expanded(
          child: Container(
            margin: EdgeInsets.only(right: e.key < 2 ? 10 : 0),
            padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 10),
            decoration: BoxDecoration(
              color: _cardColor,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: _glowColor1.withOpacity(0.1), width: 1),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.03),
                  blurRadius: 6,
                  offset: const Offset(0, 3),
                ),
                BoxShadow(
                  color: Colors.white.withOpacity(0.6),
                  blurRadius: 4,
                  offset: const Offset(-1, -1),
                ),
              ],
            ),
            child: Column(
              children: [
                Text(e.value["value"]!,
                  style: TextStyle(
                    color: _glowColor1.withOpacity(0.8),
                    fontSize: 13,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 1.5,
                    shadows: [Shadow(color: _glowColor1.withOpacity(0.2), blurRadius: 8)],
                  ),
                ),
                const SizedBox(height: 4),
                Text(e.value["label"]!,
                  style: TextStyle(
                    color: Colors.black.withOpacity(0.25),
                    fontSize: 7,
                    letterSpacing: 2,
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ],
            ),
          ),
        );
      }).toList(),
    );
  }

  // ─── BUILD ────────────────────────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;

    return Scaffold(
      backgroundColor: _bgColor,
      body: Stack(
        fit: StackFit.expand,
        children: [
          // Background gradien soft
          Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [
                  _bgSoft,
                  _bgColor,
                ],
              ),
            ),
          ),

          // 1. Decorative rings & orbs
          _buildDecorLayer(size),

          // 2. Vignette
          _buildVignette(),

          // 3. Scan line
          _buildScanLine(size),

          // 4. Top left corner tag
          _buildCornerTag(),

          // 5. Skip button
          _buildSkipButton(),

          // 6. Main content
          FadeTransition(
            opacity: _fadeAnimation,
            child: SlideTransition(
              position: _slideAnimation,
              child: Padding(
                padding: EdgeInsets.symmetric(
                  horizontal: 28,
                  vertical: size.height * 0.12,
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Expanded(child: _buildLogoBlock()),
                        const SizedBox(width: 16),
                        _buildVerticalTags(),
                      ],
                    ),

                    const SizedBox(height: 32),

                    // Status chip
                    _buildStatusChip(),

                    const SizedBox(height: 28),

                    // Info grid
                    _buildInfoGrid(),
                  ],
                ),
              ),
            ),
          ),

          // 7. Footer
          Positioned(
            bottom: 18,
            left: 0,
            right: 0,
            child: FadeTransition(
              opacity: _fadeAnimation,
              child: _buildFooter(),
            ),
          ),
        ],
      ),
    );
  }
}