import 'package:flutter/material.dart';
import 'chat_ai_page.dart';
import 'nik_check_page.dart';
import 'phone_lookup.dart';
import 'subdomain_finder_page.dart';
import 'anime.dart';
import 'iqc.dart';
import 'meme.dart';
import 'build_apk.dart';
import 'yts.dart';
import 'drawing_page.dart';
import 'fin_save_page.dart';
import 'calculator_page.dart';
import 'ppl_game_page.dart';
import 'alquran_page.dart';
import 'to_url_page.dart';

class ToolsPage extends StatelessWidget {
  final String sessionKey;
  final String userRole;

  const ToolsPage({super.key, required this.sessionKey, required this.userRole});

  static const bg = Color(0xFFF7F8FC);
  static const ink = Color(0xFF202124);
  static const yellow = Color(0xFFFFC52E);
  static const blue = Color(0xFF1698E5);

  @override
  Widget build(BuildContext context) {
    final sections = <String, List<_ToolItem>>{
      'PPL UTILITIES': [
        _ToolItem(Icons.smart_toy_outlined, 'Chat AI', 'Asisten AI', () => ChatAIPage(sessionKey: sessionKey)),
        _ToolItem(Icons.calculate, 'Kalkulator', 'Hitung cepat', () => const CalculatorPage()),
        _ToolItem(Icons.menu_book, 'Al-Quran', 'Baca surah & ayat', () => const AlQuranPage()),
        _ToolItem(Icons.upload_file, 'To URL', 'Upload file ke Catbox', () => const ToUrlPage()),
        _ToolItem(Icons.savings, 'PPL Nabung', 'Kelola tabungan', () => const FinSavePage()),
        _ToolItem(Icons.draw, 'Drawing', 'Canvas gambar', () => const DrawingPage()),
      ],
      'OSINT & LOOKUP': [
        _ToolItem(Icons.badge_outlined, 'NIK Check', 'Validasi NIK', () => NIKCheckPage(sessionKey: sessionKey)),
        _ToolItem(Icons.phone_android, 'Phone Lookup', 'Info nomor', () => PhoneLookupPage(sessionKey: sessionKey)),
        _ToolItem(Icons.dns_outlined, 'Subdomain', 'Pencarian subdomain', () => SubdomainFinderPage(sessionKey: sessionKey)),
      ],
      'MEDIA & MAKER': [
        _ToolItem(Icons.image_outlined, 'IQC', 'iPhone Quote Chat', () => const IqcPage()),
        _ToolItem(Icons.auto_awesome, 'Meme Generator', 'Meme random', () => const MemeGeneratorPage()),
        _ToolItem(Icons.music_note, 'YouTube Music', 'Cari & putar audio', () => const YouTubeS()),
        _ToolItem(Icons.sports_esports, 'PPL Game', 'Game ringan buat santai', () => const PplGamePage()),
        _ToolItem(Icons.movie_creation_outlined, 'Anime', 'Streaming anime', () => HomeAnimePage()),
        _ToolItem(Icons.build_circle_outlined, 'Build APK', 'Build project ZIP', () => BuildApkPage(sessionKey: sessionKey)),
      ],
    };

    return Scaffold(
      backgroundColor: bg,
      appBar: AppBar(
        backgroundColor: bg,
        foregroundColor: ink,
        elevation: 0,
        title: const Text('PPL TOOLS',
            style: TextStyle(fontFamily: 'Orbitron', fontWeight: FontWeight.bold, letterSpacing: 1.5)),
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(18, 6, 18, 110),
        children: [
          Container(
            height: 135,
            decoration: BoxDecoration(
              color: blue,
              border: Border.all(color: ink, width: 2.5),
              borderRadius: BorderRadius.circular(20),
              boxShadow: const [BoxShadow(color: ink, offset: Offset(0, 5))],
            ),
            clipBehavior: Clip.antiAlias,
            child: Stack(children: [
              Positioned.fill(child: Image.asset('assets/images/title.png', fit: BoxFit.cover, errorBuilder: (_, __, ___) => const SizedBox())),
              Positioned.fill(child: Container(color: blue.withOpacity(.55))),
              const Positioned(
                left: 20, top: 24,
                child: Text('PPL PROJECT', style: TextStyle(color: Colors.white, fontFamily: 'Orbitron', fontSize: 25, fontWeight: FontWeight.bold)),
              ),
              const Positioned(
                left: 20, bottom: 20,
                child: Text('TOOLS & UTILITIES', style: TextStyle(color: Colors.white, fontFamily: 'ShareTechMono', fontWeight: FontWeight.bold, letterSpacing: 2)),
              ),
            ]),
          ),
          const SizedBox(height: 20),
          ...sections.entries.expand((entry) => [
            _section(entry.key),
            const SizedBox(height: 12),
            GridView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: entry.value.length,
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                crossAxisSpacing: 12,
                mainAxisSpacing: 12,
                childAspectRatio: 1.18,
              ),
              itemBuilder: (_, i) => _card(context, entry.value[i]),
            ),
            const SizedBox(height: 22),
          ]),
        ],
      ),
    );
  }

  Widget _section(String text) => Align(
    alignment: Alignment.centerLeft,
    child: Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 9),
      decoration: BoxDecoration(
        color: yellow,
        border: Border.all(color: ink, width: 2.5),
        borderRadius: BorderRadius.circular(10),
        boxShadow: const [BoxShadow(color: ink, offset: Offset(0, 3))],
      ),
      child: Text(text, style: const TextStyle(fontFamily: 'ShareTechMono', fontWeight: FontWeight.bold, letterSpacing: 1.4)),
    ),
  );

  Widget _card(BuildContext context, _ToolItem item) => InkWell(
    borderRadius: BorderRadius.circular(16),
    onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => item.page())),
    child: Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        border: Border.all(color: ink, width: 2.5),
        borderRadius: BorderRadius.circular(16),
        boxShadow: const [BoxShadow(color: ink, offset: Offset(0, 4))],
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Container(
          width: 44, height: 44,
          decoration: BoxDecoration(color: blue.withOpacity(.16), border: Border.all(color: ink, width: 2), borderRadius: BorderRadius.circular(11)),
          child: Icon(item.icon, color: ink),
        ),
        const Spacer(),
        Text(item.title, maxLines: 1, overflow: TextOverflow.ellipsis,
            style: const TextStyle(fontFamily: 'ShareTechMono', fontWeight: FontWeight.bold, fontSize: 14)),
        const SizedBox(height: 4),
        Text(item.description, maxLines: 2, overflow: TextOverflow.ellipsis,
            style: const TextStyle(fontFamily: 'ShareTechMono', fontSize: 10)),
      ]),
    ),
  );
}

class _ToolItem {
  final IconData icon;
  final String title;
  final String description;
  final Widget Function() page;
  _ToolItem(this.icon, this.title, this.description, this.page);
}
