import 'package:flutter/material.dart';
import 'brand_guard.dart';

class BrandWatermarkLayer extends StatelessWidget {
  final Widget child;

  const BrandWatermarkLayer({super.key, required this.child});

  @override
  Widget build(BuildContext context) {
    BrandGuard.markWatermarkRendered();
    return Stack(
      fit: StackFit.expand,
      children: [
        child,
        IgnorePointer(
          child: SafeArea(
            child: Align(
              alignment: Alignment.bottomRight,
              child: Padding(
                padding: const EdgeInsets.only(right: 7, bottom: 4),
                child: DecoratedBox(
                  decoration: BoxDecoration(
                    color: Colors.black.withOpacity(.72),
                    borderRadius: BorderRadius.circular(7),
                    border: Border.all(color: const Color(0xFFFFC52E), width: 1),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 3),
                    child: Text(
                      'Pembuat: ${BrandGuard.creator}  •  Asisten: ${BrandGuard.assistant}',
                      style: const TextStyle(
                        color: Colors.white,
                        fontFamily: 'ShareTechMono',
                        fontSize: 8,
                        height: 1.0,
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }
}
