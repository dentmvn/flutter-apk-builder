// ignore_for_file: use_build_context_synchronously
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:video_player/video_player.dart';
import 'package:http/http.dart' as http;
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:web_socket_channel/status.dart' as status;

import 'api_config.dart';
import 'admin_page.dart';
import 'chat_page.dart';
import 'pplgram_page.dart';
import 'change_password_page.dart';
import 'chat_ai_page.dart';
import 'create_account_page.dart';
import 'ddos_page.dart';
import 'ddos_panel.dart';
import 'device_dashboard.dart';
import 'home_page.dart';
import 'login_page.dart';
import 'custom_bug.dart';
import 'bug_group.dart';
import 'sender_page.dart';
import 'spams_page.dart';
import 'telegram.dart';
import 'seller_page.dart';
import 'public_page.dart';
import 'fin_save_page.dart';
import 'calculator_page.dart';
import 'alquran_page.dart';

class DashboardPage extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listPayload;
  final List<Map<String, dynamic>> listDDoS;
  final List<dynamic> news;

  const DashboardPage({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.listBug,
    required this.listPayload,
    required this.listDDoS,
    required this.sessionKey,
    required this.news,
  });

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage> {
  static const bg = Color(0xFFF7F8FC);
  static const ink = Color(0xFF202124);
  static const yellow = Color(0xFFFFC52E);
  static const blue = Color(0xFF1698E5);
  static const pink = Color(0xFFFF96A6);
  static const green = Color(0xFF4BDB82);
  static const gray = Color(0xFFD1D2D5);

  int _selectedIndex = 0;
  late String username;
  late String role;
  late String expiredDate;
  late String sessionKey;
  late String password;
  late List<Map<String, dynamic>> listBug;
  late List<Map<String, dynamic>> listPayload;
  late List<Map<String, dynamic>> listDDoS;
  late List<dynamic> newsList;

  VideoPlayerController? _banner;
  VideoPlayerController? _profileBg;
  WebSocketChannel? _channel;
  String androidId = 'unknown';
  int onlineCount = 0;
  String latestChat = 'Belum ada pesan terbaru';

  @override
  void initState() {
    super.initState();
    username = widget.username;
    role = widget.role;
    expiredDate = widget.expiredDate;
    sessionKey = widget.sessionKey;
    password = widget.password;
    listBug = widget.listBug;
    listPayload = widget.listPayload;
    listDDoS = widget.listDDoS;
    newsList = widget.news;
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    _loadVideos();
    _connectSession();
  }

  Future<void> _loadVideos() async {
    _banner = VideoPlayerController.asset('assets/videos/ppl_banner.mp4');
    _profileBg = VideoPlayerController.asset('assets/videos/bg_profile.mp4');
    try {
      await Future.wait([_banner!.initialize(), _profileBg!.initialize()]);
      await _banner!.setLooping(true);
      await _profileBg!.setLooping(true);
      await _banner!.setVolume(0);
      await _profileBg!.setVolume(0);
      await _banner!.play();
      await _profileBg!.play();
      if (mounted) setState(() {});
    } catch (_) {
      if (mounted) setState(() {});
    }
  }

  Future<void> _connectSession() async {
    try {
      final info = await DeviceInfoPlugin().androidInfo;
      androidId = info.id;
      _channel = WebSocketChannel.connect(Uri.parse(ApiConfig.baseUrl.replaceFirst('http', 'ws')));
      _channel!.sink.add(jsonEncode({'type': 'validate', 'key': sessionKey, 'androidId': androidId}));
      _channel!.sink.add(jsonEncode({'type': 'stats'}));
      _channel!.stream.listen((event) {
        try {
          final data = jsonDecode(event);
          if (data['type'] == 'stats') {
            final value = data['online'] ?? data['onlineCount'] ?? data['usersOnline'];
            if (value is num && mounted) setState(() => onlineCount = value.toInt());
          }
          if (data['type'] == 'chat' && mounted) {
            final msg = data['message'];
            if (msg is Map && msg['message'] != null) setState(() => latestChat = msg['message'].toString());
          }
          if (data['type'] == 'myInfo' && data['valid'] == false) _handleInvalidSession('Session tidak valid. Silakan login lagi.');
        } catch (_) {}
      });
    } catch (_) {}
  }

  Future<void> _handleInvalidSession(String message) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.clear();
    if (!mounted) return;
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => AlertDialog(
        title: const Text('Session Expired'),
        content: Text(message),
        actions: [TextButton(onPressed: () => Navigator.of(context).pushAndRemoveUntil(MaterialPageRoute(builder: (_) => const LoginPage()), (_) => false), child: const Text('OK'))],
      ),
    );
  }

  void _open(Widget page) => setState(() => _selectedPage = page);
  late Widget _selectedPage;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (!(_selectedPageInitialized)) {
      _selectedPageInitialized = true;
      _selectedPage = _buildHome();
    }
  }

  bool _selectedPageInitialized = false;

  Widget _pageForIndex(int index) {
    switch (index) {
      case 1:
        return AttackPage(username: username, password: password, listBug: listBug, role: role, expiredDate: expiredDate, sessionKey: sessionKey);
      case 2:
        return DeviceDashboardPage(username: username);
      case 3:
        return AttackPanel(sessionKey: sessionKey, listDDoS: listDDoS);
      case 4:
        return ToolsPage(sessionKey: sessionKey, userRole: role);
      default:
        return _buildHome();
    }
  }

  void _selectTab(int index) {
    setState(() {
      _selectedIndex = index;
      _selectedPage = _pageForIndex(index);
    });
  }

  void _openChat() => _open(ChatPage(sessionKey: sessionKey));
  void _openPplgram() => _open(PplgramPage(sessionKey: sessionKey));
  void _openSender() => _open(SenderPage(sessionKey: sessionKey, userRole: role));
  void _openFinSave() => _open(const FinSavePage());
  void _openCalculator() => _open(const CalculatorPage());
  void _openQuran() => _open(const AlQuranPage());

  void _openCreateAccount() async {
    final created = await Navigator.push(context, MaterialPageRoute(builder: (_) => CreateAccountPage(sessionKey: sessionKey, creatorRole: role)));
    if (created == true && mounted) setState(() {});
  }

  Widget _header() {
    return Container(
      padding: EdgeInsets.fromLTRB(24, MediaQuery.of(context).padding.top + 10, 24, 12),
      decoration: const BoxDecoration(color: bg, border: Border(bottom: BorderSide(color: ink, width: 2))),
      child: Row(children: [
        _iconButton(Icons.menu, _showMenu, yellow),
        const SizedBox(width: 14),
        Expanded(child: ClipRRect(borderRadius: BorderRadius.circular(15), child: SizedBox(height: 54, child: _video(_banner, 'assets/images/logo.png')))),
        const SizedBox(width: 14),
        _iconButton(Icons.settings, _showAccount, yellow),
      ]),
    );
  }

  Widget _iconButton(IconData icon, VoidCallback tap, Color color) => GestureDetector(
    onTap: tap,
    child: Container(width: 50, height: 50, decoration: BoxDecoration(color: color, border: Border.all(color: ink, width: 2.5), borderRadius: BorderRadius.circular(16), boxShadow: const [BoxShadow(color: ink, offset: Offset(0, 4))]), child: Icon(icon, color: ink, size: 27)),
  );

  Widget _video(VideoPlayerController? controller, String fallback) {
    if (controller != null && controller.value.isInitialized) return FittedBox(fit: BoxFit.cover, child: SizedBox(width: controller.value.size.width, height: controller.value.size.height, child: VideoPlayer(controller)));
    return Image.asset(fallback, fit: BoxFit.cover, errorBuilder: (_, __, ___) => Container(color: gray));
  }

  Widget _buildHome() {
    return CustomScrollView(slivers: [
      SliverToBoxAdapter(child: _header()),
      SliverPadding(padding: const EdgeInsets.fromLTRB(28, 22, 28, 100), sliver: SliverList(delegate: SliverChildListDelegate([
        _profileCard(),
        const SizedBox(height: 20),
        _pplgramPreview(),
        const SizedBox(height: 20),
        _bannerCard(),
        const SizedBox(height: 22),
        _sectionTitle('QUICK ACTIONS'),
        const SizedBox(height: 12),
        SizedBox(
          height: 126,
          child: SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            physics: const BouncingScrollPhysics(),
            child: Row(children: [
              _quickCard(Icons.send, 'Sender', 'Private & Global', _openSender),
              const SizedBox(width: 12),
              _quickCard(Icons.calculate, 'Kalkulator', 'Hitung cepat', _openCalculator),
              const SizedBox(width: 12),
              _quickCard(Icons.menu_book, 'Al-Quran', 'Baca surah', _openQuran),
              const SizedBox(width: 12),
              _quickCard(Icons.bug_report, 'Bug WhatsApp', 'Halaman WhatsApp', () => _selectTab(1)),
              const SizedBox(width: 12),
              _quickCard(Icons.hub, 'DDoS', 'Panel server', () => _selectTab(3)),
              const SizedBox(width: 12),
              _quickCard(Icons.person_search, 'Other Tools', 'Utilities & OSINT', () => _selectTab(4)),
              const SizedBox(width: 12),
              _quickCard(Icons.phone_android, 'RAT', 'Perangkat', () => _selectTab(2)),
            ]),
          ),
        ),
        const SizedBox(height: 20),
        _chatPreview(),
        const SizedBox(height: 22),
        _sectionTitle('PPL NABUNG'),
        const SizedBox(height: 12),
        _largeButton(Icons.savings, 'BUKA PPL NABUNG', _openFinSave, yellow),
        if (_canCreateAccount) ...[
          const SizedBox(height: 22),
          _sectionTitle('ACCOUNT'),
          const SizedBox(height: 12),
          _largeButton(Icons.person_add_alt_1, 'CREATE ACCOUNT', _openCreateAccount, blue),
        ],
      ]))),
    ]);
  }

  bool get _canCreateAccount => role.toLowerCase() != 'member';

  Widget _profileCard() {
    return Container(height: 235, decoration: BoxDecoration(color: gray, border: Border.all(color: ink, width: 2.5), borderRadius: BorderRadius.circular(22), boxShadow: const [BoxShadow(color: ink, offset: Offset(0, 5))]), child: Stack(children: [
      ClipRRect(borderRadius: BorderRadius.circular(19), child: SizedBox.expand(child: _video(_profileBg, 'assets/images/user_card.jpg'))),
      Container(decoration: BoxDecoration(color: Colors.white.withOpacity(.65), borderRadius: BorderRadius.circular(19))),
      Padding(padding: const EdgeInsets.all(18), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [Container(width: 68, height: 68, decoration: BoxDecoration(shape: BoxShape.circle, color: const Color(0xFFBEEBF4), border: Border.all(color: ink, width: 2.5)), child: const Icon(Icons.person, size: 42, color: ink)), const SizedBox(width: 16), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(username, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 22, fontFamily: 'ShareTechMono', fontWeight: FontWeight.bold)), const SizedBox(height: 7), Row(children: [_badge(role.toUpperCase(), yellow), const SizedBox(width: 8), _badge(expiredDate.split(' ').first, pink)]),]))]),
        const Spacer(),
        Row(children: [Expanded(child: _stat('DEVICE', androidId)), const SizedBox(width: 8), Expanded(child: _stat('ONLINE', '$onlineCount')), const SizedBox(width: 8), Expanded(child: _stat('ROLE', role.toUpperCase()))]),
      ])),
    ]));
  }

  Widget _stat(String label, String value) => Container(padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 10), decoration: BoxDecoration(color: Colors.white, border: Border.all(color: ink, width: 2), borderRadius: BorderRadius.circular(13)), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(label, style: const TextStyle(fontSize: 9, fontFamily: 'ShareTechMono')), const SizedBox(height: 5), Text(value, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 11, fontFamily: 'ShareTechMono', fontWeight: FontWeight.bold))]));

  Widget _badge(String text, Color color) => Container(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7), decoration: BoxDecoration(color: color, border: Border.all(color: ink, width: 1.5), borderRadius: BorderRadius.circular(8)), child: Text(text, style: const TextStyle(fontSize: 10, fontFamily: 'ShareTechMono', fontWeight: FontWeight.bold)));

  Widget _pplgramPreview() => GestureDetector(onTap: _openPplgram, child: Container(padding: const EdgeInsets.all(16), decoration: BoxDecoration(color: yellow, border: Border.all(color: ink, width: 2.5), borderRadius: BorderRadius.circular(18), boxShadow: const [BoxShadow(color: ink, offset: Offset(0, 4))]), child: Row(children: [Container(width: 52, height: 52, decoration: BoxDecoration(color: Colors.white, shape: BoxShape.circle, border: Border.all(color: ink, width: 2)), child: const Icon(Icons.auto_stories_rounded, color: ink, size: 28)), const SizedBox(width: 14), const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('PPLGRAM', style: TextStyle(fontFamily: 'Orbitron', fontWeight: FontWeight.bold, letterSpacing: 1.5, fontSize: 17)), SizedBox(height: 5), Text('Story foto, video & teks dari semua user', maxLines: 2, overflow: TextOverflow.ellipsis, style: TextStyle(fontFamily: 'ShareTechMono', fontSize: 11))])), const Icon(Icons.arrow_forward, size: 30)])));

  Widget _chatPreview() => GestureDetector(onTap: _openChat, child: Container(padding: const EdgeInsets.all(16), decoration: BoxDecoration(color: const Color(0xFFB8E6EE), border: Border.all(color: ink, width: 2.5), borderRadius: BorderRadius.circular(18), boxShadow: const [BoxShadow(color: ink, offset: Offset(0, 4))]), child: Row(children: [Container(width: 50, height: 50, decoration: BoxDecoration(color: Colors.white, shape: BoxShape.circle, border: Border.all(color: ink, width: 2)), child: const Icon(Icons.group, color: ink)), const SizedBox(width: 14), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [const Text('GLOBAL CHAT', style: TextStyle(fontFamily: 'ShareTechMono', fontWeight: FontWeight.bold, letterSpacing: 2)), const SizedBox(height: 7), Text(latestChat, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontFamily: 'ShareTechMono'))])), const Icon(Icons.arrow_forward, size: 30)])));

  Widget _bannerCard() => Container(height: 170, decoration: BoxDecoration(borderRadius: BorderRadius.circular(20), border: Border.all(color: ink, width: 2.5), boxShadow: const [BoxShadow(color: ink, offset: Offset(0, 5))]), child: ClipRRect(borderRadius: BorderRadius.circular(17), child: Stack(children: [Positioned.fill(child: _video(_banner, 'assets/images/title.png')), Positioned.fill(child: Container(color: Colors.black.withOpacity(.18))), const Positioned(left: 22, top: 26, child: Text('PPL PROJECT', style: TextStyle(color: Colors.white, fontSize: 25, fontFamily: 'Orbitron', fontWeight: FontWeight.bold, shadows: [Shadow(color: Colors.black, blurRadius: 5)]))), Positioned(left: 22, bottom: 20, child: _smallButton('OPEN TOOLS', () => _selectTab(4)))])));

  Widget _sectionTitle(String text) => Container(padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 9), decoration: BoxDecoration(color: yellow, border: Border.all(color: ink, width: 2.5), borderRadius: BorderRadius.circular(10), boxShadow: const [BoxShadow(color: ink, offset: Offset(0, 3))]), child: Text(text, style: const TextStyle(fontFamily: 'ShareTechMono', fontWeight: FontWeight.bold, letterSpacing: 2)));

  Widget _quickCard(IconData icon, String title, String subtitle, VoidCallback tap) => GestureDetector(onTap: tap, child: Container(height: 120, padding: const EdgeInsets.all(14), decoration: BoxDecoration(color: Colors.white, border: Border.all(color: ink, width: 2.5), borderRadius: BorderRadius.circular(17), boxShadow: const [BoxShadow(color: ink, offset: Offset(0, 4))]), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Icon(icon, size: 28), const Spacer(), Text(title, style: const TextStyle(fontFamily: 'ShareTechMono', fontWeight: FontWeight.bold, fontSize: 14)), const SizedBox(height: 3), Text(subtitle, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontFamily: 'ShareTechMono', fontSize: 10))])));

  Widget _smallButton(String text, VoidCallback tap) => GestureDetector(onTap: tap, child: Container(padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10), decoration: BoxDecoration(color: yellow, border: Border.all(color: ink, width: 2), borderRadius: BorderRadius.circular(11)), child: Text(text, style: const TextStyle(fontFamily: 'ShareTechMono', fontWeight: FontWeight.bold))));

  Widget _largeButton(IconData icon, String text, VoidCallback tap, Color color) => SizedBox(height: 55, child: ElevatedButton.icon(onPressed: tap, icon: Icon(icon), label: Text(text), style: ElevatedButton.styleFrom(backgroundColor: color, foregroundColor: ink, side: const BorderSide(color: ink, width: 2.5), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)), elevation: 4, textStyle: const TextStyle(fontFamily: 'ShareTechMono', fontWeight: FontWeight.bold))));

  Widget _bottomNav() => Container(padding: const EdgeInsets.fromLTRB(10, 9, 10, 10), decoration: const BoxDecoration(color: Colors.white, border: Border(top: BorderSide(color: ink, width: 2.5))), child: Row(mainAxisAlignment: MainAxisAlignment.spaceAround, children: [
    _navItem(Icons.grid_view, 'Home', 0), _navItem(Icons.chat_bubble_outline, 'WhatsApp', 1), _navItem(Icons.phone_android, 'RAT', 2), _navItem(Icons.hub, 'DDoS', 3), _navItem(Icons.construction, 'Tools', 4),
  ]));

  Widget _navItem(IconData icon, String label, int index) { final active = _selectedIndex == index; return GestureDetector(onTap: () => _selectTab(index), child: AnimatedContainer(duration: const Duration(milliseconds: 160), width: 67, padding: const EdgeInsets.symmetric(vertical: 8), decoration: BoxDecoration(color: active ? yellow : Colors.transparent, border: active ? Border.all(color: ink, width: 2) : null, borderRadius: BorderRadius.circular(14), boxShadow: active ? const [BoxShadow(color: ink, offset: Offset(0, 3))] : null), child: Column(mainAxisSize: MainAxisSize.min, children: [Icon(icon, size: 22), const SizedBox(height: 4), Text(label, style: const TextStyle(fontSize: 10, fontFamily: 'ShareTechMono', fontWeight: FontWeight.bold))]))); }

  void _showMenu() {
    showModalBottomSheet(context: context, backgroundColor: bg, builder: (_) => SafeArea(child: ListView(shrinkWrap: true, padding: const EdgeInsets.all(18), children: [
      const Text('PPL MENU', style: TextStyle(fontSize: 20, fontFamily: 'Orbitron', fontWeight: FontWeight.bold)),
      const SizedBox(height: 12),
      _menuTile(Icons.chat, 'Global Chat', _openChat),
      _menuTile(Icons.send, 'Sender', _openSender),
      _menuTile(Icons.construction, 'Tools', () => _selectTab(4)),
      _menuTile(Icons.lock_reset, 'Change Password', () => _open(ChangePasswordPage(username: username, sessionKey: sessionKey))),
      if (_canCreateAccount) _menuTile(Icons.person_add, 'Create Account', _openCreateAccount),
      if (role.toLowerCase() == 'abud' || role.toLowerCase() == 'kingz' || role.toLowerCase() == 'high owner') _menuTile(Icons.admin_panel_settings, 'Admin', () => _open(AdminPage(sessionKey: sessionKey, creatorRole: role))),
    ])));
  }

  Widget _menuTile(IconData icon, String title, VoidCallback tap) => ListTile(leading: Container(padding: const EdgeInsets.all(8), decoration: BoxDecoration(color: yellow, border: Border.all(color: ink, width: 2), borderRadius: BorderRadius.circular(9)), child: Icon(icon)), title: Text(title, style: const TextStyle(fontFamily: 'ShareTechMono', fontWeight: FontWeight.bold)), onTap: () { Navigator.pop(context); tap(); });

  void _showAccount() => showModalBottomSheet(context: context, backgroundColor: bg, builder: (_) => SafeArea(child: Padding(padding: const EdgeInsets.all(22), child: Column(mainAxisSize: MainAxisSize.min, children: [const Text('ACCOUNT', style: TextStyle(fontFamily: 'Orbitron', fontSize: 20, fontWeight: FontWeight.bold)), const SizedBox(height: 16), _stat('USERNAME', username), const SizedBox(height: 8), _stat('ROLE', role.toUpperCase()), const SizedBox(height: 8), _stat('EXPIRED', expiredDate), const SizedBox(height: 14), _largeButton(Icons.lock_reset, 'CHANGE PASSWORD', () { Navigator.pop(context); _open(ChangePasswordPage(username: username, sessionKey: sessionKey)); }, yellow)]))));

  @override
  Widget build(BuildContext context) => Scaffold(backgroundColor: bg, body: SafeArea(top: false, child: _selectedPageInitialized ? _selectedPage : const SizedBox.shrink()), bottomNavigationBar: _bottomNav());

  @override
  void dispose() {
    _channel?.sink.close(status.goingAway);
    _banner?.dispose();
    _profileBg?.dispose();
    super.dispose();
  }
}
