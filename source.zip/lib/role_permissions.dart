class RolePermissions {
  static const List<String> roles = [
    'member',
    'reseller',
    'vip',
    'owner',
    'high owner',
    'pt',
    'tk',
    'kingz',
    'abud',
  ];

  static String normalize(String role) => role.trim().toLowerCase();

  static List<String> creatableRoles(String creatorRole) {
    switch (normalize(creatorRole)) {
      case 'abud':
        return [...roles]..remove('abud');
      case 'kingz':
        return const ['member', 'reseller', 'vip', 'owner'];
      case 'high owner':
        return roles.where((r) => const {'member', 'reseller', 'vip', 'owner', 'high owner', 'pt', 'tk'}.contains(r)).toList();
      case 'pt':
      case 'tk':
        return roles.where((r) => const {'member', 'reseller', 'vip', 'pt', 'tk'}.contains(r)).toList();
      case 'owner':
        return const ['member', 'reseller', 'vip'];
      case 'reseller':
      case 'vip':
        return const ['member'];
      default:
        return const [];
    }
  }

  static int maxDaysFor(String creatorRole, String targetRole) {
    final creator = normalize(creatorRole);
    final target = normalize(targetRole);
    if ((creator == 'reseller' || creator == 'vip') && target == 'member') return 30;
    return 36500;
  }

  static bool canCreate(String creatorRole, String targetRole, int days) {
    final target = normalize(targetRole);
    if (!creatableRoles(creatorRole).contains(target)) return false;
    return days > 0 && days <= maxDaysFor(creatorRole, target);
  }
}
