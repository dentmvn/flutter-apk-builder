// INSTAGRAM_STALK.DART

import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:flutter/services.dart';
import 'package:share_plus/share_plus.dart';
import 'package:path_provider/path_provider.dart';

// ─── TEMA WARNA PUTIH X BIRU NEW ─────────────────────────────────────────────────────────────
class _C {
  static const bg         = Color(0xFFE8EDF2);
  static const surface    = Color(0xFFFFFFFF);
  static const card       = Color(0xFFFFFFFF);
  static const border     = Color(0xFFD4DCE4);
  static const borderLit  = Color(0xFFCBD5E1);

  static const igPink     = Color(0xFFE1306C);
  static const igOrange   = Color(0xFFF77737);
  static const igPurple   = Color(0xFF833AB4);
  static const igBlue     = Color(0xFF405DE6);
  static const igYellow   = Color(0xFFFCAF45);

  static const blue       = Color(0xFF1A73E8);
  static const blueMid    = Color(0xFF4285F4);
  static const blueLight  = Color(0xFF8AB4F8);
  static const green      = Color(0xFF34A853);
  static const red        = Color(0xFFEA4335);
  static const amber      = Color(0xFFFBBC04);

  static const text       = Color(0xFF202124);
  static const textSub    = Color(0xFF5F6368);
  static const textDim    = Color(0xFF9AA0A6);
  static const white      = Color(0xFFFFFFFF);

  static const LinearGradient igGrad = LinearGradient(
    colors: [Color(0xFF833AB4), Color(0xFFE1306C), Color(0xFFF77737)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );
}

class InstagramStalkPage extends StatefulWidget {
  const InstagramStalkPage({super.key});

  @override
  State<InstagramStalkPage> createState() => _InstagramStalkPageState();
}

class _InstagramStalkPageState extends State<InstagramStalkPage>
    with SingleTickerProviderStateMixin {
  final TextEditingController _usernameController = TextEditingController();
  bool _isLoading = false;
  Map<String, dynamic>? _userData;
  String? _errorMessage;
  List<dynamic>? _mediaList;
  bool _isLoadingMedia = false;
  bool _isDownloading = false;

  late TabController _tabController;

  // ─── API ENDPOINTS ─────────────────────────────────────────────────────────
  static const String _apiStalk = 'https://api.siputzx.my.id/api/stalk/instagram';
  static const String _apiMedia = 'https://api.siputzx.my.id/api/instagram/media';
  static const String _apiBackup = 'https://api.dry.my.id/api/instagram/stalk';
  static const String _apiBackupMedia = 'https://api.dry.my.id/api/instagram/media';

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  // ─── 3D TEXT ──────────────────────────────────────────────────────────────
  Widget _build3DText(String text, {double size = 16, Color? color}) {
    final textColor = color ?? _C.igPink;
    return Stack(
      children: [
        Text(
          text,
          style: TextStyle(
            fontSize: size,
            fontWeight: FontWeight.w900,
            color: Colors.black.withOpacity(0.12),
            letterSpacing: 1,
          ),
        ),
        Transform.translate(
          offset: const Offset(-1.5, -1.5),
          child: Text(
            text,
            style: TextStyle(
              fontSize: size,
              fontWeight: FontWeight.w900,
              color: Colors.white.withOpacity(0.3),
              letterSpacing: 1,
            ),
          ),
        ),
        Transform.translate(
          offset: const Offset(-3, -3),
          child: Text(
            text,
            style: TextStyle(
              fontSize: size,
              fontWeight: FontWeight.w900,
              color: textColor,
              letterSpacing: 1,
              shadows: [
                Shadow(
                  color: textColor.withOpacity(0.3),
                  blurRadius: 12,
                  offset: const Offset(0, 3),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  // ─── STALK INSTAGRAM ───────────────────────────────────────────────────────
  Future<void> _stalkInstagram() async {
    final username = _usernameController.text.trim();
    if (username.isEmpty) {
      setState(() {
        _errorMessage = "Masukkan username Instagram!";
        _userData = null;
        _mediaList = null;
      });
      return;
    }

    final cleanUsername = username.replaceAll('@', '');

    setState(() {
      _isLoading = true;
      _errorMessage = null;
      _userData = null;
      _mediaList = null;
    });

    // Coba API Primary
    bool success = await _fetchFromPrimary(cleanUsername);
    
    // Jika gagal, coba backup
    if (!success) {
      success = await _fetchFromBackup(cleanUsername);
    }

    // Jika masih gagal
    if (!success && mounted) {
      setState(() {
        _errorMessage = "Gagal mendapatkan data. Coba lagi nanti.";
        _isLoading = false;
      });
    }
  }

  Future<bool> _fetchFromPrimary(String username) async {
    try {
      final response = await http.get(
        Uri.parse('$_apiStalk?username=$username'),
      ).timeout(const Duration(seconds: 15));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['status'] == true && data['data'] != null) {
          final userData = data['data'];
          
          // Parse dengan benar sesuai format API
          setState(() {
            _userData = {
              'username': userData['username'] ?? username,
              'full_name': userData['fullName'] ?? userData['full_name'] ?? userData['name'] ?? '',
              'profile_picture': userData['profilePic'] ?? userData['profile_picture'] ?? userData['avatar'] ?? '',
              'bio': userData['bio'] ?? userData['biography'] ?? '',
              'follower_count': userData['followerCount'] ?? userData['follower_count'] ?? 0,
              'following_count': userData['followingCount'] ?? userData['following_count'] ?? 0,
              'media_count': userData['mediaCount'] ?? userData['media_count'] ?? 0,
              'is_verified': userData['isVerified'] ?? userData['is_verified'] ?? false,
              'is_private': userData['isPrivate'] ?? userData['is_private'] ?? false,
              'business_category_name': userData['businessCategory'] ?? userData['business_category_name'] ?? '',
              'external_url': userData['externalUrl'] ?? userData['external_url'] ?? '',
              'pk': userData['pk'] ?? '',
            };
            _errorMessage = null;
          });

          // Ambil media
          await _fetchMedia(username);
          setState(() => _isLoading = false);
          return true;
        }
      }
    } catch (e) {
      print('Primary API error: $e');
    }
    return false;
  }

  Future<bool> _fetchFromBackup(String username) async {
    try {
      final response = await http.get(
        Uri.parse('$_apiBackup?username=$username'),
      ).timeout(const Duration(seconds: 15));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['status'] == true && data['result'] != null) {
          final userData = data['result'];
          
          setState(() {
            _userData = {
              'username': userData['username'] ?? username,
              'full_name': userData['fullname'] ?? userData['full_name'] ?? '',
              'profile_picture': userData['profile_picture'] ?? userData['avatar'] ?? '',
              'bio': userData['bio'] ?? userData['biography'] ?? '',
              'follower_count': userData['follower'] ?? userData['follower_count'] ?? 0,
              'following_count': userData['following'] ?? userData['following_count'] ?? 0,
              'media_count': userData['media'] ?? userData['media_count'] ?? 0,
              'is_verified': userData['verified'] ?? userData['is_verified'] ?? false,
              'is_private': userData['private'] ?? userData['is_private'] ?? false,
              'business_category_name': userData['category'] ?? '',
              'external_url': userData['external_url'] ?? '',
              'pk': userData['pk'] ?? '',
            };
            _errorMessage = null;
          });

          await _fetchMedia(username);
          setState(() => _isLoading = false);
          return true;
        }
      }
    } catch (e) {
      print('Backup API error: $e');
    }
    return false;
  }

  Future<void> _fetchMedia(String username) async {
    setState(() => _isLoadingMedia = true);
    
    try {
      // Coba primary
      var response = await http.get(
        Uri.parse('$_apiMedia?username=$username&limit=20'),
      ).timeout(const Duration(seconds: 15));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['status'] == true && data['data'] != null) {
          setState(() => _mediaList = data['data']);
          setState(() => _isLoadingMedia = false);
          return;
        }
      }
    } catch (e) {
      print('Primary media error: $e');
    }

    // Coba backup media
    try {
      final response = await http.get(
        Uri.parse('$_apiBackupMedia?username=$username&limit=20'),
      ).timeout(const Duration(seconds: 15));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['status'] == true && data['data'] != null) {
          setState(() => _mediaList = data['data']);
          setState(() => _isLoadingMedia = false);
          return;
        }
      }
    } catch (e) {
      print('Backup media error: $e');
    }

    setState(() => _isLoadingMedia = false);
  }

  Future<void> _downloadMedia(String url, String type) async {
    setState(() => _isDownloading = true);
    try {
      final response = await http.get(Uri.parse(url));
      if (response.statusCode == 200) {
        final dir = await getTemporaryDirectory();
        final ext = type == 'video' ? 'mp4' : 'jpg';
        final file = File(
          '${dir.path}/instagram_${DateTime.now().millisecondsSinceEpoch}.$ext',
        );
        await file.writeAsBytes(response.bodyBytes);

        await Share.shareXFiles(
          [XFile(file.path)],
          text: '📸 Instagram media',
        );

        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: const Row(children: [
              Icon(Icons.check_circle, color: Colors.white, size: 18),
              SizedBox(width: 8),
              Text('Media siap dibagikan!'),
            ]),
            backgroundColor: _C.green,
            behavior: SnackBarBehavior.floating,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
            duration: const Duration(seconds: 2),
          ),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Gagal download: $e'),
          backgroundColor: _C.red,
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        ),
      );
    } finally {
      setState(() => _isDownloading = false);
    }
  }

  void _copyToClipboard(String text, String label) {
    Clipboard.setData(ClipboardData(text: text));
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(children: [
          const Icon(Icons.check_circle, color: Colors.white, size: 16),
          const SizedBox(width: 8),
          Text('$label disalin!', style: const TextStyle(color: Colors.white)),
        ]),
        backgroundColor: _C.green,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        duration: const Duration(seconds: 2),
      ),
    );
  }

  String _formatNumber(dynamic num) {
    if (num == null) return '0';
    final n = num is int ? num : int.tryParse(num.toString()) ?? 0;
    if (n >= 1000000) {
      return '${(n / 1000000).toStringAsFixed(1)}M';
    } else if (n >= 1000) {
      return '${(n / 1000).toStringAsFixed(1)}K';
    }
    return n.toString();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _C.bg,
      appBar: _buildAppBar(),
      body: SingleChildScrollView(
        physics: const BouncingScrollPhysics(),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            children: [
              _buildSearchCard(),
              const SizedBox(height: 16),
              if (_errorMessage != null) _buildErrorBanner(),
              if (_isLoading) _buildLoadingState(),
              if (_userData != null && !_isLoading) _buildResultCard(),
            ],
          ),
        ),
      ),
    );
  }

  PreferredSizeWidget _buildAppBar() {
    return AppBar(
      title: _build3DText('Instagram Stalk', size: 18, color: _C.igPink),
      backgroundColor: _C.surface,
      elevation: 0,
      centerTitle: true,
      bottom: PreferredSize(
        preferredSize: const Size.fromHeight(1),
        child: Container(height: 1, color: _C.border),
      ),
      leading: IconButton(
        icon: const Icon(Icons.arrow_back_ios_new_rounded, color: _C.textSub),
        onPressed: () => Navigator.pop(context),
      ),
      actions: [
        IconButton(
          icon: const Icon(Icons.info_outline_rounded, color: _C.textSub),
          onPressed: () => _showInfoDialog(),
        ),
        const SizedBox(width: 4),
      ],
    );
  }

  Widget _buildSearchCard() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: _C.surface,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: _C.border),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.04),
            blurRadius: 12,
            offset: const Offset(0, 6),
          ),
          BoxShadow(
            color: Colors.white.withOpacity(0.6),
            blurRadius: 8,
            offset: const Offset(-2, -2),
          ),
        ],
      ),
      child: Column(
        children: [
          Row(
            children: [
              Container(
                width: 40,
                height: 40,
                decoration: BoxDecoration(
                  gradient: _C.igGrad,
                  borderRadius: BorderRadius.circular(12),
                  boxShadow: [
                    BoxShadow(
                      color: _C.igPink.withOpacity(0.3),
                      blurRadius: 12,
                      offset: const Offset(0, 4),
                    ),
                  ],
                ),
                child: const Icon(Icons.person_search_rounded, color: Colors.white, size: 22),
              ),
              const SizedBox(width: 14),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Cari Akun Instagram',
                    style: TextStyle(
                      color: _C.text,
                      fontSize: 16,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  const Text(
                    'Masukkan username tanpa @',
                    style: TextStyle(
                      color: _C.textSub,
                      fontSize: 12,
                    ),
                  ),
                ],
              ),
            ],
          ),
          const SizedBox(height: 16),
          TextField(
            controller: _usernameController,
            style: const TextStyle(
              color: Colors.black,
              fontSize: 14,
              fontWeight: FontWeight.w500,
            ),
            decoration: InputDecoration(
              hintText: 'contoh: jokowi',
              hintStyle: TextStyle(color: _C.textDim),
              prefixIcon: const Icon(Icons.alternate_email_rounded, color: _C.igPink),
              filled: true,
              fillColor: _C.bg,
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: BorderSide(color: _C.border),
              ),
              enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: BorderSide(color: _C.border),
              ),
              focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: BorderSide(color: _C.igPink, width: 1.5),
              ),
              contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
            ),
            onSubmitted: (_) => _stalkInstagram(),
          ),
          const SizedBox(height: 14),
          SizedBox(
            width: double.infinity,
            child: Container(
              height: 48,
              decoration: BoxDecoration(
                gradient: _C.igGrad,
                borderRadius: BorderRadius.circular(14),
                boxShadow: [
                  BoxShadow(
                    color: _C.igPink.withOpacity(0.35),
                    blurRadius: 16,
                    offset: const Offset(0, 4),
                  ),
                  BoxShadow(
                    color: Colors.white.withOpacity(0.6),
                    blurRadius: 8,
                    offset: const Offset(-2, -2),
                  ),
                ],
              ),
              child: ElevatedButton(
                onPressed: _isLoading ? null : _stalkInstagram,
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.transparent,
                  shadowColor: Colors.transparent,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(14),
                  ),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(
                      _isLoading ? Icons.hourglass_top : Icons.search,
                      color: Colors.white,
                      size: 20,
                    ),
                    const SizedBox(width: 10),
                    Text(
                      _isLoading ? 'MENCARI...' : 'STALKING',
                      style: const TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.w800,
                        fontSize: 14,
                        letterSpacing: 0.5,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildErrorBanner() {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: _C.red.withOpacity(0.06),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: _C.red.withOpacity(0.3)),
      ),
      child: Row(
        children: [
          Icon(Icons.error_outline_rounded, color: _C.red, size: 20),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              _errorMessage!,
              style: TextStyle(
                color: _C.textSub,
                fontSize: 13,
              ),
            ),
          ),
          GestureDetector(
            onTap: () => setState(() => _errorMessage = null),
            child: Icon(Icons.close_rounded, color: _C.textDim, size: 18),
          ),
        ],
      ),
    );
  }

  Widget _buildLoadingState() {
    return Center(
      child: Column(
        children: [
          const SizedBox(height: 20),
          Container(
            width: 60,
            height: 60,
            decoration: BoxDecoration(
              gradient: _C.igGrad,
              shape: BoxShape.circle,
              boxShadow: [
                BoxShadow(
                  color: _C.igPink.withOpacity(0.3),
                  blurRadius: 20,
                  spreadRadius: 2,
                ),
              ],
            ),
            child: const Center(
              child: SizedBox(
                width: 30,
                height: 30,
                child: CircularProgressIndicator(
                  color: Colors.white,
                  strokeWidth: 3,
                ),
              ),
            ),
          ),
          const SizedBox(height: 16),
          const Text(
            'Mengintai Akun...',
            style: TextStyle(
              color: _C.textSub,
              fontSize: 14,
              fontWeight: FontWeight.w500,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildResultCard() {
    if (_userData == null) return const SizedBox();
    final data = _userData!;

    return Column(
      children: [
        Container(
          decoration: BoxDecoration(
            color: _C.surface,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: _C.border),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.04),
                blurRadius: 12,
                offset: const Offset(0, 6),
              ),
              BoxShadow(
                color: Colors.white.withOpacity(0.6),
                blurRadius: 8,
                offset: const Offset(-2, -2),
              ),
            ],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // ─── PROFILE HEADER ────────────────────────────────────────────
              Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  gradient: _C.igGrad,
                  borderRadius: const BorderRadius.only(
                    topLeft: Radius.circular(20),
                    topRight: Radius.circular(20),
                  ),
                ),
                child: Row(
                  children: [
                    Container(
                      width: 72,
                      height: 72,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        border: Border.all(color: Colors.white, width: 3),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withOpacity(0.2),
                            blurRadius: 12,
                            offset: const Offset(0, 4),
                          ),
                        ],
                      ),
                      child: ClipOval(
                        child: _buildProfileImage(data['profile_picture'] ?? ''),
                      ),
                    ),
                    const SizedBox(width: 16),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            data['full_name'] ?? data['username'] ?? 'Unknown',
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 18,
                              fontWeight: FontWeight.w700,
                            ),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                          Row(
                            children: [
                              Text(
                                '@${data['username'] ?? 'unknown'}',
                                style: const TextStyle(
                                  color: Colors.white70,
                                  fontSize: 13,
                                ),
                              ),
                              const SizedBox(width: 8),
                              if (data['is_verified'] == true)
                                const Icon(
                                  Icons.verified_rounded,
                                  color: Colors.white,
                                  size: 16,
                                ),
                              if (data['is_private'] == true)
                                Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                                  decoration: BoxDecoration(
                                    color: Colors.black.withOpacity(0.3),
                                    borderRadius: BorderRadius.circular(4),
                                  ),
                                  child: const Text(
                                    'PRIVATE',
                                    style: TextStyle(
                                      color: Colors.white70,
                                      fontSize: 8,
                                      fontWeight: FontWeight.w700,
                                    ),
                                  ),
                                ),
                            ],
                          ),
                          if (data['bio'] != null && data['bio'].isNotEmpty) ...[
                            const SizedBox(height: 4),
                            Text(
                              data['bio'],
                              style: const TextStyle(
                                color: Colors.white70,
                                fontSize: 12,
                              ),
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                            ),
                          ],
                        ],
                      ),
                    ),
                  ],
                ),
              ),

              // ─── STATS ──────────────────────────────────────────────────────
              Container(
                padding: const EdgeInsets.symmetric(vertical: 16),
                decoration: BoxDecoration(
                  border: Border(
                    bottom: BorderSide(color: _C.border),
                  ),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    _buildStatItem(
                      icon: Icons.post_add_rounded,
                      label: 'Posts',
                      value: _formatNumber(data['media_count']),
                      color: _C.blue,
                    ),
                    _buildStatItem(
                      icon: Icons.people_alt_rounded,
                      label: 'Followers',
                      value: _formatNumber(data['follower_count']),
                      color: _C.igPink,
                    ),
                    _buildStatItem(
                      icon: Icons.person_add_alt_1_rounded,
                      label: 'Following',
                      value: _formatNumber(data['following_count']),
                      color: _C.igBlue,
                    ),
                  ],
                ),
              ),

              // ─── DETAIL INFO ──────────────────────────────────────────────
              Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  children: [
                    _buildDetailRow(
                      icon: Icons.person_outline_rounded,
                      label: 'Username',
                      value: data['username'] ?? '-',
                      onCopy: () => _copyToClipboard(data['username'] ?? '', 'Username'),
                    ),
                    _buildDetailRow(
                      icon: Icons.badge_rounded,
                      label: 'Nama Lengkap',
                      value: data['full_name'] ?? '-',
                      onCopy: () => _copyToClipboard(data['full_name'] ?? '', 'Nama'),
                    ),
                    if (data['bio'] != null && data['bio'].isNotEmpty)
                      _buildDetailRow(
                        icon: Icons.link_rounded,
                        label: 'Bio',
                        value: data['bio'] ?? '-',
                        onCopy: () => _copyToClipboard(data['bio'] ?? '', 'Bio'),
                      ),
                    _buildDetailRow(
                      icon: Icons.verified_rounded,
                      label: 'Verified',
                      value: data['is_verified'] == true ? '✅ Yes' : '❌ No',
                    ),
                    _buildDetailRow(
                      icon: Icons.lock_rounded,
                      label: 'Private',
                      value: data['is_private'] == true ? '🔒 Private' : '🌍 Public',
                    ),
                    if (data['business_category_name'] != null && data['business_category_name'].isNotEmpty)
                      _buildDetailRow(
                        icon: Icons.business_center_rounded,
                        label: 'Category',
                        value: data['business_category_name'] ?? 'Personal',
                      ),
                    if (data['external_url'] != null && data['external_url'].isNotEmpty)
                      _buildDetailRow(
                        icon: Icons.open_in_browser_rounded,
                        label: 'Website',
                        value: data['external_url'] ?? '-',
                        onCopy: () => _copyToClipboard(data['external_url'] ?? '', 'Website'),
                      ),
                  ],
                ),
              ),
            ],
          ),
        ),

        const SizedBox(height: 16),

        // ─── MEDIA TAB ───────────────────────────────────────────────────────
        Container(
          decoration: BoxDecoration(
            color: _C.surface,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: _C.border),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.04),
                blurRadius: 12,
                offset: const Offset(0, 6),
              ),
              BoxShadow(
                color: Colors.white.withOpacity(0.6),
                blurRadius: 8,
                offset: const Offset(-2, -2),
              ),
            ],
          ),
          child: Column(
            children: [
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                child: Row(
                  children: [
                    Container(
                      width: 4,
                      height: 18,
                      decoration: BoxDecoration(
                        gradient: _C.igGrad,
                        borderRadius: BorderRadius.circular(2),
                      ),
                    ),
                    const SizedBox(width: 10),
                    _build3DText('Media & Posts', size: 15, color: _C.igPink),
                    const Spacer(),
                    if (_isLoadingMedia)
                      const SizedBox(
                        width: 20,
                        height: 20,
                        child: CircularProgressIndicator(
                          color: _C.igPink,
                          strokeWidth: 2,
                        ),
                      ),
                  ],
                ),
              ),

              if (_mediaList != null && _mediaList!.isNotEmpty)
                Padding(
                  padding: const EdgeInsets.all(12),
                  child: GridView.builder(
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 3,
                      crossAxisSpacing: 8,
                      mainAxisSpacing: 8,
                      childAspectRatio: 0.9,
                    ),
                    itemCount: _mediaList!.length > 20 ? 20 : _mediaList!.length,
                    itemBuilder: (context, index) {
                      final media = _mediaList![index];
                      final isVideo = media['type'] == 'video' || media['is_video'] == true;
                      final url = media['url'] ?? media['display_url'] ?? '';
                      final thumbnail = media['thumbnail'] ?? media['thumbnail_url'] ?? url;

                      return GestureDetector(
                        onTap: () => _showMediaDetail(media),
                        child: Container(
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(color: _C.border),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.black.withOpacity(0.04),
                                blurRadius: 4,
                                offset: const Offset(0, 2),
                              ),
                            ],
                          ),
                          child: Stack(
                            fit: StackFit.expand,
                            children: [
                              ClipRRect(
                                borderRadius: BorderRadius.circular(12),
                                child: thumbnail.isNotEmpty
                                    ? Image.network(
                                        thumbnail,
                                        fit: BoxFit.cover,
                                        loadingBuilder: (_, child, progress) {
                                          if (progress == null) return child;
                                          return Container(
                                            color: _C.bg,
                                            child: const Center(
                                              child: SizedBox(
                                                width: 20,
                                                height: 20,
                                                child: CircularProgressIndicator(
                                                  color: _C.igPink,
                                                  strokeWidth: 2,
                                                ),
                                              ),
                                            ),
                                          );
                                        },
                                        errorBuilder: (_, __, ___) => Container(
                                          color: _C.bg,
                                          child: const Icon(
                                            Icons.broken_image_rounded,
                                            color: _C.textDim,
                                            size: 30,
                                          ),
                                        ),
                                      )
                                    : Container(
                                        color: _C.bg,
                                        child: const Icon(
                                          Icons.image_rounded,
                                          color: _C.textDim,
                                          size: 30,
                                        ),
                                      ),
                              ),
                              if (isVideo)
                                Positioned(
                                  top: 6,
                                  right: 6,
                                  child: Container(
                                    padding: const EdgeInsets.symmetric(
                                      horizontal: 6,
                                      vertical: 3,
                                    ),
                                    decoration: BoxDecoration(
                                      color: Colors.black.withOpacity(0.7),
                                      borderRadius: BorderRadius.circular(6),
                                    ),
                                    child: const Row(
                                      mainAxisSize: MainAxisSize.min,
                                      children: [
                                        Icon(
                                          Icons.play_arrow_rounded,
                                          color: Colors.white,
                                          size: 14,
                                        ),
                                        SizedBox(width: 2),
                                        Text(
                                          'VIDEO',
                                          style: TextStyle(
                                            color: Colors.white,
                                            fontSize: 8,
                                            fontWeight: FontWeight.w700,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              Positioned(
                                bottom: 6,
                                right: 6,
                                child: GestureDetector(
                                  onTap: () => _downloadMedia(url, isVideo ? 'video' : 'image'),
                                  child: Container(
                                    padding: const EdgeInsets.all(6),
                                    decoration: BoxDecoration(
                                      color: Colors.black.withOpacity(0.7),
                                      borderRadius: BorderRadius.circular(8),
                                    ),
                                    child: _isDownloading
                                        ? const SizedBox(
                                            width: 16,
                                            height: 16,
                                            child: CircularProgressIndicator(
                                              color: Colors.white,
                                              strokeWidth: 2,
                                            ),
                                          )
                                        : const Icon(
                                            Icons.download_rounded,
                                            color: Colors.white,
                                            size: 16,
                                          ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
                )
              else if (!_isLoadingMedia && _mediaList != null)
                const Padding(
                  padding: EdgeInsets.symmetric(vertical: 30),
                  child: Column(
                    children: [
                      Icon(Icons.photo_library_rounded, color: _C.textDim, size: 40),
                      SizedBox(height: 8),
                      Text(
                        'Tidak ada postingan',
                        style: TextStyle(
                          color: _C.textSub,
                          fontSize: 13,
                        ),
                      ),
                    ],
                  ),
                ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildProfileImage(String url) {
    if (url.isEmpty) {
      return Container(
        color: Colors.white.withOpacity(0.3),
        child: const Icon(Icons.person, color: Colors.white, size: 32),
      );
    }
    return Image.network(
      url,
      fit: BoxFit.cover,
      errorBuilder: (_, __, ___) => Container(
        color: Colors.white.withOpacity(0.3),
        child: const Icon(Icons.person, color: Colors.white, size: 32),
      ),
    );
  }

  Widget _buildStatItem({
    required IconData icon,
    required String label,
    required String value,
    required Color color,
  }) {
    return Column(
      children: [
        Icon(icon, color: color, size: 22),
        const SizedBox(height: 4),
        Text(
          value,
          style: TextStyle(
            color: _C.text,
            fontSize: 18,
            fontWeight: FontWeight.w800,
          ),
        ),
        Text(
          label,
          style: TextStyle(
            color: _C.textSub,
            fontSize: 11,
            fontWeight: FontWeight.w500,
          ),
        ),
      ],
    );
  }

  Widget _buildDetailRow({
    required IconData icon,
    required String label,
    required String value,
    VoidCallback? onCopy,
  }) {
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      decoration: BoxDecoration(
        color: _C.bg,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: _C.border),
      ),
      child: Row(
        children: [
          Icon(icon, color: _C.igPink, size: 16),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  label,
                  style: TextStyle(
                    color: _C.textSub,
                    fontSize: 10,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                Text(
                  value,
                  style: TextStyle(
                    color: _C.text,
                    fontSize: 13,
                    fontWeight: FontWeight.w500,
                  ),
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                ),
              ],
            ),
          ),
          if (onCopy != null)
            GestureDetector(
              onTap: onCopy,
              child: Container(
                padding: const EdgeInsets.all(6),
                decoration: BoxDecoration(
                  color: _C.igPink.withOpacity(0.08),
                  shape: BoxShape.circle,
                ),
                child: Icon(Icons.copy_rounded, color: _C.igPink, size: 14),
              ),
            ),
        ],
      ),
    );
  }

  void _showMediaDetail(Map<String, dynamic> media) {
    final isVideo = media['type'] == 'video' || media['is_video'] == true;
    final url = media['url'] ?? media['display_url'] ?? '';
    final caption = media['caption'] ?? media['title'] ?? 'No caption';
    final likes = media['like_count'] ?? media['likes'] ?? 0;
    final comments = media['comment_count'] ?? media['comments'] ?? 0;

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => Container(
        height: MediaQuery.of(context).size.height * 0.85,
        decoration: BoxDecoration(
          color: _C.surface,
          borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.2),
              blurRadius: 20,
              offset: const Offset(0, -4),
            ),
          ],
        ),
        child: Column(
          children: [
            Container(
              margin: const EdgeInsets.only(top: 12),
              width: 40,
              height: 4,
              decoration: BoxDecoration(
                color: _C.border,
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            const SizedBox(height: 8),

            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              child: Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      gradient: _C.igGrad,
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Icon(
                      isVideo ? Icons.play_arrow_rounded : Icons.photo_rounded,
                      color: Colors.white,
                      size: 18,
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Text(
                      isVideo ? 'Video Post' : 'Photo Post',
                      style: TextStyle(
                        color: _C.text,
                        fontSize: 16,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ),
                  IconButton(
                    icon: const Icon(Icons.close_rounded, color: _C.textSub),
                    onPressed: () => Navigator.pop(context),
                    padding: EdgeInsets.zero,
                    constraints: const BoxConstraints(),
                  ),
                ],
              ),
            ),

            const Divider(height: 1, color: _C.border),

            Expanded(
              child: SingleChildScrollView(
                child: Column(
                  children: [
                    Container(
                      margin: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(16),
                        border: Border.all(color: _C.border),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withOpacity(0.08),
                            blurRadius: 12,
                            offset: const Offset(0, 4),
                          ),
                        ],
                      ),
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(16),
                        child: url.isNotEmpty
                            ? Image.network(
                                url,
                                fit: BoxFit.contain,
                                loadingBuilder: (_, child, progress) {
                                  if (progress == null) return child;
                                  return Container(
                                    height: 300,
                                    color: _C.bg,
                                    child: const Center(
                                      child: SizedBox(
                                        width: 30,
                                        height: 30,
                                        child: CircularProgressIndicator(
                                          color: _C.igPink,
                                          strokeWidth: 2.5,
                                        ),
                                      ),
                                    ),
                                  );
                                },
                                errorBuilder: (_, __, ___) => Container(
                                  height: 300,
                                  color: _C.bg,
                                  child: const Icon(
                                    Icons.broken_image_rounded,
                                    color: _C.textDim,
                                    size: 50,
                                  ),
                                ),
                              )
                            : Container(
                                height: 300,
                                color: _C.bg,
                                child: const Icon(
                                  Icons.image_rounded,
                                  color: _C.textDim,
                                  size: 50,
                                ),
                              ),
                      ),
                    ),

                    if (caption.isNotEmpty && caption != 'No caption')
                      Container(
                        margin: const EdgeInsets.symmetric(horizontal: 16),
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color: _C.bg,
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(color: _C.border),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text(
                              'Caption',
                              style: TextStyle(
                                color: _C.textSub,
                                fontSize: 11,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              caption,
                              style: TextStyle(
                                color: _C.text,
                                fontSize: 14,
                                height: 1.5,
                              ),
                            ),
                          ],
                        ),
                      ),

                    Container(
                      margin: const EdgeInsets.all(16),
                      padding: const EdgeInsets.symmetric(vertical: 12),
                      decoration: BoxDecoration(
                        color: _C.bg,
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: _C.border),
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                          _buildStatSmall(
                            icon: Icons.favorite_rounded,
                            label: 'Likes',
                            value: _formatNumber(likes),
                            color: _C.red,
                          ),
                          Container(
                            width: 1,
                            height: 30,
                            color: _C.border,
                          ),
                          _buildStatSmall(
                            icon: Icons.chat_bubble_outline_rounded,
                            label: 'Comments',
                            value: _formatNumber(comments),
                            color: _C.blue,
                          ),
                        ],
                      ),
                    ),

                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 16),
                      child: Container(
                        width: double.infinity,
                        height: 46,
                        decoration: BoxDecoration(
                          gradient: _C.igGrad,
                          borderRadius: BorderRadius.circular(14),
                          boxShadow: [
                            BoxShadow(
                              color: _C.igPink.withOpacity(0.3),
                              blurRadius: 12,
                              offset: const Offset(0, 4),
                            ),
                          ],
                        ),
                        child: ElevatedButton(
                          onPressed: _isDownloading ? null : () => _downloadMedia(url, isVideo ? 'video' : 'image'),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.transparent,
                            shadowColor: Colors.transparent,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(14),
                            ),
                          ),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(
                                _isDownloading ? Icons.hourglass_top : Icons.download_rounded,
                                color: Colors.white,
                                size: 20,
                              ),
                              const SizedBox(width: 10),
                              Text(
                                _isDownloading ? 'MENGUNDUH...' : 'DOWNLOAD MEDIA',
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.w800,
                                  fontSize: 14,
                                  letterSpacing: 0.5,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(height: 24),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStatSmall({
    required IconData icon,
    required String label,
    required String value,
    required Color color,
  }) {
    return Row(
      children: [
        Icon(icon, color: color, size: 18),
        const SizedBox(width: 6),
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              value,
              style: TextStyle(
                color: _C.text,
                fontSize: 16,
                fontWeight: FontWeight.w700,
              ),
            ),
            Text(
              label,
              style: TextStyle(
                color: _C.textSub,
                fontSize: 10,
              ),
            ),
          ],
        ),
      ],
    );
  }

  void _showInfoDialog() {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: _C.surface,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
          side: BorderSide(color: _C.igPink.withOpacity(0.3)),
        ),
        title: Row(
          children: [
            Container(
              width: 36,
              height: 36,
              decoration: BoxDecoration(
                gradient: _C.igGrad,
                borderRadius: BorderRadius.circular(10),
              ),
              child: const Icon(Icons.info_outline_rounded, color: Colors.white, size: 18),
            ),
            const SizedBox(width: 10),
            const Text(
              'Info Stalk',
              style: TextStyle(
                color: _C.text,
                fontWeight: FontWeight.w700,
                fontSize: 16,
              ),
            ),
          ],
        ),
        content: const Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              '🔍 Fitur ini digunakan untuk melihat informasi publik akun Instagram.',
              style: TextStyle(
                color: _C.textSub,
                fontSize: 13,
                height: 1.5,
              ),
            ),
            SizedBox(height: 12),
            Text(
              '📌 Data yang tersedia:',
              style: TextStyle(
                color: _C.text,
                fontWeight: FontWeight.w600,
                fontSize: 13,
              ),
            ),
            SizedBox(height: 6),
            Text(
              '• Nama lengkap & username\n• Bio & kategori\n• Followers & following\n• Jumlah postingan\n• Status verifikasi & private\n• Link website (jika ada)',
              style: TextStyle(
                color: _C.textSub,
                fontSize: 12,
                height: 1.6,
              ),
            ),
            SizedBox(height: 12),
            Text(
              '⚠️ Hanya menampilkan informasi publik yang tersedia.',
              style: TextStyle(
                color: _C.amber,
                fontSize: 12,
                fontStyle: FontStyle.italic,
              ),
            ),
          ],
        ),
        actions: [
          Container(
            decoration: BoxDecoration(
              gradient: _C.igGrad,
              borderRadius: BorderRadius.circular(12),
            ),
            child: TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text(
                'OK',
                style: TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}