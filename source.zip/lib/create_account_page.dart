import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'api_config.dart';
import 'role_permissions.dart';

class CreateAccountPage extends StatefulWidget {
  final String sessionKey;
  final String creatorRole;

  const CreateAccountPage({super.key, required this.sessionKey, required this.creatorRole});

  @override
  State<CreateAccountPage> createState() => _CreateAccountPageState();
}

class _CreateAccountPageState extends State<CreateAccountPage> {
  final _username = TextEditingController();
  final _password = TextEditingController();
  final _days = TextEditingController(text: '30');
  late List<String> _allowedRoles;
  String _role = 'member';
  bool _loading = false;

  static const bg = Color(0xFFF6F7FB);
  static const yellow = Color(0xFFFFC72C);
  static const blue = Color(0xFF1597E5);

  @override
  void initState() {
    super.initState();
    _allowedRoles = RolePermissions.creatableRoles(widget.creatorRole);
    if (_allowedRoles.isNotEmpty) _role = _allowedRoles.first;
    _syncDefaultDays();
  }

  void _syncDefaultDays() {
    if (RolePermissions.maxDaysFor(widget.creatorRole, _role) <= 30) {
      _days.text = '30';
    }
  }

  Future<void> _create() async {
    final u = _username.text.trim();
    final p = _password.text.trim();
    final days = int.tryParse(_days.text.trim());
    if (u.isEmpty || p.isEmpty || days == null) {
      _snack('Username, password, dan durasi wajib diisi.', true);
      return;
    }
    if (!RolePermissions.canCreate(widget.creatorRole, _role, days)) {
      _snack('Role atau durasi tidak diizinkan untuk akun kamu.', true);
      return;
    }

    setState(() => _loading = true);
    try {
      final uri = ApiConfig.endpoint('/api/user/userAdd', {
        'key': widget.sessionKey,
        'username': u,
        'password': p,
        'day': '$days',
        'role': _role,
      });
      final response = await http.get(uri);
      final data = jsonDecode(response.body);
      if (data is Map && data['created'] == true) {
        _snack('Akun $u berhasil dibuat.', false);
        if (mounted) Navigator.pop(context, true);
      } else {
        _snack(data is Map ? (data['message'] ?? 'Gagal membuat akun.') : 'Gagal membuat akun.', true);
      }
    } catch (e) {
      _snack('Tidak dapat menghubungi server.', true);
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  void _snack(String message, bool error) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(message, style: const TextStyle(fontFamily: 'ShareTechMono')),
      backgroundColor: error ? Colors.red.shade700 : Colors.black87,
      behavior: SnackBarBehavior.floating,
    ));
  }

  InputDecoration _decoration(String label, IconData icon) => InputDecoration(
    labelText: label,
    prefixIcon: Icon(icon),
    filled: true,
    fillColor: Colors.white,
    border: OutlineInputBorder(borderRadius: BorderRadius.circular(16)),
    enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: const BorderSide(color: Colors.black, width: 2)),
    focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: const BorderSide(color: blue, width: 2)),
  );

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bg,
      appBar: AppBar(
        backgroundColor: bg,
        foregroundColor: Colors.black,
        elevation: 0,
        title: const Text('CREATE ACCOUNT', style: TextStyle(fontFamily: 'ShareTechMono', fontWeight: FontWeight.bold)),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(24, 12, 24, 32),
          child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
            Container(
              padding: const EdgeInsets.all(18),
              decoration: BoxDecoration(color: yellow, border: Border.all(color: Colors.black, width: 2.5), borderRadius: BorderRadius.circular(20), boxShadow: const [BoxShadow(color: Colors.black, offset: Offset(0, 5))]),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Text('BUAT AKUN BARU', style: TextStyle(fontSize: 20, fontFamily: 'Orbitron', fontWeight: FontWeight.bold)),
                const SizedBox(height: 6),
                Text('Creator: ${widget.creatorRole.toUpperCase()}', style: const TextStyle(fontFamily: 'ShareTechMono')),
              ]),
            ),
            const SizedBox(height: 24),
            TextField(controller: _username, decoration: _decoration('Username', Icons.person_outline)),
            const SizedBox(height: 14),
            TextField(controller: _password, obscureText: true, decoration: _decoration('Password', Icons.lock_outline)),
            const SizedBox(height: 14),
            DropdownButtonFormField<String>(
              value: _allowedRoles.contains(_role) ? _role : null,
              decoration: _decoration('Role', Icons.shield_outlined),
              items: _allowedRoles.map((r) => DropdownMenuItem(value: r, child: Text(r.toUpperCase()))).toList(),
              onChanged: _allowedRoles.isEmpty ? null : (v) { if (v != null) setState(() { _role = v; _syncDefaultDays(); }); },
            ),
            const SizedBox(height: 14),
            TextField(controller: _days, keyboardType: TextInputType.number, decoration: _decoration('Durasi (hari)', Icons.calendar_month)),
            if ((widget.creatorRole.toLowerCase() == 'reseller' || widget.creatorRole.toLowerCase() == 'vip') && _role == 'member')
              const Padding(padding: EdgeInsets.only(top: 8), child: Text('Reseller/VIP dibatasi maksimal 30 hari untuk Member.', style: TextStyle(fontFamily: 'ShareTechMono'))),
            const SizedBox(height: 24),
            SizedBox(height: 54, child: ElevatedButton.icon(
              onPressed: _loading || _allowedRoles.isEmpty ? null : _create,
              icon: _loading ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.person_add_alt_1),
              label: Text(_loading ? 'MEMPROSES...' : 'CREATE ACCOUNT'),
              style: ElevatedButton.styleFrom(backgroundColor: blue, foregroundColor: Colors.white, side: const BorderSide(color: Colors.black, width: 2), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)), elevation: 4),
            )),
            if (_allowedRoles.isEmpty) const Padding(padding: EdgeInsets.only(top: 20), child: Text('Role ini tidak memiliki izin membuat akun.', textAlign: TextAlign.center, style: TextStyle(fontFamily: 'ShareTechMono'))),
          ]),
        ),
      ),
    );
  }

  @override
  void dispose() {
    _username.dispose();
    _password.dispose();
    _days.dispose();
    super.dispose();
  }
}
