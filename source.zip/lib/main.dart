// MAIN.DART

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'login_page.dart';
import 'dashboard_page.dart';
import 'home_page.dart';
import 'seller_page.dart';
import 'admin_page.dart';
import 'owner_page.dart';
import 'landing.dart';

// ─────────────────────────────────────────────
//  TEMA WARNA PUTIH X BIRU NEW 
// ─────────────────────────────────────────────
class _C {
  static const bg        = Color(0xFFE8EDF2);
  static const surface   = Color(0xFFFFFFFF);
  static const card      = Color(0xFFFFFFFF);
  static const border    = Color(0xFFD4DCE4);
  static const borderLit = Color(0xFFCBD5E1);

  static const blue       = Color(0xFF1A73E8);
  static const blueMid    = Color(0xFF4285F4);
  static const blueLight  = Color(0xFF8AB4F8);
  static const blueFrost  = Color(0xFFC2D8F8);
  static const blueDark   = Color(0xFF1557B0);

  static const green     = Color(0xFF34A853);
  static const amber     = Color(0xFFFBBC04);
  static const red       = Color(0xFFEA4335);
  static const orange    = Color(0xFFFB8B24);

  static const text      = Color(0xFF202124);
  static const textSub   = Color(0xFF5F6368);
  static const textDim   = Color(0xFF9AA0A6);
  static const white     = Color(0xFFFFFFFF);
}

// ─────────────────────────────────────────────
//  3D TEXT (MINECRAFT STYLE)
// ─────────────────────────────────────────────
Widget _build3DText(String text, {double size = 16, Color? color}) {
  final textColor = color ?? _C.blue;
  return Stack(
    children: [
      Text(
        text,
        style: TextStyle(
          fontSize: size,
          fontWeight: FontWeight.w900,
          color: Colors.black.withOpacity(0.12),
          letterSpacing: 1,
        ),
      ),
      Transform.translate(
        offset: const Offset(-1.5, -1.5),
        child: Text(
          text,
          style: TextStyle(
            fontSize: size,
            fontWeight: FontWeight.w900,
            color: Colors.white.withOpacity(0.3),
            letterSpacing: 1,
          ),
        ),
      ),
      Transform.translate(
        offset: const Offset(-3, -3),
        child: Text(
          text,
          style: TextStyle(
            fontSize: size,
            fontWeight: FontWeight.w900,
            color: textColor,
            letterSpacing: 1,
            shadows: [
              Shadow(
                color: textColor.withOpacity(0.3),
                blurRadius: 12,
                offset: const Offset(0, 3),
              ),
            ],
          ),
        ),
      ),
    ],
  );
}

// ─────────────────────────────────────────────
//  THEME BUILDER - SOFT
// ─────────────────────────────────────────────
class _AppTheme {
  static const _font = 'ShareTechMono';

  static ThemeData build() => ThemeData(
    useMaterial3: true,
    brightness: Brightness.light,
    fontFamily: _font,
    scaffoldBackgroundColor: _C.bg,

    colorScheme: const ColorScheme.light(
      brightness:             Brightness.light,
      primary:                _C.blue,
      onPrimary:              _C.white,
      primaryContainer:       _C.blueFrost,
      onPrimaryContainer:     _C.text,
      secondary:              _C.blueMid,
      onSecondary:            _C.white,
      secondaryContainer:     _C.blueLight,
      onSecondaryContainer:   _C.text,
      tertiary:               _C.green,
      onTertiary:             _C.white,
      error:                  _C.red,
      onError:                _C.white,
      surface:                _C.surface,
      onSurface:              _C.text,
      surfaceContainerHighest: _C.card,
      outline:                _C.border,
      outlineVariant:         _C.borderLit,
      shadow:                 Colors.black12,
      scrim:                  Colors.black54,
      inverseSurface:         _C.text,
      onInverseSurface:       _C.white,
      inversePrimary:         _C.blueLight,
    ),

    appBarTheme: const AppBarTheme(
      backgroundColor:      _C.surface,
      foregroundColor:      _C.text,
      elevation:            0,
      scrolledUnderElevation: 0,
      centerTitle:          true,
      titleTextStyle: TextStyle(
        fontFamily:   _font,
        fontSize:     18,
        fontWeight:   FontWeight.w700,
        color:        _C.text,
        letterSpacing: 0.3,
      ),
      iconTheme:        IconThemeData(color: _C.textSub, size: 22),
      actionsIconTheme: IconThemeData(color: _C.textSub, size: 20),
      systemOverlayStyle: SystemUiOverlayStyle(
        statusBarColor:                    Colors.transparent,
        statusBarIconBrightness:           Brightness.dark,
        statusBarBrightness:               Brightness.light,
        systemNavigationBarColor:          _C.bg,
        systemNavigationBarIconBrightness: Brightness.dark,
      ),
    ),

    cardTheme: CardThemeData(
      color:        _C.surface,
      elevation:    0,
      margin:       EdgeInsets.zero,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
        side: const BorderSide(color: _C.border, width: 1),
      ),
      clipBehavior: Clip.antiAlias,
    ),

    elevatedButtonTheme: ElevatedButtonThemeData(
      style: ButtonStyle(
        backgroundColor: WidgetStateProperty.resolveWith((s) {
          if (s.contains(WidgetState.disabled)) return _C.border;
          if (s.contains(WidgetState.pressed))  return _C.blueDark;
          return _C.blue;
        }),
        foregroundColor: WidgetStateProperty.all(_C.white),
        overlayColor:  WidgetStateProperty.all(_C.blueFrost.withOpacity(0.2)),
        elevation:     WidgetStateProperty.all(2),
        shadowColor:   WidgetStateProperty.all(_C.blue.withOpacity(0.3)),
        padding:       WidgetStateProperty.all(
          const EdgeInsets.symmetric(horizontal: 24, vertical: 14),
        ),
        shape: WidgetStateProperty.all(
          RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        ),
        textStyle: WidgetStateProperty.all(
          const TextStyle(fontFamily: _font, fontSize: 14, fontWeight: FontWeight.w700, letterSpacing: 0.5),
        ),
        animationDuration: const Duration(milliseconds: 180),
      ),
    ),

    outlinedButtonTheme: OutlinedButtonThemeData(
      style: ButtonStyle(
        foregroundColor: WidgetStateProperty.resolveWith((s) {
          if (s.contains(WidgetState.pressed)) return _C.blue;
          return _C.textSub;
        }),
        side: WidgetStateProperty.resolveWith((s) {
          if (s.contains(WidgetState.pressed)) return const BorderSide(color: _C.blue, width: 1.5);
          if (s.contains(WidgetState.focused)) return const BorderSide(color: _C.blue, width: 1.5);
          return const BorderSide(color: _C.border, width: 1);
        }),
        backgroundColor: WidgetStateProperty.resolveWith((s) {
          if (s.contains(WidgetState.pressed)) return _C.blue.withOpacity(0.05);
          return Colors.transparent;
        }),
        overlayColor: WidgetStateProperty.all(_C.blue.withOpacity(0.06)),
        padding:      WidgetStateProperty.all(
          const EdgeInsets.symmetric(horizontal: 24, vertical: 14),
        ),
        shape: WidgetStateProperty.all(
          RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        ),
        textStyle: WidgetStateProperty.all(
          const TextStyle(fontFamily: _font, fontSize: 14, fontWeight: FontWeight.w600, letterSpacing: 0.4),
        ),
      ),
    ),

    textButtonTheme: TextButtonThemeData(
      style: ButtonStyle(
        foregroundColor: WidgetStateProperty.resolveWith((s) {
          if (s.contains(WidgetState.pressed)) return _C.blueDark;
          return _C.blue;
        }),
        overlayColor: WidgetStateProperty.all(_C.blue.withOpacity(0.06)),
        padding:      WidgetStateProperty.all(
          const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        ),
        shape: WidgetStateProperty.all(
          RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
        ),
        textStyle: WidgetStateProperty.all(
          const TextStyle(fontFamily: _font, fontSize: 13, fontWeight: FontWeight.w600, letterSpacing: 0.3),
        ),
      ),
    ),

    inputDecorationTheme: InputDecorationTheme(
      filled:      true,
      fillColor:   _C.white,
      hoverColor:  _C.bg,
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide:   const BorderSide(color: _C.border, width: 1),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide:   const BorderSide(color: _C.border, width: 1),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide:   const BorderSide(color: _C.blue, width: 1.5),
      ),
      errorBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide:   const BorderSide(color: _C.red, width: 1),
      ),
      focusedErrorBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide:   const BorderSide(color: _C.red, width: 1.5),
      ),
      disabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide:   const BorderSide(color: _C.textDim, width: 1),
      ),
      labelStyle:          const TextStyle(color: _C.textSub,  fontSize: 13),
      hintStyle:           const TextStyle(color: _C.textDim,  fontSize: 13),
      errorStyle:          const TextStyle(color: _C.red,      fontSize: 11),
      prefixIconColor:     _C.textSub,
      suffixIconColor:     _C.textSub,
      floatingLabelStyle:  const TextStyle(color: _C.blue, fontSize: 12),
    ),

    chipTheme: ChipThemeData(
      backgroundColor:     _C.bg,
      selectedColor:       _C.blueFrost,
      disabledColor:       _C.border,
      deleteIconColor:     _C.textSub,
      labelStyle:          const TextStyle(color: _C.text,  fontSize: 12, fontFamily: _font),
      secondaryLabelStyle: const TextStyle(color: _C.blue, fontSize: 12, fontFamily: _font),
      padding:             const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(8),
        side:         const BorderSide(color: _C.border),
      ),
      side:            const BorderSide(color: _C.border),
      elevation:       0,
      pressElevation:  2,
      showCheckmark:   false,
    ),

    bottomNavigationBarTheme: const BottomNavigationBarThemeData(
      backgroundColor:      _C.surface,
      selectedItemColor:    _C.blue,
      unselectedItemColor:  _C.textDim,
      elevation:            4,
      type:                 BottomNavigationBarType.fixed,
      selectedLabelStyle:   TextStyle(fontSize: 10, fontFamily: _font, fontWeight: FontWeight.w700),
      unselectedLabelStyle: TextStyle(fontSize: 10, fontFamily: _font),
    ),

    navigationBarTheme: NavigationBarThemeData(
      backgroundColor:  _C.surface,
      indicatorColor:   _C.blueFrost.withOpacity(0.5),
      iconTheme: WidgetStateProperty.resolveWith((s) {
        if (s.contains(WidgetState.selected)) return const IconThemeData(color: _C.blue, size: 22);
        return const IconThemeData(color: _C.textDim, size: 22);
      }),
      labelTextStyle: WidgetStateProperty.resolveWith((s) {
        if (s.contains(WidgetState.selected)) {
          return const TextStyle(color: _C.blue, fontSize: 11, fontFamily: _font, fontWeight: FontWeight.w700);
        }
        return const TextStyle(color: _C.textDim, fontSize: 11, fontFamily: _font);
      }),
      elevation:     0,
      overlayColor:  WidgetStateProperty.all(_C.blue.withOpacity(0.06)),
      labelBehavior: NavigationDestinationLabelBehavior.alwaysShow,
    ),

    navigationRailTheme: NavigationRailThemeData(
      backgroundColor:            _C.surface,
      selectedIconTheme:          const IconThemeData(color: _C.blue, size: 22),
      unselectedIconTheme:        const IconThemeData(color: _C.textDim, size: 22),
      selectedLabelTextStyle:     const TextStyle(color: _C.blue, fontSize: 11, fontFamily: _font, fontWeight: FontWeight.w700),
      unselectedLabelTextStyle:   const TextStyle(color: _C.textDim, fontSize: 11, fontFamily: _font),
      indicatorColor:             _C.blueFrost.withOpacity(0.4),
      elevation:                  0,
      useIndicator:               true,
    ),

    drawerTheme: DrawerThemeData(
      backgroundColor:   _C.surface,
      elevation:         4,
      surfaceTintColor:  Colors.transparent,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.only(
          topRight:    Radius.circular(24),
          bottomRight: Radius.circular(24),
        ),
      ),
    ),

    dialogTheme: DialogThemeData(
      backgroundColor: _C.surface,
      elevation:       4,
      surfaceTintColor: Colors.transparent,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(20),
        side:         const BorderSide(color: _C.border, width: 1),
      ),
      titleTextStyle: const TextStyle(
        fontFamily:    _font,
        fontSize:      18,
        fontWeight:    FontWeight.w700,
        color:         _C.text,
        letterSpacing: 0.2,
      ),
      contentTextStyle: const TextStyle(
        fontFamily: _font,
        fontSize:   14,
        color:      _C.textSub,
        height:     1.6,
      ),
    ),

    bottomSheetTheme: const BottomSheetThemeData(
      backgroundColor:      _C.surface,
      modalBackgroundColor: _C.surface,
      elevation:            0,
      modalElevation:       0,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      showDragHandle:   true,
      dragHandleColor:  _C.border,
      dragHandleSize:   Size(40, 4),
      clipBehavior:     Clip.antiAlias,
    ),

    snackBarTheme: SnackBarThemeData(
      backgroundColor:  _C.surface,
      contentTextStyle: const TextStyle(color: _C.text, fontFamily: _font, fontSize: 13),
      actionTextColor:  _C.blue,
      behavior:         SnackBarBehavior.floating,
      elevation:        0,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
        side:         const BorderSide(color: _C.border, width: 1),
      ),
    ),

    tabBarTheme: TabBarThemeData(
      labelColor:              _C.blue,
      unselectedLabelColor:    _C.textDim,
      indicatorColor:          _C.blue,
      indicatorSize:           TabBarIndicatorSize.label,
      labelStyle:              const TextStyle(fontFamily: _font, fontSize: 13, fontWeight: FontWeight.w700),
      unselectedLabelStyle:    const TextStyle(fontFamily: _font, fontSize: 13),
      overlayColor:            WidgetStateProperty.all(_C.blue.withOpacity(0.06)),
      dividerColor:            _C.border,
    ),

    listTileTheme: const ListTileThemeData(
      tileColor:         Colors.transparent,
      selectedTileColor: Color(0x1A1A73E8),
      iconColor:         _C.textSub,
      selectedColor:     _C.blue,
      textColor:         _C.text,
      subtitleTextStyle: TextStyle(color: _C.textSub, fontSize: 12),
      contentPadding:    EdgeInsets.symmetric(horizontal: 16, vertical: 4),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.all(Radius.circular(10)),
      ),
    ),

    dividerTheme: const DividerThemeData(
      color:     _C.border,
      thickness: 1,
      space:     1,
    ),

    switchTheme: SwitchThemeData(
      thumbColor: WidgetStateProperty.resolveWith((s) {
        if (s.contains(WidgetState.selected)) return _C.blue;
        return _C.textDim;
      }),
      trackColor: WidgetStateProperty.resolveWith((s) {
        if (s.contains(WidgetState.selected)) return _C.blue.withOpacity(0.4);
        return _C.border;
      }),
      trackOutlineColor: WidgetStateProperty.all(Colors.transparent),
      overlayColor:      WidgetStateProperty.all(_C.blue.withOpacity(0.08)),
    ),

    checkboxTheme: CheckboxThemeData(
      fillColor: WidgetStateProperty.resolveWith((s) {
        if (s.contains(WidgetState.selected)) return _C.blue;
        return Colors.transparent;
      }),
      checkColor:   WidgetStateProperty.all(_C.white),
      side:         const BorderSide(color: _C.border, width: 1.5),
      shape:        RoundedRectangleBorder(borderRadius: BorderRadius.circular(4)),
      overlayColor: WidgetStateProperty.all(_C.blue.withOpacity(0.08)),
    ),

    radioTheme: RadioThemeData(
      fillColor: WidgetStateProperty.resolveWith((s) {
        if (s.contains(WidgetState.selected)) return _C.blue;
        return _C.textDim;
      }),
      overlayColor: WidgetStateProperty.all(_C.blue.withOpacity(0.08)),
    ),

    sliderTheme: SliderThemeData(
      activeTrackColor:    _C.blue,
      inactiveTrackColor:  _C.border,
      thumbColor:          _C.blue,
      overlayColor:        _C.blue.withOpacity(0.12),
      valueIndicatorColor: _C.blueFrost,
      valueIndicatorTextStyle: const TextStyle(color: _C.text, fontSize: 12, fontFamily: _font),
      trackHeight:         3,
      thumbShape:          const RoundSliderThumbShape(enabledThumbRadius: 7),
    ),

    progressIndicatorTheme: const ProgressIndicatorThemeData(
      color:              _C.blue,
      linearTrackColor:   _C.border,
      circularTrackColor: _C.border,
      linearMinHeight:    3,
    ),

    floatingActionButtonTheme: FloatingActionButtonThemeData(
      backgroundColor:    _C.blue,
      foregroundColor:    _C.white,
      elevation:          4,
      focusElevation:     0,
      hoverElevation:     0,
      highlightElevation: 0,
      splashColor:        _C.blueFrost.withOpacity(0.2),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
    ),

    iconTheme:        const IconThemeData(color: _C.textSub, size: 22),
    primaryIconTheme: const IconThemeData(color: _C.blue, size: 22),

    popupMenuTheme: PopupMenuThemeData(
      color:            _C.surface,
      elevation:        2,
      shadowColor:      Colors.black12,
      surfaceTintColor: Colors.transparent,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
        side:         const BorderSide(color: _C.border, width: 1),
      ),
      textStyle: const TextStyle(color: _C.text, fontFamily: _font, fontSize: 13),
      labelTextStyle: WidgetStateProperty.all(
        const TextStyle(color: _C.text, fontFamily: _font, fontSize: 13),
      ),
      iconColor: _C.textSub,
    ),

    tooltipTheme: TooltipThemeData(
      decoration: BoxDecoration(
        color:        _C.surface,
        borderRadius: BorderRadius.circular(8),
        border:       Border.all(color: _C.border),
      ),
      textStyle: const TextStyle(color: _C.text, fontSize: 11, fontFamily: _font),
      padding:   const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
    ),

    scrollbarTheme: ScrollbarThemeData(
      thumbColor:      WidgetStateProperty.all(_C.border),
      trackColor:      WidgetStateProperty.all(_C.surface),
      radius:          const Radius.circular(4),
      thickness:       WidgetStateProperty.all(3),
      crossAxisMargin: 2,
    ),

    pageTransitionsTheme: const PageTransitionsTheme(
      builders: {
        TargetPlatform.android: _SteelTransitionBuilder(),
        TargetPlatform.iOS:     _SteelTransitionBuilder(),
        TargetPlatform.windows: _SteelTransitionBuilder(),
        TargetPlatform.macOS:   _SteelTransitionBuilder(),
        TargetPlatform.linux:   _SteelTransitionBuilder(),
      },
    ),

    textTheme: const TextTheme(
      displayLarge:   TextStyle(fontFamily: _font, fontSize: 57, fontWeight: FontWeight.w800, color: _C.text, letterSpacing: -1.5),
      displayMedium:  TextStyle(fontFamily: _font, fontSize: 45, fontWeight: FontWeight.w700, color: _C.text, letterSpacing: -1.0),
      displaySmall:   TextStyle(fontFamily: _font, fontSize: 36, fontWeight: FontWeight.w700, color: _C.text, letterSpacing: -0.5),
      headlineLarge:  TextStyle(fontFamily: _font, fontSize: 32, fontWeight: FontWeight.w700, color: _C.text, letterSpacing: -0.3),
      headlineMedium: TextStyle(fontFamily: _font, fontSize: 26, fontWeight: FontWeight.w600, color: _C.text, letterSpacing: -0.2),
      headlineSmall:  TextStyle(fontFamily: _font, fontSize: 22, fontWeight: FontWeight.w600, color: _C.text),
      titleLarge:     TextStyle(fontFamily: _font, fontSize: 18, fontWeight: FontWeight.w600, color: _C.text, letterSpacing:  0.2),
      titleMedium:    TextStyle(fontFamily: _font, fontSize: 15, fontWeight: FontWeight.w500, color: _C.text, letterSpacing:  0.1),
      titleSmall:     TextStyle(fontFamily: _font, fontSize: 13, fontWeight: FontWeight.w500, color: _C.textSub),
      bodyLarge:      TextStyle(fontFamily: _font, fontSize: 16, fontWeight: FontWeight.w400, color: _C.text,    height: 1.6),
      bodyMedium:     TextStyle(fontFamily: _font, fontSize: 14, fontWeight: FontWeight.w400, color: _C.text,    height: 1.6),
      bodySmall:      TextStyle(fontFamily: _font, fontSize: 12, fontWeight: FontWeight.w400, color: _C.textSub, height: 1.5),
      labelLarge:     TextStyle(fontFamily: _font, fontSize: 14, fontWeight: FontWeight.w600, color: _C.text,    letterSpacing: 0.5),
      labelMedium:    TextStyle(fontFamily: _font, fontSize: 12, fontWeight: FontWeight.w500, color: _C.textSub, letterSpacing: 0.4),
      labelSmall:     TextStyle(fontFamily: _font, fontSize: 10, fontWeight: FontWeight.w500, color: _C.textDim, letterSpacing: 0.6),
    ),
  );
}

// ─────────────────────────────────────────────
//  CUSTOM PAGE TRANSITION — Steel Fade + Slide
// ─────────────────────────────────────────────
class _SteelTransitionBuilder extends PageTransitionsBuilder {
  const _SteelTransitionBuilder();

  @override
  Widget buildTransitions<T>(
    PageRoute<T> route,
    BuildContext context,
    Animation<double> animation,
    Animation<double> secondaryAnimation,
    Widget child,
  ) {
    final inCurve  = CurvedAnimation(parent: animation,          curve: Curves.easeOutCubic);
    final outCurve = CurvedAnimation(parent: secondaryAnimation,  curve: Curves.easeInCubic);

    return FadeTransition(
      opacity: inCurve,
      child: SlideTransition(
        position: Tween<Offset>(
          begin: const Offset(0, 0.035),
          end:   Offset.zero,
        ).animate(inCurve),
        child: FadeTransition(
          opacity: Tween<double>(begin: 1.0, end: 0.82).animate(outCurve),
          child: ScaleTransition(
            scale: Tween<double>(begin: 1.0, end: 0.97).animate(outCurve),
            child: child,
          ),
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────
//  ROUTE BUILDER
// ─────────────────────────────────────────────
Route<dynamic>? _generateRoute(RouteSettings settings) {
  final args = settings.arguments as Map<String, dynamic>?;

  Widget page;

  switch (settings.name) {
    case '/':
      page = const LandingPage();

    case '/login':
      page = const LoginPage();

    case '/dashboard':
      page = DashboardPage(
        username:    args!['username']    as String,
        password:    args['password']    as String,
        role:        args['role']        as String,
        sessionKey:  args['key']         as String,
        expiredDate: args['expiredDate'] as String,
        listBug:  List<Map<String, dynamic>>.from(args['listBug']  ?? []),
        listDoos: List<Map<String, dynamic>>.from(args['listDoos'] ?? []),
        news:     List<Map<String, dynamic>>.from(args['news']     ?? []),
      );

    case '/home':
      page = HomePage(
        username:    args!['username']    as String,
        password:    args['password']    as String,
        role:        args['role']        as String,
        expiredDate: args['expiredDate'] as String,
        sessionKey:  args['sessionKey']  as String,
        listBug: List<Map<String, dynamic>>.from(args['listBug'] ?? []),
      );

    case '/seller':
      page = SellerPage(keyToken: args!['keyToken'] as String);

    case '/admin':
      page = AdminPage(sessionKey: args!['sessionKey'] as String);

    case '/owner':
      page = OwnerPage(
        sessionKey: args!['sessionKey'] as String,
        username:   args['username']    as String,
      );

    default:
      page = _NotFoundPage(routeName: settings.name ?? 'unknown');
  }

  return PageRouteBuilder<dynamic>(
    settings: settings,
    transitionDuration:        const Duration(milliseconds: 320),
    reverseTransitionDuration: const Duration(milliseconds: 260),
    pageBuilder: (_, __, ___) => page,
    transitionsBuilder: (_, animation, secondaryAnimation, child) {
      final inCurve  = CurvedAnimation(parent: animation,         curve: Curves.easeOutCubic);
      final outCurve = CurvedAnimation(parent: secondaryAnimation, curve: Curves.easeInCubic);

      return FadeTransition(
        opacity: inCurve,
        child: SlideTransition(
          position: Tween<Offset>(
            begin: const Offset(0, 0.035),
            end:   Offset.zero,
          ).animate(inCurve),
          child: FadeTransition(
            opacity: Tween<double>(begin: 1.0, end: 0.82).animate(outCurve),
            child: ScaleTransition(
              scale: Tween<double>(begin: 1.0, end: 0.97).animate(outCurve),
              child: child,
            ),
          ),
        ),
      );
    },
  );
}

// ─────────────────────────────────────────────
//  404 PAGE
// ─────────────────────────────────────────────
class _NotFoundPage extends StatefulWidget {
  const _NotFoundPage({required this.routeName});
  final String routeName;

  @override
  State<_NotFoundPage> createState() => _NotFoundPageState();
}

class _NotFoundPageState extends State<_NotFoundPage>
    with SingleTickerProviderStateMixin {
  late final AnimationController _ctrl;
  late final Animation<double>   _fade;
  late final Animation<Offset>   _slide;
  late final Animation<double>   _glow;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 800))
      ..forward();

    _fade  = CurvedAnimation(parent: _ctrl, curve: Curves.easeOut);
    _slide = Tween<Offset>(begin: const Offset(0, 0.08), end: Offset.zero)
        .animate(CurvedAnimation(parent: _ctrl, curve: Curves.easeOutCubic));
    _glow  = Tween<double>(begin: 0, end: 1)
        .animate(CurvedAnimation(parent: _ctrl, curve: const Interval(0.5, 1, curve: Curves.easeOut)));
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _C.bg,
      body: Center(
        child: FadeTransition(
          opacity: _fade,
          child: SlideTransition(
            position: _slide,
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 32),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  AnimatedBuilder(
                    animation: _glow,
                    builder: (_, child) => Container(
                      width: 88, height: 88,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: _C.surface,
                        border: Border.all(color: _C.border, width: 1.5),
                        boxShadow: [
                          BoxShadow(
                            color:        _C.blue.withOpacity(0.12 * _glow.value),
                            blurRadius:   40,
                            spreadRadius: 6,
                          ),
                        ],
                      ),
                      child: child,
                    ),
                    child: const Icon(Icons.explore_off_rounded, color: _C.textSub, size: 34),
                  ),

                  const SizedBox(height: 28),

                  _build3DText('404', size: 72, color: _C.blue),

                  const SizedBox(height: 10),

                  Text(
                    'Route not found',
                    style: const TextStyle(
                      fontFamily: 'ShareTechMono',
                      fontSize:   16,
                      fontWeight: FontWeight.w600,
                      color:      _C.textSub,
                      letterSpacing: 0.3,
                    ),
                  ),

                  const SizedBox(height: 6),

                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
                    decoration: BoxDecoration(
                      color:        _C.surface,
                      borderRadius: BorderRadius.circular(6),
                      border:       Border.all(color: _C.border),
                    ),
                    child: Text(
                      '"${widget.routeName}"',
                      style: const TextStyle(
                        fontFamily: 'ShareTechMono',
                        fontSize:   12,
                        color:      _C.textDim,
                        letterSpacing: 0.2,
                      ),
                    ),
                  ),

                  const SizedBox(height: 36),

                  OutlinedButton.icon(
                    onPressed: () =>
                        Navigator.of(context).pushNamedAndRemoveUntil('/', (_) => false),
                    icon:  const Icon(Icons.arrow_back_rounded, size: 16),
                    label: const Text('Back to Home'),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────
//  ENTRY POINT
// ─────────────────────────────────────────────
void main() {
  WidgetsFlutterBinding.ensureInitialized();

  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor:                    Colors.transparent,
    statusBarIconBrightness:           Brightness.dark,
    statusBarBrightness:               Brightness.light,
    systemNavigationBarColor:          _C.bg,
    systemNavigationBarDividerColor:   Colors.transparent,
    systemNavigationBarIconBrightness: Brightness.dark,
  ));

  SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
    DeviceOrientation.portraitDown,
  ]);

  runApp(const _OrcaApp());
}

// ─────────────────────────────────────────────
//  ROOT APP WIDGET
// ─────────────────────────────────────────────
class _OrcaApp extends StatelessWidget {
  const _OrcaApp();

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title:           'NEKOPOI8CORE',
      theme:           _AppTheme.build(),
      initialRoute:    '/',
      onGenerateRoute: _generateRoute,

      builder: (context, child) {
        final mq = MediaQuery.of(context);
        return MediaQuery(
          data: mq.copyWith(
            textScaler: TextScaler.linear(
              mq.textScaleFactor.clamp(0.85, 1.2),
            ),
          ),
          child: child ?? const SizedBox.shrink(),
        );
      },
    );
  }
}