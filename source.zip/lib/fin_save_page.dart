import 'package:flutter/material.dart';

class FinSavePage extends StatefulWidget {
  const FinSavePage({super.key});

  @override
  State<FinSavePage> createState() => _FinSavePageState();
}

class _FinSavePageState extends State<FinSavePage> {
  static const bg = Color(0xFFF7F8FC);
  static const ink = Color(0xFF202124);
  static const yellow = Color(0xFFFFC52E);
  static const blue = Color(0xFF1698E5);
  static const gray = Color(0xFFD1D2D5);

  double saldo = 2500000;
  double target = 10000000;
  final nominal = TextEditingController();

  @override
  void dispose() {
    nominal.dispose();
    super.dispose();
  }

  double _amount() => double.tryParse(nominal.text.replaceAll(',', '')) ?? 0;

  void setor() {
    final amount = _amount();
    if (amount <= 0) return;
    setState(() {
      saldo += amount;
      nominal.clear();
    });
  }

  void tarik() {
    final amount = _amount();
    if (amount <= 0 || amount > saldo) return;
    setState(() {
      saldo -= amount;
      nominal.clear();
    });
  }

  String rupiah(double value) {
    final raw = value.round().toString();
    final chars = raw.split('').reversed.toList();
    final groups = <String>[];
    for (var i = 0; i < chars.length; i += 3) {
      groups.add(chars.skip(i).take(3).toList().reversed.join());
    }
    return 'Rp ${groups.reversed.join('.')}';
  }

  @override
  Widget build(BuildContext context) {
    final progress = (saldo / target).clamp(0.0, 1.0).toDouble();
    return Scaffold(
      backgroundColor: bg,
      appBar: AppBar(
        backgroundColor: bg,
        foregroundColor: ink,
        elevation: 0,
        title: const Text('PPL NABUNG',
            style: TextStyle(fontFamily: 'Orbitron', fontWeight: FontWeight.bold)),
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(20, 8, 20, 28),
        children: [
          Container(
            padding: const EdgeInsets.all(22),
            decoration: BoxDecoration(
              color: yellow,
              border: Border.all(color: ink, width: 2.5),
              borderRadius: BorderRadius.circular(22),
              boxShadow: const [BoxShadow(color: ink, offset: Offset(0, 5))],
            ),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('TOTAL TABUNGAN',
                  style: TextStyle(fontFamily: 'ShareTechMono', fontWeight: FontWeight.bold, letterSpacing: 2)),
              const SizedBox(height: 8),
              Text(rupiah(saldo),
                  style: const TextStyle(fontFamily: 'Orbitron', fontSize: 27, fontWeight: FontWeight.bold)),
              const SizedBox(height: 18),
              ClipRRect(
                borderRadius: BorderRadius.circular(10),
                child: LinearProgressIndicator(
                  value: progress,
                  minHeight: 12,
                  backgroundColor: Colors.white,
                  color: blue,
                ),
              ),
              const SizedBox(height: 7),
              Text('${(progress * 100).toStringAsFixed(1)}% dari target',
                  style: const TextStyle(fontFamily: 'ShareTechMono')),
            ]),
          ),
          const SizedBox(height: 20),
          _card(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('NOMINAL',
                  style: TextStyle(fontFamily: 'ShareTechMono', fontWeight: FontWeight.bold)),
              const SizedBox(height: 10),
              TextField(
                controller: nominal,
                keyboardType: TextInputType.number,
                decoration: InputDecoration(
                  hintText: 'Contoh 50000',
                  filled: true,
                  fillColor: bg,
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(14),
                    borderSide: const BorderSide(color: ink, width: 2),
                  ),
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(14),
                    borderSide: const BorderSide(color: ink, width: 2),
                  ),
                ),
              ),
              const SizedBox(height: 12),
              Row(children: [
                Expanded(child: _button('SETOR', Icons.add, blue, setor)),
                const SizedBox(width: 10),
                Expanded(child: _button('TARIK', Icons.remove, yellow, tarik)),
              ]),
            ]),
          ),
          const SizedBox(height: 16),
          _card(child: ListTile(
            contentPadding: EdgeInsets.zero,
            leading: const Icon(Icons.flag, color: ink),
            title: const Text('TARGET', style: TextStyle(fontFamily: 'ShareTechMono', fontWeight: FontWeight.bold)),
            subtitle: Text(rupiah(target), style: const TextStyle(fontFamily: 'ShareTechMono')),
          )),
          const SizedBox(height: 12),
          _card(child: const ListTile(
            contentPadding: EdgeInsets.zero,
            leading: Icon(Icons.history, color: ink),
            title: Text('RIWAYAT', style: TextStyle(fontFamily: 'ShareTechMono', fontWeight: FontWeight.bold)),
            subtitle: Text('Belum ada transaksi tersimpan', style: TextStyle(fontFamily: 'ShareTechMono')),
          )),
        ],
      ),
    );
  }

  Widget _card({required Widget child}) => Container(
    padding: const EdgeInsets.all(16),
    decoration: BoxDecoration(
      color: Colors.white,
      border: Border.all(color: ink, width: 2.5),
      borderRadius: BorderRadius.circular(18),
      boxShadow: const [BoxShadow(color: ink, offset: Offset(0, 4))],
    ),
    child: child,
  );

  Widget _button(String text, IconData icon, Color color, VoidCallback tap) =>
      SizedBox(height: 52, child: ElevatedButton.icon(
        onPressed: tap,
        icon: Icon(icon, color: ink),
        label: Text(text, style: const TextStyle(fontFamily: 'ShareTechMono', fontWeight: FontWeight.bold)),
        style: ElevatedButton.styleFrom(
          backgroundColor: color,
          foregroundColor: ink,
          side: const BorderSide(color: ink, width: 2),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(13)),
          elevation: 3,
        ),
      ));
}
