import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';

class PplGamePage extends StatefulWidget {
  const PplGamePage({super.key});
  @override State<PplGamePage> createState() => _PplGamePageState();
}

class _PplGamePageState extends State<PplGamePage> {
  final _random = Random();
  Timer? _timer;
  int score = 0;
  int seconds = 30;
  bool running = false;
  double x = .5, y = .5;

  void _start() {
    _timer?.cancel();
    setState(() { score = 0; seconds = 30; running = true; _move(); });
    _timer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (!mounted) return;
      if (seconds <= 1) { _timer?.cancel(); setState(() { seconds = 0; running = false; }); }
      else setState(() => seconds--);
    });
  }
  void _move() => setState(() { x = .12 + _random.nextDouble() * .76; y = .15 + _random.nextDouble() * .70; });
  @override void dispose() { _timer?.cancel(); super.dispose(); }

  @override Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF7F8FC),
      appBar: AppBar(title: const Text('PPL GAME', style: TextStyle(fontFamily:'Orbitron', fontWeight:FontWeight.bold))),
      body: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(children: [
          Row(children: [
            Expanded(child: _stat('SCORE', '$score')),
            const SizedBox(width:10), Expanded(child: _stat('TIME', '${seconds}s')),
          ]),
          const SizedBox(height:14),
          Expanded(child: Container(
            decoration: BoxDecoration(color: Colors.white, border: Border.all(color: const Color(0xFF202124), width: 2.5), borderRadius: BorderRadius.circular(20), boxShadow: const [BoxShadow(color: Color(0xFF202124), offset: Offset(0,5))]),
            child: LayoutBuilder(builder: (_, c) => Stack(children: [
              if (running) Positioned(left: c.maxWidth*x-28, top: c.maxHeight*y-28, child: GestureDetector(onTap: () { setState(() => score++); _move(); }, child: Container(width:56,height:56,decoration:BoxDecoration(color:const Color(0xFFFFC52E),shape:BoxShape.circle,border:Border.all(color:const Color(0xFF202124),width:3)), child: const Icon(Icons.bolt, color:Color(0xFF202124), size:30)))),
              if (!running) Center(child: Column(mainAxisSize:MainAxisSize.min, children:[Text(seconds==0 ? 'WAKTU HABIS' : 'READY?', style:const TextStyle(fontFamily:'Orbitron',fontSize:22,fontWeight:FontWeight.bold)), const SizedBox(height:10), ElevatedButton(onPressed:_start, child:const Text('MULAI GAME'))]))
            ])),
          )),
          const SizedBox(height:14),
          const Text('Klik target secepat mungkin sebelum waktunya habis.', style: TextStyle(fontFamily:'ShareTechMono')),
        ]),
      ),
    );
  }
  Widget _stat(String title, String value) => Container(padding:const EdgeInsets.all(14), decoration:BoxDecoration(color:Colors.white,border:Border.all(color:const Color(0xFF202124),width:2),borderRadius:BorderRadius.circular(14)), child:Row(mainAxisAlignment:MainAxisAlignment.spaceBetween,children:[Text(title,style:const TextStyle(fontFamily:'ShareTechMono',fontWeight:FontWeight.bold)),Text(value,style:const TextStyle(fontFamily:'Orbitron',fontWeight:FontWeight.bold))]));
}
