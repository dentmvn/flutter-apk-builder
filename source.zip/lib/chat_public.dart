import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:web_socket_channel/status.dart' as status;

class ChatScreen extends StatefulWidget {
  const ChatScreen({super.key});

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final TextEditingController _messageController = TextEditingController();
  final List<Map<String, dynamic>> _messages = [];
  String _username = 'User${DateTime.now().millisecond.toString().substring(0, 3)}';
  String _sessionKey = '';
  int? _replyToIndex;
  final ScrollController _scrollController = ScrollController();

  // WebSocket
  WebSocketChannel? _channel;
  bool _isConnected = false;
  int _onlineUsers = 0;

  @override
  void initState() {
    super.initState();
    _loadUsername();
    _loadSessionKey();
    _connectWebSocket();
  }

  @override
  void dispose() {
    _channel?.sink.close(status.goingAway);
    _channel?.stream.listen(null).cancel();
    _scrollController.dispose();
    super.dispose();
  }

  // ─── LOAD SESSION KEY ──────────────────────────────────────────────────────
  Future<void> _loadSessionKey() async {
    final prefs = await SharedPreferences.getInstance();
    final key = prefs.getString('session_key') ?? '';
    setState(() => _sessionKey = key);
    if (key.isNotEmpty) {
      _connectWebSocket();
    }
  }

  // ─── WEBSOCKET ─────────────────────────────────────────────────────────────
  void _connectWebSocket() {
    try {
      _channel = WebSocketChannel.connect(
        Uri.parse('ws://arulcacat.pteroq.biz.id:10273'),
      );

      _channel!.stream.listen(
        (event) {
          try {
            final data = jsonDecode(event);
            _handleWebSocketMessage(data);
          } catch (e) {
            print('Error parsing message: $e');
          }
        },
        onDone: () {
          setState(() => _isConnected = false);
          // Reconnect after 3 seconds
          Future.delayed(const Duration(seconds: 3), () {
            if (mounted) _connectWebSocket();
          });
        },
        onError: (error) {
          setState(() => _isConnected = false);
        },
      );

      // Kirim join message
      _sendJoinMessage();
    } catch (e) {
      setState(() => _isConnected = false);
    }
  }

  void _sendJoinMessage() {
    if (_channel == null) return;
    try {
      _channel!.sink.add(jsonEncode({
        'type': 'join',
        'username': _username,
        'key': _sessionKey,
      }));
    } catch (e) {
      print('Error sending join: $e');
    }
  }

  void _handleWebSocketMessage(Map<String, dynamic> data) {
    final type = data['type'] ?? '';

    switch (type) {
      case 'chat':
        // Pesan chat dari user lain
        _addMessage(
          username: data['username'] ?? 'Unknown',
          text: data['message'] ?? '',
          time: DateTime.parse(data['time'] ?? DateTime.now().toIso8601String()),
        );
        break;

      case 'history':
        // History chat (saat join)
        final history = data['messages'] as List? ?? [];
        for (var msg in history) {
          _addMessage(
            username: msg['username'] ?? 'Unknown',
            text: msg['message'] ?? '',
            time: DateTime.parse(msg['time'] ?? DateTime.now().toIso8601String()),
            addToList: false,
          );
        }
        setState(() {});
        _scrollToBottom();
        break;

      case 'online':
        setState(() => _onlineUsers = data['count'] ?? 0);
        break;

      case 'connected':
        setState(() => _isConnected = true);
        break;

      case 'error':
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(data['message'] ?? 'Error occurred'),
            backgroundColor: Colors.red,
          ),
        );
        break;
    }
  }

  void _addMessage({
    required String username,
    required String text,
    required DateTime time,
    bool addToList = true,
  }) {
    if (addToList) {
      setState(() {
        _messages.add({
          'username': username,
          'text': text,
          'time': time,
          'replyTo': null,
        });
      });
      _scrollToBottom();
    } else {
      // Untuk history, cek duplikat
      final exists = _messages.any((msg) =>
          msg['username'] == username &&
          msg['text'] == text &&
          (msg['time'] as DateTime).difference(time).abs().inSeconds < 2);

      if (!exists) {
        _messages.add({
          'username': username,
          'text': text,
          'time': time,
          'replyTo': null,
        });
      }
    }
  }

  // ─── SEND MESSAGE ──────────────────────────────────────────────────────────
  void _sendMessage() {
    final text = _messageController.text.trim();
    if (text.isEmpty || _channel == null) return;

    // Kirim ke WebSocket
    try {
      _channel!.sink.add(jsonEncode({
        'type': 'message',
        'username': _username,
        'message': text,
        'key': _sessionKey,
      }));

      // Tambahkan ke UI lokal
      _addMessage(
        username: _username,
        text: text,
        time: DateTime.now(),
      );

      _messageController.clear();
      _replyToIndex = null;
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Gagal mengirim pesan'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  // ─── LOAD USERNAME ─────────────────────────────────────────────────────────
  Future<void> _loadUsername() async {
    final prefs = await SharedPreferences.getInstance();
    final saved = prefs.getString('chat_username');
    if (saved != null && saved.isNotEmpty) {
      setState(() => _username = saved);
    }
  }

  Future<void> _saveUsername() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('chat_username', _username);
  }

  void _scrollToBottom() {
    Future.delayed(const Duration(milliseconds: 150), () {
      if (_scrollController.hasClients) {
        _scrollController.animateTo(
          _scrollController.position.maxScrollExtent,
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeOut,
        );
      }
    });
  }

  // ─── BUILD ──────────────────────────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF0F4F8),
      appBar: _buildAppBar(),
      body: Column(
        children: [
          // Online users indicator
          _buildOnlineIndicator(),
          Expanded(
            child: _messages.isEmpty
                ? _buildEmptyState()
                : ListView.builder(
                    controller: _scrollController,
                    padding: const EdgeInsets.all(16),
                    itemCount: _messages.length,
                    itemBuilder: (context, index) {
                      final msg = _messages[index];
                      final isOwn = msg['username'] == _username;
                      return _buildMessageItem(msg, index, isOwn);
                    },
                  ),
          ),
          if (_replyToIndex != null) _buildReplyBar(),
          _buildInputBar(),
        ],
      ),
    );
  }

  // ─── ONLINE INDICATOR ──────────────────────────────────────────────────────
  Widget _buildOnlineIndicator() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
      decoration: BoxDecoration(
        color: Colors.white,
        border: Border(
          bottom: BorderSide(color: const Color(0xFFE2E8F0)),
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.02),
            blurRadius: 4,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            width: 8,
            height: 8,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: _isConnected ? const Color(0xFF34A853) : const Color(0xFFEA4335),
              boxShadow: [
                BoxShadow(
                  color: (_isConnected ? const Color(0xFF34A853) : const Color(0xFFEA4335))
                      .withOpacity(0.3),
                  blurRadius: 8,
                ),
              ],
            ),
          ),
          const SizedBox(width: 8),
          Text(
            _isConnected 
                ? '${_onlineUsers > 0 ? _onlineUsers : 0} user online' 
                : 'Connecting...',
            style: TextStyle(
              color: _isConnected ? const Color(0xFF5F6368) : const Color(0xFFEA4335),
              fontSize: 12,
              fontWeight: FontWeight.w500,
            ),
          ),
          if (_isConnected) ...[
            const SizedBox(width: 12),
            Container(
              width: 4,
              height: 4,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: const Color(0xFF9AA0A6),
              ),
            ),
            const SizedBox(width: 12),
            Text(
              'Chat Public',
              style: TextStyle(
                color: const Color(0xFF1A73E8),
                fontSize: 11,
                fontWeight: FontWeight.w600,
              ),
            ),
          ],
        ],
      ),
    );
  }

  // ─── APP BAR ────────────────────────────────────────────────────────────────
  PreferredSizeWidget _buildAppBar() {
    return AppBar(
      title: const Row(
        children: [
          Icon(Icons.public_rounded, color: Colors.white, size: 20),
          SizedBox(width: 10),
          Text(
            'PUBLIC CHAT',
            style: TextStyle(
              fontWeight: FontWeight.w700,
              fontSize: 18,
              letterSpacing: 0.5,
            ),
          ),
        ],
      ),
      backgroundColor: const Color(0xFF1A73E8),
      elevation: 0,
      centerTitle: false,
      actions: [
        Container(
          margin: const EdgeInsets.only(right: 8),
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
          decoration: BoxDecoration(
            color: Colors.white.withOpacity(0.15),
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: Colors.white.withOpacity(0.2)),
          ),
          child: Row(
            children: [
              const Icon(Icons.person_outline_rounded, color: Colors.white, size: 14),
              const SizedBox(width: 4),
              Text(
                _username.length > 12 ? '${_username.substring(0, 10)}...' : _username,
                style: const TextStyle(color: Colors.white, fontSize: 12),
              ),
            ],
          ),
        ),
        IconButton(
          icon: const Icon(Icons.edit_outlined, color: Colors.white, size: 20),
          onPressed: _showUsernameDialog,
          tooltip: 'Ubah Username',
        ),
        const SizedBox(width: 4),
      ],
      bottom: PreferredSize(
        preferredSize: const Size.fromHeight(1),
        child: Container(height: 1, color: Colors.white.withOpacity(0.1)),
      ),
    );
  }

  // ─── EMPTY STATE ────────────────────────────────────────────────────────────
  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            width: 80,
            height: 80,
            decoration: BoxDecoration(
              color: const Color(0xFF1A73E8).withOpacity(0.08),
              shape: BoxShape.circle,
              border: Border.all(
                color: const Color(0xFF1A73E8).withOpacity(0.2),
                width: 2,
              ),
              boxShadow: [
                BoxShadow(
                  color: const Color(0xFF1A73E8).withOpacity(0.1),
                  blurRadius: 30,
                  offset: const Offset(0, 8),
                ),
              ],
            ),
            child: const Icon(
              Icons.chat_bubble_outline_rounded,
              color: Color(0xFF1A73E8),
              size: 36,
            ),
          ),
          const SizedBox(height: 20),
          const Text(
            'Belum Ada Pesan',
            style: TextStyle(
              color: Color(0xFF202124),
              fontSize: 20,
              fontWeight: FontWeight.w700,
            ),
          ),
          const SizedBox(height: 8),
          const Text(
            'Mulai chat pertama kamu! 🚀',
            style: TextStyle(
              color: Color(0xFF5F6368),
              fontSize: 14,
            ),
          ),
          const SizedBox(height: 24),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            decoration: BoxDecoration(
              color: const Color(0xFF1A73E8).withOpacity(0.06),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                color: const Color(0xFF1A73E8).withOpacity(0.15),
              ),
            ),
            child: const Text(
              '💡 Double tap pesan untuk reply',
              style: TextStyle(
                color: Color(0xFF5F6368),
                fontSize: 12,
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ─── MESSAGE ITEM ──────────────────────────────────────────────────────────
  Widget _buildMessageItem(Map<String, dynamic> msg, int index, bool isOwn) {
    return GestureDetector(
      onDoubleTap: () => setState(() => _replyToIndex = index),
      child: Container(
        margin: const EdgeInsets.only(bottom: 12),
        child: Column(
          crossAxisAlignment: isOwn ? CrossAxisAlignment.end : CrossAxisAlignment.start,
          children: [
            if (msg['replyTo'] != null) ...[
              Container(
                padding: const EdgeInsets.all(10),
                margin: const EdgeInsets.only(bottom: 4),
                decoration: BoxDecoration(
                  color: const Color(0xFFF8FAFC),
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(
                    color: const Color(0xFF1A73E8).withOpacity(0.3),
                    width: 1,
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.04),
                      blurRadius: 4,
                      offset: const Offset(0, 2),
                    ),
                  ],
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Icon(
                          Icons.reply_rounded,
                          color: const Color(0xFF1A73E8).withOpacity(0.6),
                          size: 12,
                        ),
                        const SizedBox(width: 6),
                        Text(
                          'Replying to ${msg['replyTo']['username']}',
                          style: TextStyle(
                            color: const Color(0xFF1A73E8),
                            fontSize: 11,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 4),
                    Text(
                      msg['replyTo']['text'],
                      style: const TextStyle(
                        color: Color(0xFF5F6368),
                        fontSize: 13,
                      ),
                      overflow: TextOverflow.ellipsis,
                    ),
                  ],
                ),
              ),
            ],
            Container(
              padding: const EdgeInsets.symmetric(
                horizontal: 16,
                vertical: 12,
              ),
              decoration: BoxDecoration(
                color: isOwn
                    ? const Color(0xFF1A73E8)
                    : Colors.white,
                borderRadius: BorderRadius.only(
                  topLeft: const Radius.circular(16),
                  topRight: const Radius.circular(16),
                  bottomLeft: isOwn ? const Radius.circular(16) : const Radius.circular(4),
                  bottomRight: isOwn ? const Radius.circular(4) : const Radius.circular(16),
                ),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(isOwn ? 0.08 : 0.04),
                    blurRadius: 8,
                    offset: const Offset(0, 4),
                  ),
                  BoxShadow(
                    color: Colors.white.withOpacity(isOwn ? 0 : 0.6),
                    blurRadius: 4,
                    offset: const Offset(-1, -1),
                  ),
                ],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Flexible(
                        child: Text(
                          msg['username'],
                          style: TextStyle(
                            color: isOwn ? Colors.white : const Color(0xFF1A73E8),
                            fontWeight: FontWeight.bold,
                            fontSize: 13,
                          ),
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                      const SizedBox(width: 8),
                      Text(
                        DateFormat('HH:mm').format(msg['time']),
                        style: TextStyle(
                          color: isOwn ? Colors.white70 : const Color(0xFF9AA0A6),
                          fontSize: 11,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 4),
                  Text(
                    msg['text'],
                    style: TextStyle(
                      color: isOwn ? Colors.white : const Color(0xFF202124),
                      fontSize: 15,
                      height: 1.4,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ─── REPLY BAR ─────────────────────────────────────────────────────────────
  Widget _buildReplyBar() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      decoration: BoxDecoration(
        color: Colors.white,
        border: Border(
          top: BorderSide(color: const Color(0xFFE2E8F0)),
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.04),
            blurRadius: 8,
            offset: const Offset(0, -2),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            width: 3,
            height: 24,
            decoration: BoxDecoration(
              color: const Color(0xFF1A73E8),
              borderRadius: BorderRadius.circular(2),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              'Replying to: ${_messages[_replyToIndex!]['username']}',
              style: const TextStyle(
                color: Color(0xFF1A73E8),
                fontSize: 13,
                fontWeight: FontWeight.w500,
              ),
              overflow: TextOverflow.ellipsis,
            ),
          ),
          Container(
            decoration: BoxDecoration(
              color: const Color(0xFFEA4335).withOpacity(0.08),
              shape: BoxShape.circle,
            ),
            child: IconButton(
              icon: const Icon(Icons.close_rounded, color: Color(0xFFEA4335), size: 18),
              onPressed: () => setState(() => _replyToIndex = null),
              padding: EdgeInsets.zero,
              constraints: const BoxConstraints(minWidth: 32, minHeight: 32),
            ),
          ),
        ],
      ),
    );
  }

  // ─── INPUT BAR ──────────────────────────────────────────────────────────────
  Widget _buildInputBar() {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.white,
        border: Border(
          top: BorderSide(color: const Color(0xFFE2E8F0)),
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.04),
            blurRadius: 12,
            offset: const Offset(0, -4),
          ),
          BoxShadow(
            color: Colors.white.withOpacity(0.6),
            blurRadius: 8,
            offset: const Offset(-1, 0),
          ),
        ],
      ),
      child: Row(
        children: [
          Expanded(
            child: Container(
              decoration: BoxDecoration(
                color: const Color(0xFFF0F4F8),
                borderRadius: BorderRadius.circular(24),
                border: Border.all(
                  color: const Color(0xFFE2E8F0),
                ),
                boxShadow: [
                  BoxShadow(
                    color: Colors.white.withOpacity(0.6),
                    blurRadius: 4,
                    offset: const Offset(-1, -1),
                  ),
                ],
              ),
              child: TextField(
                controller: _messageController,
                style: const TextStyle(
                  color: Color(0xFF202124),
                  fontSize: 15,
                ),
                decoration: InputDecoration(
                  hintText: _replyToIndex != null ? 'Ketik balasan...' : 'Ketik pesan...',
                  hintStyle: TextStyle(
                    color: const Color(0xFF9AA0A6),
                    fontSize: 14,
                  ),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(24),
                    borderSide: BorderSide.none,
                  ),
                  contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                ),
                onSubmitted: (_) => _sendMessage(),
              ),
            ),
          ),
          const SizedBox(width: 10),
          Container(
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [Color(0xFF1A73E8), Color(0xFF4285F4)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              shape: BoxShape.circle,
              boxShadow: [
                BoxShadow(
                  color: const Color(0xFF1A73E8).withOpacity(0.3),
                  blurRadius: 16,
                  offset: const Offset(0, 4),
                ),
                BoxShadow(
                  color: Colors.white.withOpacity(0.6),
                  blurRadius: 6,
                  offset: const Offset(-2, -2),
                ),
              ],
            ),
            child: Material(
              color: Colors.transparent,
              shape: const CircleBorder(),
              child: InkWell(
                customBorder: const CircleBorder(),
                splashColor: Colors.white24,
                onTap: _sendMessage,
                child: const Padding(
                  padding: EdgeInsets.all(12),
                  child: Icon(
                    Icons.send_rounded,
                    color: Colors.white,
                    size: 20,
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ─── USERNAME DIALOG ───────────────────────────────────────────────────────
  void _showUsernameDialog() {
    final controller = TextEditingController(text: _username);
    showGeneralDialog(
      context: context,
      barrierDismissible: true,
      barrierLabel: '',
      barrierColor: Colors.black54,
      transitionDuration: const Duration(milliseconds: 300),
      transitionBuilder: (_, anim, __, child) => ScaleTransition(
        scale: CurvedAnimation(parent: anim, curve: Curves.easeOutBack),
        child: FadeTransition(opacity: anim, child: child),
      ),
      pageBuilder: (ctx, _, __) => Dialog(
        backgroundColor: Colors.transparent,
        insetPadding: const EdgeInsets.symmetric(horizontal: 28),
        child: Container(
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(24),
            border: Border.all(
              color: const Color(0xFF1A73E8).withOpacity(0.3),
              width: 1.5,
            ),
            boxShadow: [
              BoxShadow(
                color: const Color(0xFF1A73E8).withOpacity(0.15),
                blurRadius: 50,
              ),
              BoxShadow(
                color: Colors.white.withOpacity(0.6),
                blurRadius: 20,
                offset: const Offset(-2, -2),
              ),
            ],
          ),
          padding: const EdgeInsets.all(28),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 56,
                height: 56,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: const Color(0xFF1A73E8).withOpacity(0.08),
                  border: Border.all(
                    color: const Color(0xFF1A73E8).withOpacity(0.2),
                  ),
                ),
                child: const Icon(
                  Icons.person_outline_rounded,
                  color: Color(0xFF1A73E8),
                  size: 28,
                ),
              ),
              const SizedBox(height: 16),
              const Text(
                'Ubah Username',
                style: TextStyle(
                  color: Color(0xFF202124),
                  fontSize: 18,
                  fontWeight: FontWeight.w800,
                ),
              ),
              const SizedBox(height: 8),
              const Text(
                'Masukkan username baru untuk chat',
                style: TextStyle(
                  color: Color(0xFF5F6368),
                  fontSize: 13,
                ),
              ),
              const SizedBox(height: 20),
              Container(
                decoration: BoxDecoration(
                  color: const Color(0xFFF0F4F8),
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: const Color(0xFFE2E8F0)),
                ),
                child: TextField(
                  controller: controller,
                  style: const TextStyle(
                    color: Color(0xFF202124),
                    fontSize: 15,
                  ),
                  decoration: InputDecoration(
                    hintText: 'Username',
                    hintStyle: TextStyle(color: const Color(0xFF9AA0A6)),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(14),
                      borderSide: BorderSide.none,
                    ),
                    contentPadding: const EdgeInsets.symmetric(
                      horizontal: 16,
                      vertical: 14,
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 24),
              Row(
                children: [
                  Expanded(
                    child: _DialogOutlineBtn(
                      label: 'Batal',
                      onTap: () => Navigator.pop(ctx),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: _DialogGradBtn(
                      label: 'Simpan',
                      onTap: () {
                        if (controller.text.trim().isNotEmpty) {
                          final newUsername = controller.text.trim();
                          setState(() {
                            _username = newUsername;
                            _saveUsername();
                          });
                          // Kirim update username ke WebSocket
                          if (_channel != null) {
                            try {
                              _channel!.sink.add(jsonEncode({
                                'type': 'update_username',
                                'old_username': _username,
                                'new_username': newUsername,
                                'key': _sessionKey,
                              }));
                            } catch (e) {
                              print('Error updating username: $e');
                            }
                          }
                          Navigator.pop(ctx);
                        }
                      },
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ─── DIALOG GRADIENT BUTTON ──────────────────────────────────────────────────
class _DialogGradBtn extends StatefulWidget {
  final String label;
  final VoidCallback onTap;

  const _DialogGradBtn({
    required this.label,
    required this.onTap,
  });

  @override
  State<_DialogGradBtn> createState() => _DialogGradBtnState();
}

class _DialogGradBtnState extends State<_DialogGradBtn> {
  bool _down = false;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => setState(() => _down = true),
      onTapUp: (_) { setState(() => _down = false); widget.onTap(); },
      onTapCancel: () => setState(() => _down = false),
      child: AnimatedScale(
        scale: _down ? 0.96 : 1.0,
        duration: const Duration(milliseconds: 120),
        child: Container(
          height: 46,
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              colors: [Color(0xFF1A73E8), Color(0xFF4285F4)],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            borderRadius: BorderRadius.circular(13),
            boxShadow: _down ? [] : [
              BoxShadow(
                color: const Color(0xFF1A73E8).withOpacity(0.3),
                blurRadius: 14,
                offset: const Offset(0, 4),
              ),
              BoxShadow(
                color: Colors.white.withOpacity(0.6),
                blurRadius: 6,
                offset: const Offset(-2, -2),
              ),
            ],
          ),
          child: Center(
            child: Text(
              widget.label,
              style: const TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.w700,
                fontSize: 14,
              ),
            ),
          ),
        ),
      ),
    );
  }
}

// ─── DIALOG OUTLINE BUTTON ──────────────────────────────────────────────────
class _DialogOutlineBtn extends StatefulWidget {
  final String label;
  final VoidCallback onTap;

  const _DialogOutlineBtn({
    required this.label,
    required this.onTap,
  });

  @override
  State<_DialogOutlineBtn> createState() => _DialogOutlineBtnState();
}

class _DialogOutlineBtnState extends State<_DialogOutlineBtn> {
  bool _down = false;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => setState(() => _down = true),
      onTapUp: (_) { setState(() => _down = false); widget.onTap(); },
      onTapCancel: () => setState(() => _down = false),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 120),
        height: 46,
        decoration: BoxDecoration(
          color: _down ? const Color(0xFFE2E8F0).withOpacity(0.5) : Colors.transparent,
          borderRadius: BorderRadius.circular(13),
          border: Border.all(color: const Color(0xFFE2E8F0)),
        ),
        child: Center(
          child: Text(
            widget.label,
            style: const TextStyle(
              color: Color(0xFF5F6368),
              fontWeight: FontWeight.w600,
              fontSize: 14,
            ),
          ),
        ),
      ),
    );
  }
}