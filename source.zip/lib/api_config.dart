/// Centralized API configuration for the PPL Project base.
class ApiConfig {
  static const String baseUrl = 'http://alfa-store-officials.alfamarket2.my.id:4785';

  static Uri endpoint(String path, [Map<String, String>? query]) {
    final normalized = path.startsWith('/') ? path : '/$path';
    return Uri.parse('$baseUrl$normalized').replace(queryParameters: query);
  }
}
