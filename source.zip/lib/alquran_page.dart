import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class AlQuranPage extends StatefulWidget {
  const AlQuranPage({super.key});
  @override
  State<AlQuranPage> createState() => _AlQuranPageState();
}

class _AlQuranPageState extends State<AlQuranPage> {
  static const bg = Color(0xFFF7F8FC), ink = Color(0xFF202124), yellow = Color(0xFFFFC52E), blue = Color(0xFF1698E5);
  List<dynamic> surahs = [];
  bool loading = true;
  String? error;

  @override
  void initState() { super.initState(); _load(); }

  Future<void> _load() async {
    try {
      final r = await http.get(Uri.parse('https://api.quran.gading.dev/surah'));
      if (r.statusCode != 200) throw Exception('HTTP ${r.statusCode}');
      final data = jsonDecode(r.body);
      setState(() {
        surahs = data is Map && data['data'] is List ? data['data'] as List : [];
        loading = false;
      });
    } catch (e) {
      setState(() { loading = false; error = 'Gagal memuat daftar surah'; });
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    backgroundColor: bg,
    appBar: AppBar(
      backgroundColor: bg, foregroundColor: ink, elevation: 0,
      title: const Text('PPL AL-QURAN', style: TextStyle(fontFamily: 'Orbitron', fontWeight: FontWeight.bold)),
      actions: [IconButton(onPressed: _load, icon: const Icon(Icons.refresh))],
    ),
    body: loading
      ? const Center(child: CircularProgressIndicator(color: blue))
      : error != null
        ? Center(child: Text(error!, style: const TextStyle(fontFamily: 'ShareTechMono')))
        : ListView.separated(
            padding: const EdgeInsets.fromLTRB(18, 8, 18, 24),
            itemCount: surahs.length,
            separatorBuilder: (_, __) => const SizedBox(height: 10),
            itemBuilder: (_, i) {
              final s = Map<String,dynamic>.from(surahs[i] as Map);
              final name = s['name']?.toString() ?? '-';
              final translit = s['name']?['transliteration']?['id']?.toString() ?? s['englishName']?.toString() ?? '';
              final number = s['number']?.toString() ?? '${i+1}';
              return InkWell(
                borderRadius: BorderRadius.circular(16),
                onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => _SurahPage(number: int.tryParse(number) ?? i+1, title: translit.isEmpty ? name : translit))),
                child: Container(
                  padding: const EdgeInsets.all(15),
                  decoration: BoxDecoration(color: Colors.white, border: Border.all(color: ink, width: 2), borderRadius: BorderRadius.circular(16), boxShadow: const [BoxShadow(color: ink, offset: Offset(0,3))]),
                  child: Row(children: [
                    Container(width: 42, height: 42, alignment: Alignment.center, decoration: BoxDecoration(color: yellow, border: Border.all(color: ink, width: 2), borderRadius: BorderRadius.circular(10)), child: Text(number, style: const TextStyle(fontFamily: 'ShareTechMono', fontWeight: FontWeight.bold))),
                    const SizedBox(width: 12),
                    Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text(translit.isEmpty ? name : translit, style: const TextStyle(fontFamily: 'ShareTechMono', fontWeight: FontWeight.bold, fontSize: 16)),
                      Text(name, style: const TextStyle(fontSize: 16)),
                    ])),
                    const Icon(Icons.chevron_right),
                  ]),
                ),
              );
            }),
  );
}

class _SurahPage extends StatefulWidget {
  final int number; final String title;
  const _SurahPage({required this.number, required this.title});
  @override State<_SurahPage> createState() => _SurahPageState();
}
class _SurahPageState extends State<_SurahPage> {
  Map<String,dynamic>? data; String? error;
  @override void initState(){super.initState(); _load();}
  Future<void> _load() async {
    try {
      final r=await http.get(Uri.parse('https://api.quran.gading.dev/surah/${widget.number}'));
      if(r.statusCode!=200) throw Exception();
      final j=jsonDecode(r.body);
      setState(()=>data=j is Map && j['data'] is Map ? Map<String,dynamic>.from(j['data']) : null);
    } catch(_){setState(()=>error='Gagal memuat surah.');}
  }
  @override Widget build(BuildContext context)=>Scaffold(
    backgroundColor: const Color(0xFFF7F8FC),
    appBar: AppBar(backgroundColor: const Color(0xFFF7F8FC),foregroundColor: const Color(0xFF202124),elevation:0,title:Text(widget.title,style:const TextStyle(fontFamily:'Orbitron',fontWeight:FontWeight.bold))),
    body: error!=null ? Center(child:Text(error!,style:const TextStyle(fontFamily:'ShareTechMono'))) :
      data==null ? const Center(child:CircularProgressIndicator(color:Color(0xFF1698E5))) :
      ListView.builder(
        padding: const EdgeInsets.all(18),
        itemCount: (data!['verses'] as List?)?.length ?? 0,
        itemBuilder: (_,i){
          final v=Map<String,dynamic>.from((data!['verses'] as List)[i] as Map);
          final text=v['text'] is Map ? Map<String,dynamic>.from(v['text']) : {};
          final translation=text['translation'] is Map ? Map<String,dynamic>.from(text['translation']) : {};
          final arab=text['arab']?.toString() ?? '';
          final transliteration=text['transliteration'] is Map ? Map<String,dynamic>.from(text['transliteration']) : {};
          final latin=(transliteration['en'] ?? transliteration['id'] ?? text['latin'] ?? '').toString();
          final indo=translation['id']?.toString() ?? '';
          return Container(
            margin: const EdgeInsets.only(bottom: 12), padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(color:Colors.white,border:Border.all(color:const Color(0xFF202124),width:2),borderRadius:BorderRadius.circular(16),boxShadow:const[BoxShadow(color:Color(0xFF202124),offset:Offset(0,3))]),
            child: Column(crossAxisAlignment:CrossAxisAlignment.end,children:[
              Text(arab,textAlign:TextAlign.right,style:const TextStyle(fontSize:25,height:1.8)),
              if (latin.isNotEmpty) ...[
                const SizedBox(height:10),
                Align(alignment:Alignment.centerLeft,child:Text(latin,style:const TextStyle(fontFamily:'ShareTechMono',fontStyle:FontStyle.italic,height:1.5))),
              ],
              const SizedBox(height:10),
              Align(alignment:Alignment.centerLeft,child:Text(indo,style:const TextStyle(fontFamily:'ShareTechMono',height:1.5))),
              const SizedBox(height:7),
              Align(alignment:Alignment.centerLeft,child:Text('${i+1}',style:const TextStyle(fontFamily:'ShareTechMono',fontWeight:FontWeight.bold,color:Color(0xFF1698E5)))),
            ]),
          );
        }),
  );
}
