import 'dart:convert';
import 'dart:io';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:video_player/video_player.dart';
import 'api_config.dart';

class PplgramPage extends StatefulWidget {
  final String sessionKey;
  const PplgramPage({super.key, required this.sessionKey});

  @override
  State<PplgramPage> createState() => _PplgramPageState();
}

class _PplgramPageState extends State<PplgramPage> {
  static const _yellow = Color(0xFFFFC52E);
  static const _blue = Color(0xFF1698E5);
  static const _ink = Color(0xFF202124);
  static const _bg = Color(0xFFF7F8FC);

  List<Map<String, dynamic>> _stories = [];
  bool _loading = true;
  bool _posting = false;

  @override
  void initState() {
    super.initState();
    _loadStories();
  }

  bool _isStory(Map<String, dynamic> message) {
    final text = message['message']?.toString() ?? '';
    return text.startsWith('PPLGRAM_STORY:');
  }

  Map<String, dynamic>? _decodeStory(Map<String, dynamic> message) {
    final raw = message['message']?.toString() ?? '';
    if (!_isStory(message)) return null;
    try {
      final data = jsonDecode(raw.substring('PPLGRAM_STORY:'.length));
      if (data is! Map) return null;
      final story = Map<String, dynamic>.from(data);
      story['username'] = message['username']?.toString() ?? 'user';
      story['role'] = message['role']?.toString() ?? 'member';
      story['createdAt'] = message['createdAt']?.toString() ?? '';
      story['id'] = message['id']?.toString() ?? '';
      return story;
    } catch (_) {
      return null;
    }
  }

  Future<void> _loadStories() async {
    if (mounted) setState(() => _loading = true);
    try {
      final r = await http.get(
        ApiConfig.endpoint('/api/global-chat/messages', {'key': widget.sessionKey}),
      ).timeout(const Duration(seconds: 12));

      if (r.statusCode != 200) {
        throw Exception('HTTP ${r.statusCode}');
      }

      final data = jsonDecode(r.body);
      if (data['valid'] != true) {
        throw Exception(data['message']?.toString() ?? 'Gagal memuat PPLgram');
      }

      final now = DateTime.now().toUtc();
      final list = <Map<String, dynamic>>[];

      for (final item in (data['messages'] as List? ?? const [])) {
        if (item is! Map) continue;
        final story = _decodeStory(Map<String, dynamic>.from(item));
        if (story == null) continue;

        final expires = DateTime.tryParse(story['expiresAt']?.toString() ?? '');
        if (expires != null && expires.isBefore(now)) continue;

        list.add(story);
      }

      list.sort((a, b) {
        final aa = DateTime.tryParse(a['createdAt']?.toString() ?? '') ??
            DateTime.fromMillisecondsSinceEpoch(0, isUtc: true);
        final bb = DateTime.tryParse(b['createdAt']?.toString() ?? '') ??
            DateTime.fromMillisecondsSinceEpoch(0, isUtc: true);
        return bb.compareTo(aa);
      });

      if (mounted) setState(() {
        _stories = list;
        _loading = false;
      });
    } catch (e) {
      if (mounted) {
        setState(() => _loading = false);
        _snack('PPLgram gagal dimuat: ${e.toString().replaceFirst('Exception: ', '')}', true);
      }
    }
  }

  Future<String> _uploadToCatbox(File file) async {
    final request = http.MultipartRequest(
      'POST',
      Uri.parse('https://catbox.moe/user/api.php'),
    );
    request.fields['reqtype'] = 'fileupload';
    request.files.add(await http.MultipartFile.fromPath('fileToUpload', file.path));

    final response = await request.send().timeout(const Duration(minutes: 2));
    final body = await response.stream.bytesToString();
    if (response.statusCode != 200 || !body.startsWith('http')) {
      throw Exception('Upload Catbox gagal');
    }
    return body.trim();
  }

  Future<void> _createTextStory() async {
    final controller = TextEditingController();
    final text = await showDialog<String>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('BUAT STORY TEKS'),
        content: TextField(
          controller: controller,
          maxLength: 240,
          maxLines: 5,
          autofocus: true,
          decoration: const InputDecoration(
            hintText: 'Tulis sesuatu untuk semua user...',
            border: OutlineInputBorder(),
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('BATAL')),
          ElevatedButton(
            onPressed: () => Navigator.pop(context, controller.text.trim()),
            child: const Text('POST'),
          ),
        ],
      ),
    );
    controller.dispose();

    if (text == null || text.isEmpty) return;
    await _postStory({'kind': 'text', 'text': text});
  }

  Future<void> _createMediaStory() async {
    final result = await FilePicker.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['jpg', 'jpeg', 'png', 'webp', 'mp4', 'mov', 'm4v'],
    );
    if (result == null || result.files.single.path == null) return;

    final file = File(result.files.single.path!);
    final ext = (result.files.single.extension ?? '').toLowerCase();
    final isVideo = ['mp4', 'mov', 'm4v'].contains(ext);

    final captionController = TextEditingController();
    final caption = await showDialog<String>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(isVideo ? 'STORY VIDEO' : 'STORY FOTO'),
        content: TextField(
          controller: captionController,
          maxLength: 160,
          maxLines: 3,
          decoration: const InputDecoration(
            hintText: 'Caption (opsional)',
            border: OutlineInputBorder(),
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('LEWATI')),
          ElevatedButton(
            onPressed: () => Navigator.pop(context, captionController.text.trim()),
            child: const Text('UPLOAD'),
          ),
        ],
      ),
    );
    captionController.dispose();

    if (caption == null) return;

    if (mounted) setState(() => _posting = true);
    try {
      final url = await _uploadToCatbox(file);
      await _postStory({
        'kind': isVideo ? 'video' : 'image',
        'url': url,
        'caption': caption,
      }, keepPostingState: true);
    } catch (e) {
      if (mounted) _snack('Gagal membuat story: $e', true);
    } finally {
      if (mounted) setState(() => _posting = false);
    }
  }

  Future<void> _postStory(
    Map<String, dynamic> story, {
    bool keepPostingState = false,
  }) async {
    if (!keepPostingState && mounted) setState(() => _posting = true);

    try {
      final now = DateTime.now().toUtc();
      story['version'] = 1;
      story['createdAt'] = now.toIso8601String();
      story['expiresAt'] = now.add(const Duration(hours: 24)).toIso8601String();

      // Story sengaja disimpan sebagai pesan khusus di Global Chat API.
      // Tidak membutuhkan endpoint/database baru di API.
      final encoded = 'PPLGRAM_STORY:${jsonEncode(story)}';

      if (encoded.length > 500) {
        throw Exception('Story terlalu panjang untuk penyimpanan Global Chat');
      }

      final r = await http.post(
        ApiConfig.endpoint('/api/global-chat/messages', {'key': widget.sessionKey}),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'message': encoded}),
      ).timeout(const Duration(seconds: 12));

      final data = jsonDecode(r.body);
      if (r.statusCode != 200 || data['valid'] != true) {
        throw Exception(data['message']?.toString() ?? 'Gagal menyimpan story');
      }

      if (mounted) _snack('Story berhasil diposting selama 24 jam', false);
      await _loadStories();
    } catch (e) {
      if (mounted) _snack('Gagal posting story: $e', true);
    } finally {
      if (!keepPostingState && mounted) setState(() => _posting = false);
    }
  }

  void _snack(String text, bool bad) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(text),
        backgroundColor: bad ? Colors.red : _blue,
      ),
    );
  }

  void _showStory(Map<String, dynamic> story) {
    final kind = story['kind']?.toString() ?? 'text';
    showDialog(
      context: context,
      barrierColor: Colors.black.withOpacity(.92),
      builder: (_) => _StoryViewer(story: story),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _bg,
      appBar: AppBar(
        backgroundColor: _bg,
        foregroundColor: _ink,
        elevation: 0,
        title: const Text(
          'PPLGRAM',
          style: TextStyle(
            fontFamily: 'Orbitron',
            fontWeight: FontWeight.bold,
            letterSpacing: 1.4,
          ),
        ),
        actions: [
          IconButton(
            onPressed: _loading || _posting ? null : _loadStories,
            icon: const Icon(Icons.refresh),
          ),
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : RefreshIndicator(
              onRefresh: _loadStories,
              child: ListView(
                padding: const EdgeInsets.fromLTRB(16, 4, 16, 30),
                children: [
                  _headerCard(),
                  const SizedBox(height: 16),
                  _createCard(),
                  const SizedBox(height: 18),
                  Row(
                    children: [
                      const Expanded(
                        child: Text(
                          'STORY TERBARU',
                          style: TextStyle(
                            fontFamily: 'Orbitron',
                            fontWeight: FontWeight.bold,
                            letterSpacing: 1,
                          ),
                        ),
                      ),
                      Text(
                        '${_stories.length} story',
                        style: const TextStyle(fontFamily: 'ShareTechMono'),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  if (_stories.isEmpty)
                    _emptyState()
                  else
                    ..._stories.map(
                      (story) => Padding(
                        padding: const EdgeInsets.only(bottom: 14),
                        child: _storyCard(story),
                      ),
                    ),
                ],
              ),
            ),
    );
  }

  Widget _headerCard() => Container(
        padding: const EdgeInsets.all(18),
        decoration: BoxDecoration(
          color: _blue,
          borderRadius: BorderRadius.circular(22),
          border: Border.all(color: _ink, width: 2.5),
          boxShadow: const [BoxShadow(color: _ink, offset: Offset(0, 5))],
        ),
        child: const Row(
          children: [
            Icon(Icons.auto_stories_rounded, color: Colors.white, size: 38),
            SizedBox(width: 13),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'PPLGRAM',
                    style: TextStyle(
                      color: Colors.white,
                      fontFamily: 'Orbitron',
                      fontWeight: FontWeight.bold,
                      fontSize: 18,
                    ),
                  ),
                  SizedBox(height: 5),
                  Text(
                    'Bagikan foto, video, atau teks. Semua user PPL bisa melihatnya.',
                    style: TextStyle(
                      color: Colors.white,
                      fontFamily: 'ShareTechMono',
                      fontSize: 11,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      );

  Widget _createCard() => Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: _ink, width: 2),
          boxShadow: const [BoxShadow(color: _ink, offset: Offset(0, 3))],
        ),
        child: Row(
          children: [
            Expanded(
              child: _createButton(
                Icons.photo_library_rounded,
                'FOTO / VIDEO',
                _createMediaStory,
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: _createButton(
                Icons.edit_note_rounded,
                'TEKS',
                _createTextStory,
              ),
            ),
          ],
        ),
      );

  Widget _createButton(IconData icon, String label, VoidCallback onTap) =>
      ElevatedButton.icon(
        onPressed: _posting ? null : onTap,
        icon: Icon(icon, size: 19),
        label: Text(label, style: const TextStyle(fontSize: 11)),
        style: ElevatedButton.styleFrom(
          backgroundColor: _yellow,
          foregroundColor: _ink,
          padding: const EdgeInsets.symmetric(vertical: 15, horizontal: 8),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
        ),
      );

  Widget _emptyState() => Container(
        padding: const EdgeInsets.symmetric(vertical: 45, horizontal: 20),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: _ink, width: 1.5),
        ),
        child: const Column(
          children: [
            Icon(Icons.auto_stories_outlined, size: 48, color: _blue),
            SizedBox(height: 10),
            Text(
              'Belum ada story',
              style: TextStyle(fontFamily: 'Orbitron', fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 5),
            Text(
              'Jadilah orang pertama yang posting.',
              textAlign: TextAlign.center,
              style: TextStyle(fontFamily: 'ShareTechMono'),
            ),
          ],
        ),
      );

  Widget _storyCard(Map<String, dynamic> story) {
    final username = story['username']?.toString() ?? 'user';
    final kind = story['kind']?.toString() ?? 'text';
    final caption = story['caption']?.toString() ?? '';
    final created = DateTime.tryParse(story['createdAt']?.toString() ?? '')?.toLocal();
    final time = created == null
        ? ''
        : '${created.hour.toString().padLeft(2, '0')}:${created.minute.toString().padLeft(2, '0')}';

    return GestureDetector(
      onTap: () => _showStory(story),
      child: Container(
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: _ink, width: 2),
          boxShadow: const [BoxShadow(color: _ink, offset: Offset(0, 3))],
        ),
        clipBehavior: Clip.antiAlias,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            ListTile(
              dense: true,
              leading: CircleAvatar(
                backgroundColor: _blue,
                child: Text(
                  username.isEmpty ? '?' : username[0].toUpperCase(),
                  style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                ),
              ),
              title: Text(
                username,
                style: const TextStyle(fontFamily: 'ShareTechMono', fontWeight: FontWeight.bold),
              ),
              subtitle: Text(
                'PPLgram • $time',
                style: const TextStyle(fontFamily: 'ShareTechMono', fontSize: 10),
              ),
              trailing: Icon(
                kind == 'video'
                    ? Icons.play_circle_fill_rounded
                    : kind == 'image'
                        ? Icons.image_rounded
                        : Icons.text_fields_rounded,
                color: _blue,
              ),
            ),
            if (kind == 'image' && story['url'] != null)
              Image.network(
                story['url'].toString(),
                width: double.infinity,
                height: 280,
                fit: BoxFit.cover,
                errorBuilder: (_, __, ___) => _mediaError(),
              )
            else if (kind == 'video')
              Container(
                height: 180,
                color: Colors.black,
                child: const Center(
                  child: Icon(Icons.play_circle_fill_rounded, color: Colors.white, size: 60),
                ),
              )
            else
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(24),
                color: const Color(0xFFFFF6CF),
                child: Text(
                  story['text']?.toString() ?? '',
                  style: const TextStyle(
                    fontFamily: 'ShareTechMono',
                    fontSize: 18,
                    height: 1.4,
                  ),
                ),
              ),
            if (caption.isNotEmpty)
              Padding(
                padding: const EdgeInsets.fromLTRB(15, 10, 15, 15),
                child: Text(
                  caption,
                  style: const TextStyle(fontFamily: 'ShareTechMono'),
                ),
              ),
          ],
        ),
      ),
    );
  }

  Widget _mediaError() => Container(
        height: 180,
        color: const Color(0xFFE9EDF2),
        alignment: Alignment.center,
        child: const Text('Media tidak dapat dimuat'),
      );
}

class _StoryViewer extends StatefulWidget {
  final Map<String, dynamic> story;
  const _StoryViewer({required this.story});

  @override
  State<_StoryViewer> createState() => _StoryViewerState();
}

class _StoryViewerState extends State<_StoryViewer> {
  VideoPlayerController? _video;
  bool _videoReady = false;

  @override
  void initState() {
    super.initState();
    if (widget.story['kind']?.toString() == 'video' && widget.story['url'] != null) {
      _video = VideoPlayerController.networkUrl(Uri.parse(widget.story['url'].toString()))
        ..initialize().then((_) {
          if (!mounted) return;
          setState(() => _videoReady = true);
          _video!.setLooping(true);
          _video!.play();
        }).catchError((_) {});
    }
  }

  @override
  void dispose() {
    _video?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final kind = widget.story['kind']?.toString() ?? 'text';
    final caption = widget.story['caption']?.toString() ?? '';

    return Dialog(
      backgroundColor: Colors.transparent,
      insetPadding: const EdgeInsets.all(12),
      child: Stack(
        children: [
          Container(
            constraints: const BoxConstraints(maxHeight: 700),
            decoration: BoxDecoration(
              color: Colors.black,
              borderRadius: BorderRadius.circular(22),
              border: Border.all(color: const Color(0xFFFFC52E), width: 2),
            ),
            clipBehavior: Clip.antiAlias,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                if (kind == 'image')
                  InteractiveViewer(
                    child: Image.network(
                      widget.story['url'].toString(),
                      fit: BoxFit.contain,
                    ),
                  )
                else if (kind == 'video')
                  _videoReady
                      ? AspectRatio(
                          aspectRatio: _video!.value.aspectRatio,
                          child: VideoPlayer(_video!),
                        )
                      : const Padding(
                          padding: EdgeInsets.all(80),
                          child: CircularProgressIndicator(color: Colors.white),
                        )
                else
                  Padding(
                    padding: const EdgeInsets.all(30),
                    child: Text(
                      widget.story['text']?.toString() ?? '',
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 22,
                        height: 1.4,
                        fontFamily: 'ShareTechMono',
                      ),
                    ),
                  ),
                if (caption.isNotEmpty)
                  Padding(
                    padding: const EdgeInsets.fromLTRB(18, 10, 18, 18),
                    child: Text(
                      caption,
                      style: const TextStyle(color: Colors.white70, fontFamily: 'ShareTechMono'),
                    ),
                  ),
              ],
            ),
          ),
          Positioned(
            right: 8,
            top: 8,
            child: IconButton(
              onPressed: () => Navigator.pop(context),
              icon: const Icon(Icons.close_rounded, color: Colors.white, size: 30),
            ),
          ),
        ],
      ),
    );
  }
}
