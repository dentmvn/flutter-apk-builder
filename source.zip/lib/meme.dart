import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class MemeGeneratorPage extends StatefulWidget {
  // CONSTRUCTOR CONST
  const MemeGeneratorPage({super.key});

  @override
  State<MemeGeneratorPage> createState() => _MemeGeneratorPageState();
}

class _MemeGeneratorPageState extends State<MemeGeneratorPage> {
  String? _imageUrl;
  bool _isLoading = false;

  Future<void> fetchMeme() async {
    setState(() {
      _isLoading = true;
      _imageUrl = null;
    });
    try {
      final response = await http.get(
        Uri.parse('https://meme-api.com/gimme'),
        headers: const {'User-Agent': 'PPL-Project/1.0'},
      );
      if (response.statusCode != 200) {
        throw Exception('Server Error: ${response.statusCode}');
      }
      final data = json.decode(response.body) as Map<String, dynamic>;
      final url = data['url']?.toString();
      if (url == null || url.isEmpty) throw Exception('URL meme tidak tersedia');
      if (!mounted) return;
      setState(() {
        _imageUrl = url;
        _isLoading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() => _isLoading = false);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error: $e'), backgroundColor: const Color(0xFFFFC52E)),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF7F8FC),
      appBar: AppBar(
        title: const Text("PPL MEME GENERATOR", style: TextStyle(fontFamily: "Orbitron", fontWeight: FontWeight.bold)),
        backgroundColor: const Color(0xFFF7F8FC),
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            ElevatedButton(
              onPressed: _isLoading ? null : fetchMeme,
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFFFFC52E),
                foregroundColor: const Color(0xFF202124),
                minimumSize: const Size(double.infinity, 55),
              ),
              child: Text(_isLoading ? "LOADING..." : "BUAT MEME"),
            ),
            const SizedBox(height: 20),
            Expanded(
              child: Container(
                width: double.infinity,
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(15),
                  border: Border.all(color: const Color(0xFF202124), width: 2.5),
                ),
                child: Center(
                  child: _isLoading
                      ? const CircularProgressIndicator(color: const Color(0xFF1698E5))
                      : _imageUrl != null
                          ? Image.network(
                              _imageUrl!,
                              // Tambahin header di Image.network juga biar aman!
                              headers: const {
                                'User-Agent': 'Mozilla/5.0',
                              },
                              errorBuilder: (context, error, stackTrace) =>
                                  const Text("Gambar gagal tampil"),
                            )
                          : const Text("Tekan tombol untuk mengambil meme"),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}