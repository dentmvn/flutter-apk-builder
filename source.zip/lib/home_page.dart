import 'dart:convert';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:video_player/video_player.dart';
import 'package:chewie/chewie.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'sender_global.dart';

const _baseUrl = 'https://recommends-parameter-seating-maine.trycloudflare.com';

// ─── TEMA WARNA ──────────────────────────────────────────────────────────────
class _C {
  static const bg        = Color(0xFF0A1628);
  static const bgCard    = Color(0xFF1A2A4A);
  static const surface   = Color(0xFFFFFFFF);
  static const card      = Color(0xFF1E2D5A);
  static const border    = Color(0xFF2A3F7A);
  static const borderLit = Color(0xFF3A5F9A);

  static const blue        = Color(0xFF1A73E8);
  static const blueMid     = Color(0xFF4285F4);
  static const blueLight   = Color(0xFF8AB4F8);
  static const blueFrost   = Color(0xFFC2D8F8);
  static const blueDark    = Color(0xFF1557B0);

  static const green     = Color(0xFF34A853);
  static const greenDim  = Color(0xFF2D8F47);
  static const amber     = Color(0xFFFBBC04);
  static const red       = Color(0xFFEA4335);

  static const text      = Color(0xFFFFFFFF);
  static const textSub   = Color(0xFFB0B8C8);
  static const textDim   = Color(0xFF6A7A9A);
  static const white     = Color(0xFFFFFFFF);

  static const LinearGradient btnGrad = LinearGradient(
    colors: [Color(0xFF1A73E8), Color(0xFF4285F4)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );
  
  static const LinearGradient btnGradRed = LinearGradient(
    colors: [Color(0xFFD93025), Color(0xFFEA4335)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );
  
  static const LinearGradient btnGradGreen = LinearGradient(
    colors: [Color(0xFF34A853), Color(0xFF2D8F47)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );
  
  static const LinearGradient bgGrad = LinearGradient(
    colors: [Color(0xFF0A1628), Color(0xFF1A3A5C)],
    begin: Alignment.topCenter,
    end: Alignment.bottomCenter,
  );
}

Color _roleColor(String role) {
  switch (role.toLowerCase()) {
    case 'owner':    return const Color(0xFF1A73E8);
    case 'admin':    return const Color(0xFFEA4335);
    case 'moderator': return const Color(0xFF34A853);
    case 'partner':  return const Color(0xFF1A73E8);
    case 'vip':      return const Color(0xFF1A73E8);
    case 'reseller': return const Color(0xFF34A853);
    default:         return _C.blue;
  }
}

class HomePage extends StatefulWidget {
  final String username;
  final String password;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final String role;
  final String expiredDate;

  const HomePage({
    super.key,
    required this.username,
    required this.password,
    required this.sessionKey,
    required this.listBug,
    required this.role,
    required this.expiredDate,
  });

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> with TickerProviderStateMixin {
  final targetCtrl = TextEditingController();

  String selectedBugId = '';
  String _bugMode      = 'number';
  String _senderType   = 'private';
  bool   _isSending    = false;
  String? _responseMsg;

  List<String> _globalSenders   = [];
  bool         _isLoadingSenders = false;

  // ─── COUNTDOWN STATE ──────────────────────────────────────────────────────
  bool _showCountdown = false;
  int _countdownValue = 5;
  bool _countdownComplete = false;
  bool _showSuccessDialog = false;
  String _successMessage = '';

  late AnimationController _bgCtrl;
  late AnimationController _entranceCtrl;
  late AnimationController _sendBtnCtrl;
  late AnimationController _resultCtrl;
  late AnimationController _waveCtrl;
  late AnimationController _countdownCtrl;
  late AnimationController _spinCtrl;

  late Animation<double> _entrance;
  late Animation<double> _sendPulse;
  late Animation<double> _sendGlow;
  late Animation<double> _resultFade;
  late Animation<Offset>  _resultSlide;
  late Animation<double>  _countdownScale;
  late Animation<double>  _countdownFade;
  late Animation<double>  _spinAngle;

  late VideoPlayerController _videoCtrl;
  ChewieController? _chewieCtrl;
  bool _videoReady = false;

  bool get canAccessGlobalSender {
    return true;
  }

  bool get _isOwner => widget.role.toLowerCase() == 'owner';

  // ─── GET FILTERED BUGS ────────────────────────────────────────────────────
  List<Map<String, dynamic>> get _filteredBugs {
    if (_bugMode == 'number') {
      return widget.listBug;
    } else {
      final groupBugs = widget.listBug.where((bug) {
        final id = bug['bug_id']?.toString().toUpperCase() ?? '';
        final name = bug['bug_name']?.toString().toUpperCase() ?? '';
        return id == 'FREZZ' || 
               id == 'FREZZGB' || 
               id == 'GROUP' ||
               name.contains('FREZZ') ||
               name.contains('BANNED') ||
               name.contains('GROUP');
      }).toList();
      
      final hasFREZZ = groupBugs.any((b) => 
        b['bug_id']?.toString().toUpperCase() == 'FREZZ' ||
        b['bug_name']?.toString().toUpperCase() == 'FREZZ GROUP'
      );
      
      if (!hasFREZZ) {
        groupBugs.insert(0, {
          'bug_id': 'FREZZ',
          'bug_name': 'FREZZ GROUP',
        });
      }
      
      return groupBugs.isNotEmpty ? groupBugs : widget.listBug;
    }
  }

  @override
  void initState() {
    super.initState();
    
    if (widget.listBug.isNotEmpty) {
      final filtered = _filteredBugs;
      if (filtered.isNotEmpty) {
        selectedBugId = filtered[0]['bug_id'];
      } else {
        selectedBugId = widget.listBug[0]['bug_id'];
      }
    }

    _bgCtrl = AnimationController(vsync: this, duration: const Duration(seconds: 16))..repeat();

    _entranceCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 900));
    _entrance = CurvedAnimation(parent: _entranceCtrl, curve: Curves.easeOutCubic);

    _sendBtnCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 1800))
      ..repeat(reverse: true);
    _sendPulse = Tween<double>(begin: 1.0, end: 1.05)
        .animate(CurvedAnimation(parent: _sendBtnCtrl, curve: Curves.easeInOut));
    _sendGlow = Tween<double>(begin: 0.25, end: 0.65)
        .animate(CurvedAnimation(parent: _sendBtnCtrl, curve: Curves.easeInOut));

    _resultCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 450));
    _resultFade  = CurvedAnimation(parent: _resultCtrl, curve: Curves.easeOut);
    _resultSlide = Tween<Offset>(begin: const Offset(0, 0.12), end: Offset.zero)
        .animate(CurvedAnimation(parent: _resultCtrl, curve: Curves.easeOutCubic));

    _waveCtrl = AnimationController(vsync: this, duration: const Duration(seconds: 3))..repeat();

    // ─── COUNTDOWN ANIMATIONS ──────────────────────────────────────────────
    _countdownCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 300));
    _countdownScale = Tween<double>(begin: 0.5, end: 1.2)
        .animate(CurvedAnimation(parent: _countdownCtrl, curve: Curves.elasticOut));
    _countdownFade = Tween<double>(begin: 0, end: 1)
        .animate(CurvedAnimation(parent: _countdownCtrl, curve: Curves.easeOut));

    _spinCtrl = AnimationController(vsync: this, duration: const Duration(seconds: 1))..repeat();
    _spinAngle = Tween<double>(begin: 0, end: 2 * math.pi)
        .animate(CurvedAnimation(parent: _spinCtrl, curve: Curves.linear));

    _entranceCtrl.forward();
    _initVideo();
    _loadGlobalSenders();
  }

  @override
  void dispose() {
    _bgCtrl.dispose();
    _entranceCtrl.dispose();
    _sendBtnCtrl.dispose();
    _resultCtrl.dispose();
    _waveCtrl.dispose();
    _countdownCtrl.dispose();
    _spinCtrl.dispose();
    targetCtrl.dispose();
    _videoCtrl.dispose();
    _chewieCtrl?.dispose();
    super.dispose();
  }

  void _initVideo() {
    _videoCtrl = VideoPlayerController.asset('assets/videos/banner.mp4');
    _videoCtrl.initialize().then((_) {
      if (!mounted) return;
      _videoCtrl.setVolume(0);
      setState(() {
        _chewieCtrl = ChewieController(
          videoPlayerController: _videoCtrl,
          autoPlay: true,
          looping: true,
          showControls: false,
        );
        _videoReady = true;
      });
    });
  }

  Future<void> _loadGlobalSenders() async {
    setState(() => _isLoadingSenders = true);
    try {
      final res = await http.get(Uri.parse(
        'https://recommends-parameter-seating-maine.trycloudflare.com/getActiveSenders?key=${widget.sessionKey}',
      )).timeout(const Duration(seconds: 10));

      final data = jsonDecode(res.body);
      if (data['valid'] == true && data['senders'] != null) {
        if (mounted) setState(() => _globalSenders = List<String>.from(data['senders']));
      } else {
        if (mounted) setState(() => _globalSenders = []);
      }
    } catch (_) {
      if (mounted) setState(() => _globalSenders = []);
    } finally {
      if (mounted) setState(() => _isLoadingSenders = false);
    }
  }

  Future<void> _sendBug() async {
    final rawInput = targetCtrl.text.trim();
    final key      = widget.sessionKey;

    if (_bugMode == 'number') {
      if (formatPhone(rawInput) == null) {
        _showAlert('Nomor Tidak Valid', 'Gunakan format internasional.\nContoh: +62812xxxxxxxx');
        return;
      }
    } else {
      if (!isValidGroupLink(rawInput)) {
        _showAlert('Link Tidak Valid',
            'Masukkan link grup WhatsApp yang valid.\nContoh: https://chat.whatsapp.com/XXX');
        return;
      }
    }

    if (_senderType == 'global' && !canAccessGlobalSender) {
      _showAlert('Akses Ditolak', 'Sender Global hanya untuk Owner, Admin, Moderator, Partner & VIP!');
      return;
    }

    if (selectedBugId.isEmpty) {
      _showAlert('Pilih Bug', 'Silakan pilih bug terlebih dahulu.');
      return;
    }

    // ─── TAMPILKAN DIALOG KONFIRMASI ──────────────────────────────────────
    _showConfirmDialog();
  }

  // ─── DIALOG KONFIRMASI ──────────────────────────────────────────────────
  void _showConfirmDialog() {
    showGeneralDialog(
      context: context,
      barrierDismissible: false,
      barrierLabel: '',
      barrierColor: Colors.black54,
      transitionDuration: const Duration(milliseconds: 350),
      transitionBuilder: (_, anim, __, child) => ScaleTransition(
        scale: CurvedAnimation(parent: anim, curve: Curves.easeOutBack),
        child: FadeTransition(opacity: anim, child: child),
      ),
      pageBuilder: (ctx, _, __) => Dialog(
        backgroundColor: Colors.transparent,
        insetPadding: const EdgeInsets.symmetric(horizontal: 24),
        child: Container(
          decoration: BoxDecoration(
            color: _C.surface,
            borderRadius: BorderRadius.circular(28),
            border: Border.all(color: _C.red.withOpacity(0.3), width: 1.5),
            boxShadow: [
              BoxShadow(color: Colors.black.withOpacity(0.15), blurRadius: 50),
              BoxShadow(color: Colors.white.withOpacity(0.6), blurRadius: 20, offset: const Offset(-2, -2)),
            ],
          ),
          padding: const EdgeInsets.all(28),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 72,
                height: 72,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: _C.btnGradRed,
                  boxShadow: [
                    BoxShadow(
                      color: _C.red.withOpacity(0.4),
                      blurRadius: 24,
                      offset: const Offset(0, 6),
                    ),
                  ],
                ),
                child: const Icon(Icons.warning_rounded, color: Colors.white, size: 34),
              ),
              const SizedBox(height: 18),
              const Text(
                '⚠️ PERINGATAN ⚠️',
                style: TextStyle(
                  color: _C.red,
                  fontSize: 18,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 1,
                ),
              ),
              const SizedBox(height: 12),
              const Text(
                'Apakah anda siap bertanggung jawab\napabila yang lu bug kenapa-kenapa?',
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: _C.text,
                  fontSize: 16,
                  fontWeight: FontWeight.w600,
                  height: 1.5,
                ),
              ),
              const SizedBox(height: 8),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                decoration: BoxDecoration(
                  color: _C.amber.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: _C.amber.withOpacity(0.3)),
                ),
                child: const Text(
                  'Hanya untuk tujuan edukasi!',
                  style: TextStyle(
                    color: _C.amber,
                    fontSize: 11,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
              const SizedBox(height: 24),
              Row(
                children: [
                  Expanded(
                    child: GestureDetector(
                      onTap: () => Navigator.pop(ctx),
                      child: Container(
                        height: 50,
                        decoration: BoxDecoration(
                          color: _C.bg,
                          borderRadius: BorderRadius.circular(14),
                          border: Border.all(color: _C.border),
                        ),
                        child: const Center(
                          child: Text(
                            'BATAL',
                            style: TextStyle(
                              color: _C.textSub,
                              fontWeight: FontWeight.w700,
                              fontSize: 14,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: GestureDetector(
                      onTap: () {
                        Navigator.pop(ctx);
                        _showCountdownDialog();
                      },
                      child: Container(
                        height: 50,
                        decoration: BoxDecoration(
                          gradient: _C.btnGradRed,
                          borderRadius: BorderRadius.circular(14),
                          boxShadow: [
                            BoxShadow(
                              color: _C.red.withOpacity(0.3),
                              blurRadius: 16,
                              offset: const Offset(0, 4),
                            ),
                          ],
                        ),
                        child: const Center(
                          child: Text(
                            'OKE',
                            style: TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.w800,
                              fontSize: 14,
                              letterSpacing: 1,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ─── COUNTDOWN DIALOG ──────────────────────────────────────────────────
  void _showCountdownDialog() {
    setState(() {
      _showCountdown = true;
      _countdownValue = 5;
      _countdownComplete = false;
      _showSuccessDialog = false;
    });

    showGeneralDialog(
      context: context,
      barrierDismissible: false,
      barrierLabel: '',
      barrierColor: Colors.black54,
      transitionDuration: const Duration(milliseconds: 400),
      transitionBuilder: (_, anim, __, child) => ScaleTransition(
        scale: CurvedAnimation(parent: anim, curve: Curves.easeOutBack),
        child: FadeTransition(opacity: anim, child: child),
      ),
      pageBuilder: (ctx, _, __) => StatefulBuilder(
        builder: (context, setStateDialog) {
          int countdown = 5;
          bool isComplete = false;

          Future<void> startCountdown() async {
            while (countdown > 0) {
              await Future.delayed(const Duration(seconds: 1));
              countdown--;
              setStateDialog(() {});
              if (countdown == 0) {
                isComplete = true;
                setStateDialog(() {});
                _executeSendBug();
                await Future.delayed(const Duration(milliseconds: 500));
                if (mounted) {
                  Navigator.pop(ctx);
                  _showSuccessDialogFunc();
                }
              }
            }
          }

          WidgetsBinding.instance.addPostFrameCallback((_) {
            startCountdown();
          });

          return Dialog(
            backgroundColor: Colors.transparent,
            insetPadding: const EdgeInsets.symmetric(horizontal: 24),
            child: Container(
              decoration: BoxDecoration(
                color: _C.surface,
                borderRadius: BorderRadius.circular(28),
                border: Border.all(color: _C.blue.withOpacity(0.3), width: 1.5),
                boxShadow: [
                  BoxShadow(color: Colors.black.withOpacity(0.15), blurRadius: 50),
                  BoxShadow(color: Colors.white.withOpacity(0.6), blurRadius: 20, offset: const Offset(-2, -2)),
                ],
              ),
              padding: const EdgeInsets.all(32),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  AnimatedBuilder(
                    animation: _spinCtrl,
                    builder: (_, __) => Transform.rotate(
                      angle: _spinAngle.value,
                      child: Container(
                        width: 120,
                        height: 120,
                        decoration: BoxDecoration(
                          gradient: _C.btnGrad,
                          shape: BoxShape.circle,
                          boxShadow: [
                            BoxShadow(
                              color: _C.blue.withOpacity(0.4),
                              blurRadius: 30,
                              offset: const Offset(0, 8),
                            ),
                          ],
                        ),
                        child: Center(
                          child: Text(
                            isComplete ? '✓' : '$countdown',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: isComplete ? 60 : 48,
                              fontWeight: FontWeight.w900,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 20),
                  Text(
                    isComplete ? 'MENGIRIM...' : 'PROSES',
                    style: const TextStyle(
                      color: _C.blue,
                      fontSize: 18,
                      fontWeight: FontWeight.w800,
                      letterSpacing: 2,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    isComplete ? 'Bug sedang dikirim...' : 'Tunggu sebentar...',
                    style: TextStyle(
                      color: _C.textSub,
                      fontSize: 13,
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  // ─── SUCCESS DIALOG ──────────────────────────────────────────────────
  void _showSuccessDialogFunc() {
    showGeneralDialog(
      context: context,
      barrierDismissible: true,
      barrierLabel: '',
      barrierColor: Colors.black54,
      transitionDuration: const Duration(milliseconds: 400),
      transitionBuilder: (_, anim, __, child) => ScaleTransition(
        scale: CurvedAnimation(parent: anim, curve: Curves.easeOutBack),
        child: FadeTransition(opacity: anim, child: child),
      ),
      pageBuilder: (ctx, _, __) => Dialog(
        backgroundColor: Colors.transparent,
        insetPadding: const EdgeInsets.symmetric(horizontal: 24),
        child: Container(
          decoration: BoxDecoration(
            color: _C.surface,
            borderRadius: BorderRadius.circular(28),
            border: Border.all(color: _C.green.withOpacity(0.3), width: 1.5),
            boxShadow: [
              BoxShadow(color: Colors.black.withOpacity(0.15), blurRadius: 50),
              BoxShadow(color: Colors.white.withOpacity(0.6), blurRadius: 20, offset: const Offset(-2, -2)),
            ],
          ),
          padding: const EdgeInsets.all(28),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 72,
                height: 72,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: _C.btnGradGreen,
                  boxShadow: [
                    BoxShadow(
                      color: _C.green.withOpacity(0.4),
                      blurRadius: 24,
                      offset: const Offset(0, 6),
                    ),
                  ],
                ),
                child: const Icon(Icons.check_rounded, color: Colors.white, size: 40),
              ),
              const SizedBox(height: 18),
              const Text(
                '✅ BERHASIL',
                style: TextStyle(
                  color: _C.green,
                  fontSize: 20,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 1,
                ),
              ),
              const SizedBox(height: 12),
              Text(
                'Bug berhasil dikirim!',
                style: TextStyle(
                  color: _C.textSub,
                  fontSize: 15,
                ),
              ),
              const SizedBox(height: 24),
              GestureDetector(
                onTap: () => Navigator.pop(ctx),
                child: Container(
                  height: 50,
                  width: double.infinity,
                  decoration: BoxDecoration(
                    gradient: _C.btnGrad,
                    borderRadius: BorderRadius.circular(14),
                    boxShadow: [
                      BoxShadow(
                        color: _C.blue.withOpacity(0.3),
                        blurRadius: 16,
                        offset: const Offset(0, 4),
                      ),
                    ],
                  ),
                  child: const Center(
                    child: Text(
                      'OK',
                      style: TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.w800,
                        fontSize: 15,
                        letterSpacing: 1,
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _executeSendBug() async {
    // Eksekusi send bug di sini
    setState(() => _isSending = true);
    await Future.delayed(const Duration(seconds: 1));
    setState(() => _isSending = false);
  }

  void _showAlert(String title, String message) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(title),
        content: Text(message),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('OK'),
          ),
        ],
      ),
    );
  }

  // ─── BUILD ────────────────────────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Container(
        decoration: BoxDecoration(
          gradient: _C.bgGrad,
        ),
        child: Stack(
          children: [
            // Background particles
            ...List.generate(30, (index) {
              return Positioned(
                left: (index * 23) % MediaQuery.of(context).size.width,
                top: (index * 31) % MediaQuery.of(context).size.height,
                child: Container(
                  width: 2 + (index % 4),
                  height: 2 + (index % 4),
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: Colors.white.withOpacity(0.05 + (index % 3) * 0.02),
                  ),
                ),
              );
            }),
            
            SafeArea(
              child: SingleChildScrollView(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // ─── HEADER ──────────────────────────────────────────────
                    Row(
                      children: [
                        Container(
                          width: 50,
                          height: 50,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            border: Border.all(color: _C.blue, width: 2),
                            boxShadow: [
                              BoxShadow(
                                color: _C.blue.withOpacity(0.3),
                                blurRadius: 20,
                              ),
                            ],
                          ),
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(25),
                            child: Image.asset(
                              'assets/images/logo.png',
                              fit: BoxFit.cover,
                              errorBuilder: (_, __, ___) => Icon(
                                Icons.account_circle,
                                color: _C.blue,
                                size: 40,
                              ),
                            ),
                          ),
                        ),
                        const SizedBox(width: 12),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              '#IPL PROJECT',
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 20,
                                fontWeight: FontWeight.w900,
                                letterSpacing: 1,
                              ),
                            ),
                            Row(
                              children: [
                                Container(
                                  width: 8,
                                  height: 8,
                                  decoration: BoxDecoration(
                                    shape: BoxShape.circle,
                                    color: _roleColor(widget.role),
                                  ),
                                ),
                                const SizedBox(width: 6),
                                Text(
                                  widget.role.toUpperCase(),
                                  style: TextStyle(
                                    color: _roleColor(widget.role),
                                    fontSize: 11,
                                    fontWeight: FontWeight.w700,
                                  ),
                                ),
                                const SizedBox(width: 12),
                                Icon(
                                  Icons.schedule,
                                  color: Colors.white54,
                                  size: 12,
                                ),
                                const SizedBox(width: 4),
                                Text(
                                  widget.expiredDate,
                                  style: TextStyle(
                                    color: Colors.white54,
                                    fontSize: 10,
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                        const Spacer(),
                        IconButton(
                          onPressed: () {},
                          icon: Icon(
                            Icons.more_vert,
                            color: Colors.white70,
                          ),
                        ),
                      ],
                    ),
                    
                    const SizedBox(height: 16),
                    
                    // ─── BUG NOMOR / SENDER ──────────────────────────────────
                    Row(
                      children: [
                        Expanded(
                          child: _buildDropdownCard(
                            label: 'Bug Nomor',
                            value: _bugMode,
                            items: const [
                              DropdownMenuItem(value: 'number', child: Text('Number')),
                              DropdownMenuItem(value: 'group', child: Text('Group')),
                            ],
                            onChanged: (v) {
                              setState(() {
                                _bugMode = v!;
                                final filtered = _filteredBugs;
                                if (filtered.isNotEmpty) {
                                  selectedBugId = filtered[0]['bug_id'];
                                }
                              });
                            },
                          ),
                        ),
                        const SizedBox(width: 8),
                        Expanded(
                          child: _buildDropdownCard(
                            label: 'Sender',
                            value: _senderType,
                            items: [
                              const DropdownMenuItem(value: 'private', child: Text('Private')),
                              const DropdownMenuItem(value: 'global', child: Text('Global')),
                            ],
                            onChanged: (v) {
                              setState(() => _senderType = v!);
                            },
                          ),
                        ),
                      ],
                    ),
                    
                    const SizedBox(height: 16),
                    
                    // ─── TARGET NUMBER ──────────────────────────────────────
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
                      decoration: BoxDecoration(
                        color: _C.bgCard,
                        borderRadius: BorderRadius.circular(14),
                        border: Border.all(color: _C.border),
                      ),
                      child: Row(
                        children: [
                          const Text(
                            'Target Number',
                            style: TextStyle(
                              color: _C.textSub,
                              fontSize: 13,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                          const Spacer(),
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                            decoration: BoxDecoration(
                              color: _C.blue.withOpacity(0.2),
                              borderRadius: BorderRadius.circular(6),
                            ),
                            child: Row(
                              children: [
                                const Text(
                                  '+62',
                                  style: TextStyle(
                                    color: _C.blueLight,
                                    fontSize: 12,
                                    fontWeight: FontWeight.w700,
                                  ),
                                ),
                                const SizedBox(width: 2),
                                Icon(
                                  Icons.arrow_drop_down,
                                  color: _C.blueLight,
                                  size: 16,
                                ),
                              ],
                            ),
                          ),
                          const SizedBox(width: 8),
                          Expanded(
                            child: TextField(
                              controller: targetCtrl,
                              style: const TextStyle(
                                color: Colors.white,
                                fontSize: 14,
                              ),
                              decoration: const InputDecoration(
                                hintText: 'e.g. 8xxx...',
                                hintStyle: TextStyle(
                                  color: _C.textDim,
                                  fontSize: 13,
                                ),
                                border: InputBorder.none,
                                isDense: true,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    
                    const SizedBox(height: 16),
                    
                    // ─── SELECT PAYLOAD BUG ──────────────────────────────────
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 12),
                      decoration: BoxDecoration(
                        color: _C.bgCard,
                        borderRadius: BorderRadius.circular(14),
                        border: Border.all(color: _C.border),
                      ),
                      child: DropdownButtonHideUnderline(
                        child: DropdownButton<String>(
                          value: selectedBugId.isEmpty ? null : selectedBugId,
                          hint: Text(
                            'Select Payload Bug',
                            style: TextStyle(
                              color: _C.textDim,
                              fontSize: 13,
                            ),
                          ),
                          dropdownColor: _C.bgCard,
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 14,
                            fontWeight: FontWeight.w600,
                          ),
                          items: _filteredBugs.map((bug) {
                            final id = bug['bug_id']?.toString() ?? '';
                            final name = bug['bug_name']?.toString() ?? id;
                            return DropdownMenuItem<String>(
                              value: id,
                              child: Row(
                                children: [
                                  Container(
                                    width: 6,
                                    height: 6,
                                    decoration: BoxDecoration(
                                      shape: BoxShape.circle,
                                      color: _C.blue,
                                    ),
                                  ),
                                  const SizedBox(width: 10),
                                  Text(
                                    name.length > 20 ? '${name.substring(0, 20)}...' : name,
                                    style: const TextStyle(
                                      color: Colors.white,
                                      fontSize: 13,
                                    ),
                                  ),
                                ],
                              ),
                            );
                          }).toList(),
                          onChanged: (v) => setState(() => selectedBugId = v!),
                          icon: Icon(
                            Icons.arrow_drop_down,
                            color: _C.blueLight,
                          ),
                        ),
                      ),
                    ),
                    
                    const SizedBox(height: 16),
                    
                    // ─── SEND BUG BUTTON ────────────────────────────────────
                    GestureDetector(
                      onTap: _sendBug,
                      child: Container(
                        height: 52,
                        width: double.infinity,
                        decoration: BoxDecoration(
                          gradient: _C.btnGrad,
                          borderRadius: BorderRadius.circular(14),
                          boxShadow: [
                            BoxShadow(
                              color: _C.blue.withOpacity(0.4),
                              blurRadius: 20,
                              offset: const Offset(0, 6),
                            ),
                          ],
                        ),
                        child: const Center(
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(
                                Icons.send_rounded,
                                color: Colors.white,
                                size: 20,
                              ),
                              SizedBox(width: 10),
                              Text(
                                'SEND BUG',
                                style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 16,
                                  fontWeight: FontWeight.w800,
                                  letterSpacing: 2,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                    
                    const SizedBox(height: 24),
                    
                    // ─── BOTTOM NAVIGATION ──────────────────────────────────
                    Container(
                      padding: const EdgeInsets.symmetric(vertical: 8),
                      decoration: BoxDecoration(
                        color: _C.bgCard.withOpacity(0.8),
                        borderRadius: BorderRadius.circular(16),
                        border: Border.all(color: _C.border.withOpacity(0.3)),
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceAround,
                        children: [
                          _buildNavItem(Icons.home_rounded, 'Home', true),
                          _buildNavItem(FontAwesomeIcons.whatsapp, 'WhatsApp', false),
                          _buildNavItem(Icons.security_rounded, 'RAT', false),
                          _buildNavItem(Icons.flash_on_rounded, 'DDoS', false),
                          _buildNavItem(Icons.build_rounded, 'Tools', false),
                        ],
                      ),
                    ),
                    
                    const SizedBox(height: 16),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildDropdownCard({
    required String label,
    required String value,
    required List<DropdownMenuItem<String>> items,
    required void Function(String?) onChanged,
  }) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 2),
      decoration: BoxDecoration(
        color: _C.bgCard,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: _C.border),
      ),
      child: DropdownButtonHideUnderline(
        child: DropdownButton<String>(
          value: value,
          items: items,
          onChanged: onChanged,
          dropdownColor: _C.bgCard,
          style: const TextStyle(
            color: Colors.white,
            fontSize: 13,
            fontWeight: FontWeight.w600,
          ),
          icon: Icon(
            Icons.arrow_drop_down,
            color: _C.blueLight,
          ),
        ),
      ),
    );
  }

  Widget _buildNavItem(IconData icon, String label, bool isActive) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Icon(
          icon,
          color: isActive ? _C.blue : _C.textDim,
          size: 22,
        ),
        const SizedBox(height: 2),
        Text(
          label,
          style: TextStyle(
            color: isActive ? _C.blue : _C.textDim,
            fontSize: 10,
            fontWeight: isActive ? FontWeight.w700 : FontWeight.w500,
          ),
        ),
        if (isActive)
          Container(
            width: 20,
            height: 2,
            decoration: BoxDecoration(
              gradient: _C.btnGrad,
              borderRadius: BorderRadius.circular(2),
            ),
          ),
      ],
    );
  }
}