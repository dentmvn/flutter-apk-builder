import 'dart:async';
import 'dart:convert';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:file_picker/file_picker.dart';
import 'package:url_launcher/url_launcher.dart';
import 'api_config.dart';

class BuildApkPage extends StatefulWidget {
  final String sessionKey;
  const BuildApkPage({super.key, required this.sessionKey});

  @override
  State<BuildApkPage> createState() => _BuildApkPageState();
}

class _BuildApkPageState extends State<BuildApkPage> {
  final String serverUrl = ApiConfig.baseUrl;

  bool _isLoading = false;
  String _currentStatus = "READY";
  double _progressValue = 0.0;
  final List<String> _logs = ["System Initialized... Waiting for project ZIP."];
  String? _jobId;
  Timer? _timer;

  // Variabel untuk menampung link download
  String? _downloadUrl;

  final Color nexusRed = const Color(0xFFFF5252);
  final Color nexusCard = const Color(0xFF121212);

  void _addLog(String msg) {
    if (!mounted) return;
    setState(() {
      _logs.add(
        "[${DateTime.now().toString().split(' ')[1].split('.')[0]}] $msg",
      );
    });
  }

  // === LOGIKA BUILD ===

  Future<void> _startProcess() async {
    try {
      FilePickerResult? result = await FilePicker.pickFiles(
        type: FileType.custom,
        allowedExtensions: ['zip'],
      );

      if (result == null) return;

      setState(() {
        _isLoading = true;
        _progressValue = 0.1;
        _currentStatus = "UPLOADING";
        _downloadUrl = null;
        _logs.clear();
      });

      _addLog("📦 File selected: ${result.files.single.name}");
      _addLog("📤 Uploading to Nexus Proxy...");

      var request = http.MultipartRequest(
        'POST',
        Uri.parse('$serverUrl/api/nexus/upload-build'),
      );
      request.fields['key'] = widget.sessionKey;
      request.files.add(
        await http.MultipartFile.fromPath('file', result.files.single.path!),
      );

      var streamedResponse = await request.send().timeout(
        const Duration(minutes: 5),
      );
      var response = await http.Response.fromStream(streamedResponse);

      if (response.statusCode != 200) {
        throw "Server Error: ${response.statusCode}";
      }

      var data = jsonDecode(response.body);

      if (data['success'] == true) {
        _jobId = data['job_id'].toString();
        _addLog("✅ Upload Success! Job ID: $_jobId");
        _addLog("🚀 Cloud Build Engine Started...");
        _startPolling();
      } else {
        _addLog("❌ Error: ${data['message']}");
        setState(() => _isLoading = false);
      }
    } catch (e) {
      _addLog("❌ Process Error: $e");
      setState(() {
        _isLoading = false;
        _currentStatus = "ERROR";
      });
    }
  }

  void _startPolling() {
    _timer?.cancel();
    _timer = Timer.periodic(const Duration(seconds: 5), (timer) async {
      try {
        final res = await http
            .get(Uri.parse('$serverUrl/api/nexus/build-status/$_jobId'))
            .timeout(const Duration(seconds: 10));

        if (res.statusCode != 200) return;

        final data = jsonDecode(res.body);
        String status = (data['status'] ?? 'unknown').toString().toUpperCase();

        _addLog("🛰️ Cloud Engine Status: $status");

        if (status == "RUNNING" ||
            status == "PROCESSING" ||
            status == "QUEUED") {
          setState(() {
            _currentStatus = "BUILDING";
            if (_progressValue < 0.9) _progressValue += 0.05;
          });
        }
        // FIXED: Memperluas deteksi status sukses
        else if (status == "COMPLETED" ||
            status == "SUCCESS" ||
            status == "FINISHED") {
          timer.cancel();
          setState(() {
            _currentStatus = "FINISHED";
            _progressValue = 1.0;
          });

          _addLog("🎊 Build Finished! Checking Link...");

          // Jika backend sudah menyertakan link di status, langsung pakai
          if (data['download_url'] != null &&
              data['download_url'].toString().isNotEmpty) {
            _updateDownloadReady(data['download_url'].toString());
          } else {
            // Jika belum ada, panggil endpoint artifact
            _fetchDownloadLink();
          }
        } else if (status == "FAILED" || status == "ERROR") {
          timer.cancel();
          _addLog("❌ Build Failed on Cloud Engine.");
          setState(() {
            _isLoading = false;
            _currentStatus = "FAILED";
          });
        }
      } catch (e) {
        _addLog("⚠️ Connection lost, retrying...");
      }
    });
  }

  Future<void> _fetchDownloadLink() async {
    try {
      _addLog("🔗 Requesting artifact link...");
      final res = await http
          .get(Uri.parse('$serverUrl/api/nexus/build-artifact/$_jobId'))
          .timeout(const Duration(seconds: 15));

      final data = jsonDecode(res.body);
      String? link = data['url']?.toString();

      if (link != null && link.isNotEmpty) {
        _updateDownloadReady(link);
      } else {
        _addLog("⚠️ Link not found. Please try again later.");
        setState(() => _isLoading = false);
      }
    } catch (e) {
      _addLog("❌ Failed to fetch link: $e");
      setState(() => _isLoading = false);
    }
  }

  void _updateDownloadReady(String url) {
    if (!mounted) return;
    setState(() {
      _downloadUrl = url;
      _isLoading = false;
    });
    _addLog("📥 Link Captured: Ready to Download");
    _showFinishDialog(url);
  }

  void _showFinishDialog(String url) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        backgroundColor: const Color(0xFF1A1A1A),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
          side: BorderSide(color: nexusRed),
        ),
        title: Text(
          "BUILD SUCCESS",
          style: TextStyle(color: nexusRed, fontWeight: FontWeight.bold),
        ),
        content: const Text(
          "Your Nexus Evolution APK is ready for deployment.",
          style: TextStyle(color: Colors.white70),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text("CLOSE", style: TextStyle(color: Colors.grey)),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: nexusRed),
            onPressed: () async {
              final uri = Uri.parse(url);
              if (await canLaunchUrl(uri)) {
                await launchUrl(uri, mode: LaunchMode.externalApplication);
              }
            },
            child: const Text(
              "DOWNLOAD APK",
              style: TextStyle(
                color: Colors.black,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        title: const Text(
          "PPL CLOUD BUILD",
          style: TextStyle(
            letterSpacing: 2,
            fontSize: 14,
            fontWeight: FontWeight.bold,
          ),
        ),
        backgroundColor: Colors.black,
        elevation: 0,
        centerTitle: true,
      ),
      body: Column(
        children: [
          const SizedBox(height: 10),

          if (_isLoading)
            Container(
              margin: const EdgeInsets.symmetric(horizontal: 20),
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: nexusRed.withOpacity(0.1),
                borderRadius: BorderRadius.circular(10),
              ),
              child: Row(
                children: [
                  Icon(Icons.warning_amber_rounded, color: nexusRed, size: 20),
                  const SizedBox(width: 10),
                  const Expanded(
                    child: Text(
                      "PENTING: Jangan menutup aplikasi agar proses build tidak terhenti.",
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 10,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ],
              ),
            ),

          const SizedBox(height: 15),

          // PANEL STATUS
          Container(
            margin: const EdgeInsets.symmetric(horizontal: 20),
            padding: const EdgeInsets.all(25),
            decoration: BoxDecoration(
              color: nexusCard,
              borderRadius: BorderRadius.circular(25),
              border: Border.all(
                color: _downloadUrl != null
                    ? Colors.greenAccent.withOpacity(0.5)
                    : nexusRed.withOpacity(0.2),
              ),
            ),
            child: Column(
              children: [
                Stack(
                  alignment: Alignment.center,
                  children: [
                    SizedBox(
                      width: 110,
                      height: 110,
                      child: CircularProgressIndicator(
                        value: _progressValue,
                        strokeWidth: 8,
                        backgroundColor: Colors.white10,
                        color: _downloadUrl != null
                            ? Colors.greenAccent
                            : (_currentStatus == "FAILED"
                                  ? Colors.orange
                                  : nexusRed),
                      ),
                    ),
                    Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(
                          "${(_progressValue * 100).toInt()}%",
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        Text(
                          _currentStatus,
                          style: TextStyle(
                            color: _downloadUrl != null
                                ? Colors.greenAccent
                                : nexusRed.withOpacity(0.7),
                            fontSize: 9,
                            letterSpacing: 1.2,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
                const SizedBox(height: 25),

                GestureDetector(
                  onTap: () async {
                    if (_downloadUrl != null) {
                      final uri = Uri.parse(_downloadUrl!);
                      if (await canLaunchUrl(uri)) {
                        await launchUrl(
                          uri,
                          mode: LaunchMode.externalApplication,
                        );
                      }
                    } else if (!_isLoading) {
                      _startProcess();
                    }
                  },
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 300),
                    width: double.infinity,
                    height: 50,
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: _downloadUrl != null
                            ? [Colors.green.shade900, Colors.greenAccent]
                            : _isLoading
                            ? [Colors.grey.shade800, Colors.grey.shade700]
                            : [const Color(0xFF8B0000), nexusRed],
                      ),
                      borderRadius: BorderRadius.circular(15),
                      boxShadow: _downloadUrl != null
                          ? [
                              BoxShadow(
                                color: Colors.greenAccent.withOpacity(0.2),
                                blurRadius: 10,
                              ),
                            ]
                          : [],
                    ),
                    child: Center(
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(
                            _downloadUrl != null
                                ? Icons.download_for_offline
                                : _isLoading
                                ? Icons.sync
                                : Icons.cloud_upload,
                            color: Colors.white,
                            size: 20,
                          ),
                          const SizedBox(width: 10),
                          Text(
                            _downloadUrl != null
                                ? "DOWNLOAD APK NOW"
                                : _isLoading
                                ? "BUILDING..."
                                : "UPLOAD PROJECT ZIP",
                            style: const TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.bold,
                              fontSize: 13,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),

          // LOGS Area
          Expanded(
            child: Container(
              width: double.infinity,
              margin: const EdgeInsets.fromLTRB(20, 20, 20, 20),
              decoration: BoxDecoration(
                color: const Color(0xFF050505),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: Colors.white10),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 15,
                      vertical: 8,
                    ),
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.05),
                      borderRadius: const BorderRadius.only(
                        topLeft: Radius.circular(20),
                        topRight: Radius.circular(20),
                      ),
                    ),
                    child: const Row(
                      children: [
                        Icon(
                          Icons.terminal,
                          color: Colors.greenAccent,
                          size: 14,
                        ),
                        SizedBox(width: 10),
                        Text(
                          "SYSTEM_V3_LOGS",
                          style: TextStyle(
                            color: Colors.grey,
                            fontSize: 10,
                            fontFamily: 'monospace',
                          ),
                        ),
                      ],
                    ),
                  ),
                  Expanded(
                    child: ListView.builder(
                      padding: const EdgeInsets.all(15),
                      itemCount: _logs.length,
                      itemBuilder: (context, index) {
                        return Padding(
                          padding: const EdgeInsets.only(bottom: 4),
                          child: Text(
                            ">> ${_logs[index]}",
                            style: const TextStyle(
                              color: Colors.greenAccent,
                              fontFamily: 'monospace',
                              fontSize: 11,
                            ),
                          ),
                        );
                      },
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
