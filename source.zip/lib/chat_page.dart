import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'api_config.dart';

class ChatPage extends StatefulWidget {
  final String sessionKey;
  const ChatPage({super.key, required this.sessionKey});
  @override State<ChatPage> createState() => _ChatPageState();
}

class _ChatPageState extends State<ChatPage> {
  final TextEditingController messageController = TextEditingController();
  final ScrollController _scrollController = ScrollController();
  Timer? _pollTimer;
  List<Map<String,dynamic>> messages = [];
  bool loading = true;
  bool sending = false;
  String? error;

  @override void initState() { super.initState(); _loadMessages(); _pollTimer=Timer.periodic(const Duration(seconds:3), (_) => _loadMessages(silent:true)); }

  Future<void> _loadMessages({bool silent=false}) async {
    if (!silent) setState(() { loading=true; error=null; });
    try {
      final uri=ApiConfig.endpoint('/api/global-chat/messages', {'key':widget.sessionKey});
      final r=await http.get(uri).timeout(const Duration(seconds:10));
      final data=jsonDecode(r.body);
      if(r.statusCode==200 && data['valid']==true) {
        final incoming=(data['messages'] as List? ?? [])
            .map((e)=>Map<String,dynamic>.from(e as Map))
            .where((m) => !(m['message']?.toString() ?? '').startsWith('PPLGRAM_STORY:'))
            .toList();
        if(mounted) setState(() { messages=incoming; loading=false; });
        _scrollToBottom();
      } else if(mounted && !silent) setState(() { loading=false; error=data['message']?.toString() ?? 'Gagal memuat Global Chat'; });
    } catch(e) { if(mounted && !silent) setState(() { loading=false; error='API Global Chat tidak dapat dihubungi'; }); }
  }

  Future<void> _sendMessage() async {
    final text=messageController.text.trim();
    if(text.isEmpty || sending) return;
    setState(()=>sending=true);
    try {
      final r=await http.post(ApiConfig.endpoint('/api/global-chat/messages', {'key':widget.sessionKey}), headers:{'Content-Type':'application/json'}, body:jsonEncode({'message':text})).timeout(const Duration(seconds:10));
      final data=jsonDecode(r.body);
      if(r.statusCode==200 && data['valid']==true) { messageController.clear(); await _loadMessages(silent:true); }
      else if(mounted) _snack(data['message']?.toString() ?? 'Gagal mengirim pesan', true);
    } catch(_) { if(mounted) _snack('Global Chat sedang tidak tersedia', true); }
    if(mounted) setState(()=>sending=false);
  }

  void _scrollToBottom()=>WidgetsBinding.instance.addPostFrameCallback((_) { if(_scrollController.hasClients) _scrollController.jumpTo(_scrollController.position.maxScrollExtent); });
  void _snack(String t,bool bad)=>ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(t),backgroundColor:bad?Colors.red:const Color(0xFFFFC52E)));

  @override void dispose(){_pollTimer?.cancel();messageController.dispose();_scrollController.dispose();super.dispose();}

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF7F8FC),
      appBar: AppBar(
        backgroundColor: const Color(0xFFF7F8FC),
        foregroundColor: const Color(0xFF202124),
        elevation: 0,
        title: const Text(
          'GLOBAL CHAT',
          style: TextStyle(
            fontFamily: 'Orbitron',
            fontWeight: FontWeight.bold,
            letterSpacing: 1.2,
          ),
        ),
        actions: [
          IconButton(
            onPressed: () => _loadMessages(),
            icon: const Icon(Icons.refresh),
          ),
        ],
      ),
      body: Column(
        children: [
          Container(
            margin: const EdgeInsets.fromLTRB(16, 4, 16, 12),
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: const Color(0xFF1698E5),
              border: Border.all(color: const Color(0xFF202124), width: 2.5),
              borderRadius: BorderRadius.circular(18),
              boxShadow: const [
                BoxShadow(color: Color(0xFF202124), offset: Offset(0, 4)),
              ],
            ),
            child: const Row(
              children: [
                Icon(Icons.public, color: Colors.white, size: 30),
                SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'PPL GLOBAL CHAT',
                        style: TextStyle(
                          color: Colors.white,
                          fontFamily: 'Orbitron',
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      SizedBox(height: 3),
                      Text(
                        'Semua pesan menampilkan username dan role pengirim.',
                        style: TextStyle(
                          color: Colors.white70,
                          fontFamily: 'ShareTechMono',
                          fontSize: 11,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            child: loading && messages.isEmpty
                ? const Center(child: CircularProgressIndicator())
                : error != null && messages.isEmpty
                    ? Center(
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Text(
                              error!,
                              style: const TextStyle(fontFamily: 'ShareTechMono'),
                            ),
                            const SizedBox(height: 10),
                            ElevatedButton(
                              onPressed: () => _loadMessages(),
                              child: const Text('COBA LAGI'),
                            ),
                          ],
                        ),
                      )
                    : messages.isEmpty
                        ? const Center(
                            child: Text(
                              'Belum ada pesan. Jadilah yang pertama ngobrol.',
                              style: TextStyle(fontFamily: 'ShareTechMono'),
                            ),
                          )
                        : ListView.builder(
                            controller: _scrollController,
                            padding: const EdgeInsets.fromLTRB(14, 0, 14, 14),
                            itemCount: messages.length,
                            itemBuilder: (_, i) {
                              final m = messages[i];
                              return _bubble(m, false);
                            },
                          ),
          ),
          SafeArea(
            top: false,
            child: Container(
              padding: const EdgeInsets.fromLTRB(12, 8, 12, 10),
              decoration: const BoxDecoration(
                color: Colors.white,
                border: Border(
                  top: BorderSide(color: Color(0xFF202124), width: 1.5),
                ),
              ),
              child: Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: messageController,
                      maxLength: 500,
                      minLines: 1,
                      maxLines: 4,
                      onSubmitted: (_) => _sendMessage(),
                      decoration: InputDecoration(
                        counterText: '',
                        hintText: 'Tulis pesan ke Global Chat...',
                        filled: true,
                        fillColor: const Color(0xFFF7F8FC),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(16),
                          borderSide: const BorderSide(
                            color: Color(0xFF202124),
                            width: 1.5,
                          ),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Container(
                    decoration: BoxDecoration(
                      color: const Color(0xFFFFC52E),
                      border: Border.all(color: const Color(0xFF202124), width: 2),
                      borderRadius: BorderRadius.circular(14),
                    ),
                    child: IconButton(
                      onPressed: sending ? null : _sendMessage,
                      icon: sending
                          ? const SizedBox(
                              width: 20,
                              height: 20,
                              child: CircularProgressIndicator(strokeWidth: 2),
                            )
                          : const Icon(Icons.send, color: Color(0xFF202124)),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _bubble(Map<String,dynamic> m,bool mine){
    final role=m['role']?.toString() ?? 'member'; final name=m['username']?.toString() ?? 'user';
    return Align(alignment:Alignment.centerLeft,child:Container(margin:const EdgeInsets.only(bottom:9),padding:const EdgeInsets.all(12),constraints:BoxConstraints(maxWidth:MediaQuery.of(context).size.width*.84),decoration:BoxDecoration(color:Colors.white,border:Border.all(color:const Color(0xFF202124),width:1.7),borderRadius:BorderRadius.circular(15),boxShadow:const[BoxShadow(color:Color(0xFF202124),offset:Offset(0,2))]),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Row(children:[CircleAvatar(radius:14,backgroundColor:const Color(0xFF1698E5),child:Text(name.isEmpty?'?':name[0].toUpperCase(),style:const TextStyle(color:Colors.white,fontWeight:FontWeight.bold))),const SizedBox(width:8),Expanded(child:Text(name,style:const TextStyle(fontFamily:'ShareTechMono',fontWeight:FontWeight.bold))),Text(role.toUpperCase(),style:const TextStyle(fontFamily:'ShareTechMono',fontSize:9,color:Color(0xFF1698E5)))]),const SizedBox(height:7),Text(m['message']?.toString()??'',style:const TextStyle(fontFamily:'ShareTechMono',height:1.4))])));
  }
}
