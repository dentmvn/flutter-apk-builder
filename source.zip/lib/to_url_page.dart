import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class ToUrlPage extends StatefulWidget {
  const ToUrlPage({super.key});
  @override State<ToUrlPage> createState() => _ToUrlPageState();
}
class _ToUrlPageState extends State<ToUrlPage> {
  String? fileName, result;
  bool loading = false;

  Future<void> pickAndUpload() async {
    final picked = await FilePicker.pickFiles(withData: true);
    if (picked == null || picked.files.isEmpty) return;
    final file = picked.files.single;
    if (file.bytes == null) return;
    setState(() { loading = true; result = null; fileName = file.name; });
    try {
      final req = http.MultipartRequest('POST', Uri.parse('https://catbox.moe/user/api.php'));
      req.fields['reqtype'] = 'fileupload';
      req.files.add(http.MultipartFile.fromBytes('fileToUpload', file.bytes!, filename: file.name));
      final response = await req.send();
      final body = await response.stream.bytesToString();
      if (response.statusCode != 200 || !body.startsWith('http')) throw Exception(body);
      setState(() => result = body.trim());
    } catch (e) {
      setState(() => result = 'Upload gagal');
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    backgroundColor: const Color(0xFFF7F8FC),
    appBar: AppBar(
      backgroundColor: const Color(0xFFF7F8FC), foregroundColor: const Color(0xFF202124), elevation: 0,
      title: const Text('PPL TO URL', style: TextStyle(fontFamily: 'Orbitron', fontWeight: FontWeight.bold)),
    ),
    body: Padding(
      padding: const EdgeInsets.all(20),
      child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        Container(
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(color: Colors.white,border: Border.all(color: const Color(0xFF202124),width:2.5),borderRadius:BorderRadius.circular(18),boxShadow:const[BoxShadow(color:Color(0xFF202124),offset:Offset(0,4))]),
          child: Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
            const Text('CATBOX UPLOADER',style:TextStyle(fontFamily:'ShareTechMono',fontWeight:FontWeight.bold,letterSpacing:1.5)),
            const SizedBox(height:8),
            Text(fileName ?? 'Belum ada file dipilih',style:const TextStyle(fontFamily:'ShareTechMono')),
            const SizedBox(height:16),
            ElevatedButton.icon(
              onPressed: loading ? null : pickAndUpload,
              icon: const Icon(Icons.upload_file),
              label: Text(loading ? 'UPLOADING...' : 'PILIH & UPLOAD'),
              style: ElevatedButton.styleFrom(backgroundColor:const Color(0xFFFFC52E),foregroundColor:const Color(0xFF202124),side:const BorderSide(color:Color(0xFF202124),width:2),shape:RoundedRectangleBorder(borderRadius:BorderRadius.circular(13)),elevation:3),
            ),
            if(result!=null) ...[
              const SizedBox(height:16),
              SelectableText(result!,style:const TextStyle(fontFamily:'ShareTechMono',color:Color(0xFF1698E5))),
            ],
          ]),
        ),
      ]),
    ),
  );
}
