package com.pplantikorup;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
